"use strict";
// ===============================
// REALM DEFENSE 2D  (revisi)
// Semua logika game ada di file ini.
// ===============================
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const W = canvas.width, H = canvas.height;
const MAX_WAVE = 10;
const SAVE_KEY = "realmDefense2D.save.v1";
const METEOR_COOLDOWN = 35;

const $ = id => document.getElementById(id);
const ui = {
  health: $("health"), gold: $("gold"), wave: $("wave"), best: $("best"),
  overlay: $("overlay"), overlayTitle: $("overlayTitle"), overlayText: $("overlayText"),
  startBtn: $("startBtn"), diffRow: $("diffRow"), waveBtn: $("waveBtn"), upgradeBtn: $("upgradeBtn"), sellBtn: $("sellBtn"),
  pauseBtn: $("pauseBtn"), autoBtn: $("autoBtn"), tokens: $("tokens"), speedBtn: $("speedBtn"), restartBtn: $("restartBtn"),
  meteorBtn: $("meteorBtn"), soundBtn: $("soundBtn"),
  selectionInfo: $("selectionInfo"), message: $("message"),
  wavePreview: $("wavePreview"), waveFill: $("waveFill"), towerGrid: $("towerGrid"),
  overlayLobbyBtn: $("overlayLobbyBtn"), lobbyBtn: $("lobbyBtn")
};

// ---------- Simpan progres (localStorage, aman jika diblokir) ----------
const GAME_VERSION = "6.5";
// ---------- Event Halloween ----------
// Ubah tanggal di sini untuk memperpanjang / mengganti periode event. EVENT_FORCE_ON = true -> event selalu aktif.
const EVENT = { id: "halloween", name: "Halloween", start: "2026-10-23", end: "2026-11-07" };
const EVENT_FORCE_ON = false;
const PULL_COST = 10, PULL10_COST = 90;
function eventActive() {
  if (EVENT_FORCE_ON || save.adminEvent) return true;
  const now = Date.now();
  return now >= new Date(EVENT.start + "T00:00:00").getTime() && now <= new Date(EVENT.end + "T23:59:59").getTime();
}
function eventDaysLeft() { return Math.max(0, Math.ceil((new Date(EVENT.end + "T23:59:59").getTime() - Date.now()) / 86400000)); }
const rarities = {
  common:   { name: "Common",   color: "#b8c2cc", weight: 55,  refund: 2 },
  uncommon: { name: "Uncommon", color: "#5fd27a", weight: 28,  refund: 4 },
  rare:     { name: "Rare",     color: "#4aa3ff", weight: 11.5, refund: 8 },
  legend:   { name: "Legend",   color: "#ffb020", weight: 4.2, refund: 20 },
  mythical: { name: "Mythical", color: "#ff4fd8", weight: 1.1, refund: 50 },
  secret:   { name: "Secret",   color: "#ff3b3b", weight: 0.2, refund: 150 }
};
const rarityOrder = Object.keys(rarities);

// Tambahkan entri baru di PALING ATAS setiap ada pembaruan, lalu ubah GAME_VERSION.
const patchNotes = [
  {
    version: "6.5", date: "30 Okt 2026", title: "Unit Murah untuk Early Wave 🪨",
    sections: [
      { label: "🛒 Toko (💎)", items: [
        "Slinger 🪨 (15 💎): hanya 30 gold di game, paling murah. Tembakan cepat ke musuh darat.",
        "Petasan 🧨 (30 💎): 50 gold. Ledakan kecil yang mengenai musuh bergerombol."
      ]},
      { label: "⚔️ Raid Shop (🔷)", items: [
        "Pedagang 💰 (70 🔷): 55 gold, memberi gold tambahan tiap wave selesai (+16 / +26 / +38 sesuai level). Maks 1 per game, ideal dipasang di awal."
      ]},
      { label: "💡 Tips", items: [
        "Slinger dan Petasan hanya mengenai musuh darat. Padukan dengan Archer agar kelelawar tetap tertangani."
      ]}
    ]
  },
  {
    version: "6.4", date: "30 Okt 2026", title: "Skin Baru & Intro Sinematik 🎬",
    sections: [
      { label: "🎬 Intro masuk game", items: [
        "Layar pembuka animasi: malam berbintang, benteng, dan pasukanmu (lengkap dengan skin yang dipakai) menahan gelombang slime sementara judul game muncul.",
        "Ketuk layar untuk mulai bermain. Tombol Lewati tersedia kapan saja."
      ]},
      { label: "🎨 9 skin baru", items: [
        "Common: Mint, Kopi. Uncommon: Matahari, Karang. Rare: Ninja Bayangan, Neon Siber. Legend: Ksatria Suci.",
        "Mythical baru dengan efek spesial: Dewi Sakura (kelopak bergugur & jejak kelopak) dan Raja Bayangan (asap gelap & kabut ungu).",
        "Secret baru dengan efek spesial: Dewa Matahari (sinar berputar, percikan api, tiga matahari mengorbit)."
      ]}
    ]
  },
  {
    version: "6.3", date: "29 Okt 2026", title: "4 Evolve Baru ✨",
    sections: [
      { label: "✨ Evolve baru (3 🧿 per unit, permanen)", items: [
        "Cannon → Howitzer 🚀: peluru artileri AOE besar. Skill Barrage tiap 9 dtk: 6 peluru jatuh ke 6 musuh terdepan.",
        "Ice → Blizzard 🌨️: serpihan es melambatkan area. Skill Deep Freeze tiap 10 dtk: semua musuh dalam jangkauan membeku 2,5 dtk (bos hanya melambat).",
        "Tesla → Storm Coil 🌩️: petir memantul ke 4 musuh. Skill Thunder Strike tiap 8 dtk: sambaran 3× damage ke semua musuh dalam jangkauan, termasuk yang terbang.",
        "Sniper → Railgun ⚡: sinar menembus semua musuh sejajar. Skill Headshot tiap 6 dtk: tembakan 4× damage.",
        "Tiap evolve punya karakter chibi dan suara sendiri. Seperti biasa, bisa dikembalikan ke Original kapan saja di tab Pasukan."
      ]}
    ]
  },
  {
    version: "6.2", date: "29 Okt 2026", title: "Keseimbangan: Lebih Ramah Pemain ⚖️",
    sections: [
      { label: "💰 Harga lebih murah", items: [
        "Harga semua unit turun 20%, dan biaya upgrade ikut turun.",
        "Gold awal naik: Easy 300, Medium 240, Hard 190, Insane 150.",
        "Nyawa markas naik: Easy 20, Medium 15, Hard 10, Insane 6."
      ]},
      { label: "⚔️ Raid", items: [
        "Karena unit lebih murah, Raid Boss dan pasukannya dibuat lebih tebal agar Raid tetap menantang."
      ]}
    ]
  },
  {
    version: "6.1", date: "28 Okt 2026", title: "Serangan Sesuai Karakter ⚔️",
    sections: [
      { label: "⚔️ Animasi serangan baru", items: [
        "Pencabut Nyawa (Reaper) kini menebas: sabit diayun, tubuh maju sedikit, dan muncul garis tebasan di musuh (bukan tembakan lagi).",
        "Archer dan Crossbow menembakkan anak panah sungguhan yang mengarah ke musuh.",
        "Ballista melepas baut besar, dan Volley Crossbow melepas tiga anak panah sekaligus.",
        "Flame dan Blazed menyemburkan api dari obor ke arah musuh."
      ]}
    ]
  },
  {
    version: "6.0", date: "27 Okt 2026", title: "Skin & Peti Gacha 🎨",
    sections: [
      { label: "🎨 Skin untuk semua unit", items: [
        "24 skin baru dengan 6 tingkat kelangkaan: Common, Uncommon, Rare, Legend, Mythical, dan Secret.",
        "Skin mengubah warna seluruh karakter chibi, termasuk unit evolve dan unit Halloween. Pasang untuk semua unit, atau pilih skin berbeda untuk tiap unit.",
        "Tab Skin punya pratinjau animasi: coba skin apa pun pada unit pilihanmu sebelum memakainya."
      ]},
      { label: "📦 Peti Gacha (bayar 🔷 Crystal)", items: [
        "4 peti: Kayu (30 🔷), Perak (100 🔷), Emas (250 🔷), Berlian (600 🔷). Makin mahal, makin besar peluang skin langka.",
        "Buka ×1 atau ×5 (diskon 10%). Tiap peti punya pity sendiri. Skin kembar dikembalikan sebagai 🔷.",
        "Crystal didapat dari mode Raid."
      ]},
      { label: "✨ Efek spesial (di atas Legend)", items: [
        "Legend: aura bercahaya.",
        "Mythical: Naga Api (api & jejak api), Raja Es (salju & serpihan es), Dewa Petir (kilat di sekeliling & peluru petir).",
        "Secret: Void Semesta (lubang hitam & bintang) dan Prisma Pelangi (warna berputar & jejak pelangi)."
      ]}
    ]
  },
  {
    version: "5.3", date: "27 Okt 2026", title: "Efek Suara Baru 🔊",
    sections: [
      { label: "🔊 Mesin suara baru", items: [
        "Setiap unit kini punya suara tembakan sendiri: petikan busur Archer, dentuman Cannon, denting kristal Ice, gelembung Poison, retakan Sniper, sambaran Tesla, desis api Flame, sabetan Reaper, dan lainnya.",
        "Musuh punya suara kematian berbeda: slime, pelari, tank, kelelawar, bos, sampai Raid Boss.",
        "Suara baru untuk wave dimulai, peringatan bos, auman Raid Boss, meteor, Inferno, Volley, Nova, markas terkena, kemenangan, dan kekalahan.",
        "Evolve, jatuhnya token 🧿, dan hasil Gacha (dari Common sampai Secret) punya fanfare masing-masing.",
        "Klik menu, ganti tab, pasang/lepas unit, beli, dan pilih mode kini ada bunyinya.",
        "Suara dibatasi otomatis saat pertempuran ramai agar tidak pecah. Tombol 🔊 tetap untuk menyalakan/mematikan semua suara."
      ]}
    ]
  },
  {
    version: "5.2", date: "25 Okt 2026", title: "Karakter Chibi 🎨",
    sections: [
      { label: "🎨 Tampilan baru semua unit", items: [
        "Semua unit kini punya karakter chibi sendiri: Archer bertopi pemburu, Magic berjubah penyihir, Reaper berkerudung dengan sabit, Phoenix bersayap api, Totem, Penambang, hingga Meriam dengan penembaknya.",
        "Karakter menghadap ke musuh yang diserang, bergerak halus saat diam, dan memberi efek cahaya saat menembak.",
        "Bentuk Evolved tampil berbeda dari Original (zirah, jubah, dan efek lebih megah) dan diberi cincin cahaya.",
        "Tower level 3 ke atas diberi cincin cahaya di kaki; level 5 berwarna emas.",
        "Potret karakter juga tampil di tombol tower, slot pasukan, Toko, dan Raid Shop."
      ]}
    ]
  },
  {
    version: "5.1", date: "25 Okt 2026", title: "Evolve Permanen",
    sections: [
      { label: "✨ Evolve kini permanen", items: [
        "Evolve dilakukan di lobi: tab Pasukan → pada unit Flame / Poison / Archer tekan ✨ Evolve (3 🧿). Cukup sekali, berlaku selamanya.",
        "Setelah dibuka, unit langsung dipasang dalam bentuk Evolved sejak awal game (tanpa perlu level maksimum). Harga di game lebih tinggi karena sudah setara unit level maks.",
        "Bisa kembali ke bentuk Original kapan saja lewat tombol Bentuk di kartu unit, tanpa kehilangan evolve dan tanpa biaya.",
        "Tombol Evolve di dalam game dihapus. 🧿 Token tetap jatuh dari musuh seperti sebelumnya."
      ]}
    ]
  },
  {
    version: "5.0", date: "24 Okt 2026", title: "Evolve & Raid ⚔️",
    sections: [
      { label: "✨ Sistem Evolve", items: [
        "Musuh yang dibunuh bisa menjatuhkan 🧿 Evolve Token dengan peluang sangat kecil (bos lebih besar). Ada pity: dijamin dapat 1 token setelah 300 musuh tanpa drop.",
        "Naikkan tower ke level maksimum, pilih tower itu, lalu tekan ✨ Evolve (butuh 3 🧿). Tombol pintasan: E.",
        "Flame → Blazed 🌋: skill Inferno tiap 7 detik, ledakan api 5× damage ke semua musuh darat + bakar parah.",
        "Poison → Toxic Acid 🧪: asam mengikis armor musuh (-30%, dinikmati semua tower) dan musuh yang mati meledakkan genangan asam.",
        "Archer → Crossbow 🏹: jarak & damage lebih besar, tiap tembakan ke-4 melontarkan Volley Tembus yang menembus semua musuh dalam satu garis (abaikan armor)."
      ]},
      { label: "⚔️ Mode Raid", items: [
        "Tab baru Raid: bertarung di Arena Raid, 10 wave penuh bos dan ditutup dengan Raid Boss raksasa yang mengamuk saat HP 50% (+3 nyawa hilang jika bocor).",
        "Hadiah 🔷 Crystal: 5 per wave yang selesai, +80 jika menang, dikali pengali mode kesulitan. Tidak ada 💎 dari raid.",
        "Raid Shop: tukar 🔷 Crystal dengan 3 unit spesial yang HANYA ada di sini: Titan Cannon 🚀, Penjaga Waktu ⏳, dan Phoenix 🦅."
      ]}
    ]
  },
  {
    version: "4.4", date: "24 Okt 2026", title: "Lobby Baru, Lebih Simpel",
    sections: [
      { label: "📱 Tampilan lobi baru", items: [
        "HP: menu pindah ke bilah bawah (Map, Pasukan, Toko, Gacha, Info) dan tombol Main selalu terlihat, jadi tidak perlu scroll.",
        "Kartu map di HP dibuat ringkas (gambar di kiri, info di kanan); di PC tampil 3 kolom.",
        "Map yang dipilih diberi tanda ✔ Dipilih, dan petunjuk 3 langkah (pilih map → atur pasukan → Main) ada di bagian atas.",
        "Teks petunjuk dipersingkat agar lebih mudah dipahami."
      ]}
    ]
  },
  {
    version: "4.3", date: "24 Okt 2026", title: "Pilih Mode di Dalam Map & Auto Wave",
    sections: [
      { label: "🎚️ Pilih mode sebelum mulai", items: [
        "Mode kesulitan (Easy / Medium / Hard / Insane) kini dipilih di layar awal setiap map, tepat sebelum menekan Mulai.",
        "Ganti mode di layar awal atau layar game over akan langsung mengulang map dengan pengaturan baru."
      ]},
      { label: "🔁 Auto Wave", items: [
        "Tombol baru 🔁 Auto: otomatis memulai wave berikutnya sekitar 2 detik setelah wave selesai, jadi tidak perlu menekan Mulai Wave terus-menerus.",
        "Pintasan keyboard: A. Pengaturan Auto tersimpan."
      ]}
    ]
  },
  {
    version: "4.2", date: "23 Okt 2026", title: "Mode Kesulitan",
    sections: [
      { label: "🎚️ 4 tingkat kesulitan", items: [
        "Pilih Easy, Medium, Hard, atau Insane di tab Pilih Map sebelum bermain.",
        "Easy: musuh lebih lemah dan lambat, nyawa 15, gold awal lebih banyak, tetapi hadiah 💎 ×0,6.",
        "Medium: pengalaman standar seperti sebelumnya (nyawa 10, hadiah ×1).",
        "Hard: musuh +35% HP dan sedikit lebih cepat, nyawa 8, gold awal 140, hadiah 💎 ×1,5.",
        "Insane: musuh +70% HP dan jauh lebih cepat, nyawa 5, gold awal 130, hadiah 💎 ×2,5.",
        "Rekor setiap map dicatat terpisah untuk tiap mode."
      ]}
    ]
  },
  {
    version: "4.1", date: "23 Okt 2026", title: "Balance Pass & Gua Kristal",
    sections: [
      { label: "⚖️ Balance semua unit", items: [
        "Archer lebih murah DPS awal yang sehat: damage 18 → 17, interval 0,70 → 0,72 detik.",
        "Cannon, Ice, Magic, Tesla, Sniper, Flame, Ballista, Mortar, Hexer, dan unit Gacha disetel ulang agar tidak ada satu unit yang unggul di semua situasi.",
        "Totem dan Bulan Darah diturunkan buff-nya; Mine dibuat lebih konsisten; BARACK lebih murah tetapi pasukannya sedikit lebih rapuh.",
        "Unit multi-target tetap kuat melawan gerombolan, tetapi damage per target diturunkan agar Sniper, Magic, dan Archer tetap punya peran jelas."
      ]},
      { label: "🌿 Unit baru", items: ["Druid (145 🪙 / 75 💎): penembak alam hybrid dengan jangkauan panjang, bisa menyerang darat dan udara, tetapi tanpa tembus armor."] },
      { label: "💎 Map baru", items: ["Gua Kristal (★★★★): jalur memutar panjang dengan banyak tikungan. Musuh +75% HP, hadiah 💎 ×2,0, dan gelombang udara mulai wave 4."] }
    ]
  },
  {
    version: "4.0", date: "23 Okt 2026", title: "Event Halloween 🎃",
    sections: [
      { label: "🗺️ Map event", items: ["🎃 Lembah Hantu (★★★): map bertema Halloween, jalur tangga berliku. Lebih banyak musuh terbang 🦇 sejak wave 2. Musuh +35% HP, hadiah 💎 ×1,3. Hanya tersedia selama event."] },
      { label: "🎃 Halloween Coin", items: ["Mata uang khusus event. Didapat dari bermain di Lembah Hantu: 2 coin per wave selesai, +20 jika menang. Kamu mendapat 20 coin gratis di awal.", "Dipakai untuk gacha di tab 🎃 Gacha."] },
      { label: "🎰 Gacha unit", items: [
        "Tarik ×1 = 10 🎃, tarik ×10 = 90 🎃 (hemat 10).",
        "6 tingkat rarity (peluang dasar): Common 55%, Uncommon 28%, Rare 11,5%, Legend 4,2%, Mythical 1,1%, dan Secret 0,2%.",
        "Pity: tarikan ke-10 tanpa Rare pasti Rare+. Legend+ dijamin dalam 40 tarikan, Mythical+ dalam 120 tarikan.",
        "Unit duplikat dikembalikan jadi coin (Common 2 hingga Secret 150)."] },
      { label: "🧰 Unit gacha baru (maks Lv 3)", items: [
        "Common: 🎃 Labu Meledak, 🕯️ Lilin Api.",
        "Uncommon: 👻 Hantu (tembus armor), 🕸️ Jaring Laba-laba (aura perlambat).",
        "Rare: 🪦 Kuburan (memanggil zombie), 🧙 Penyihir (kolam racun + perlambat).",
        "Legend: 🧛 Vampir (menyerang banyak musuh sekaligus).",
        "Mythical: 💀 Malaikat Maut (mengeksekusi musuh berHP rendah).",
        "Secret: ??? Temukan sendiri 🤫"] },
      { label: "🛠️ Lain-lain", items: ["Event berlangsung sampai 7 Nov 2026. Unit yang sudah didapat tetap bisa dipakai setelah event berakhir."] }
    ]
  },
  {
    version: "3.0", date: "23 Okt 2026", title: "Gunung Berapi, Mortar & Hexer",
    sections: [
      { label: "🗺️ Map baru", items: ["🌋 Gunung Berapi (★★★★): jalur zig-zag panjang dengan kolam lava. Musuh +60% HP, hadiah 💎 ×1,8."] },
      { label: "🧰 Unit baru (maks Lv 3)", items: [
        "🧨 Mortar (75 💎): artileri jarak jauh dengan ledakan AOE besar (radius 55/62/70). Hanya mengenai musuh darat.",
        "🔮 Hexer (65 💎): menandai musuh sehingga menerima +20/30/40% damage dari semua sumber selama 3,5 detik. Lv 3 menyebarkan kutukan ke 2 musuh di dekatnya."] },
      { label: "⚖️ Balance", items: [
        "Archer: kecepatan tembak 0,65 → 0,70 detik (sedikit lebih lambat).", "Cannon: damage 38 → 42.", "Magic: damage 28 → 30.", "Tesla: damage 24 → 27.",
        "Sniper: damage 72 → 80, jangkauan 245 → 235.", "Totem Lv 1: bonus damage 15% → 18%.",
        "Mine Lv 3: gold per wave 85 → 80.", "BARACK: HP Ksatria 92 → 100.",
        "Meteor: jeda 40 → 35 detik.", "Bos: hadiah gold 40 → 45.", "Bonus gems saat menang: 25 → 30."] },
      { label: "🛠️ Lain-lain", items: ["Tab Patch Note di lobby, lengkap dengan badge BARU."] }
    ]
  },
  {
    version: "2.1", date: "23 Okt 2026", title: "Flame jadi AOE",
    sections: [{ label: "⚖️ Balance", items: ["🔥 Flame kini menyerang SEMUA musuh darat dalam jangkauan sekaligus dan membakar mereka.", "Damage per semburan diturunkan: 7/12/19 → 5/9/14 agar seimbang."] }]
  },
  {
    version: "2.0", date: "22 Okt 2026", title: "Lobby, Toko & Map",
    sections: [
      { label: "🏠 Lobby", items: ["Pilih map: Hutan, Padang Pasir, Gerbang Kerajaan.", "Bawa maksimal 5 unit (slot). Awalnya hanya Archer yang terbuka.", "Toko: beli unit permanen dengan 💎 yang didapat dari menyelesaikan wave."] },
      { label: "🧰 Unit baru (maks Lv 3)", items: ["🔥 Flame, 🔱 Ballista, 🗿 Totem, ⛏️ Mine."] },
      { label: "⚖️ Balance", items: ["Padang Pasir: musuh +30% HP. Gerbang Kerajaan: musuh +50% HP."] }
    ]
  },
  {
    version: "1.1", date: "22 Okt 2026", title: "Revisi besar",
    sections: [
      { label: "🐞 Perbaikan bug", items: ["Ice tidak lagi membekukan terus-menerus: kini memperlambat, dan membeku 1,2 detik tiap 4 tembakan.", "Musuh sekarang melawan pasukan BARACK, dan pasukan menjaga titik kumpul.", "Tower tidak bisa lagi dipasang menimpa pohon, kolam, atau markas.", "Target tower dipilih dari jarak tempuh asli musuh."] },
      { label: "✨ Fitur baru", items: ["Musuh baru: Lari, Tank, Terbang, dan Bos.", "Skill Meteor, efek suara, rekor tersimpan, pratinjau jangkauan, pintasan keyboard."] }
    ]
  },
  {
    version: "1.0", date: "—", title: "Versi awal",
    sections: [{ label: "🎮 Isi game", items: ["8 tower, 10 wave, dan BARACK dengan pasukan."] }]
  }
];

const defaultSave = { bestWave: 0, wins: 0, muted: false, gems: 30, owned: ["archer"], loadout: ["archer"], map: "forest", mapBest: {}, seenPatch: "", coins: 20, gacha: { pRare: 0, pLegend: 0, pMyth: 0, pulls: 0 }, seenEvent: false, diff: "medium", auto: false, crystals: 0, tokens: 0, tokenPity: 0, evolved: {}, evoOn: {}, skinsOwned: [], skinAll: "", skinFor: {}, skinPity: {} };
function loadSave() {
  try { return Object.assign({}, defaultSave, JSON.parse(localStorage.getItem(SAVE_KEY) || "{}")); }
  catch (e) { return Object.assign({}, defaultSave); }
}
function writeSave() { try { localStorage.setItem(SAVE_KEY, JSON.stringify(save)); } catch (e) { /* abaikan */ } }
const save = loadSave();

// ---------- Data tower & musuh ----------
const towerTypes = {
  archer: { name: "Archer", cost: 50, gem: 0, range: 125, damage: 17, rate: 0.72, color: "#f7c66a", icon: "🏹", air: true, desc: "Murah & cepat" },
  cannon: { name: "Cannon", cost: 80, gem: 25, range: 105, damage: 44, rate: 1.3, color: "#aeb9c9", icon: "💣", air: false, desc: "Damage area • hanya darat" },
  ice: { name: "Ice", cost: 90, gem: 35, range: 120, damage: 8, rate: 0.9, color: "#81e5ff", icon: "❄️", air: true, desc: "Memperlambat • membeku tiap 4 tembakan" },
  poison: { name: "Poison", cost: 100, gem: 40, range: 130, damage: 13, rate: 0.9, color: "#a7e36b", icon: "☠️", air: false, pierce: true, desc: "Racun bertahap • hanya darat" },
  magic: { name: "Magic", cost: 110, gem: 50, range: 165, damage: 28, rate: 0.95, color: "#d3a2ff", icon: "✨", air: true, pierce: true, desc: "Jangkauan jauh • tembus armor" },
  sniper: { name: "Sniper", cost: 125, gem: 60, range: 235, damage: 88, rate: 2.05, color: "#ffce73", icon: "🎯", air: true, desc: "Jarak jauh, damage tinggi" },
  tesla: { name: "Tesla", cost: 140, gem: 70, range: 145, damage: 25, rate: 1.2, color: "#7ce7ff", icon: "⚡", air: true, desc: "Listrik memantul ke musuh sekitar" },
  barrack: { name: "BARACK", cost: 280, gem: 80, range: 0, damage: 0, rate: 8, color: "#c79b63", icon: "🏰", air: false, rally: true, maxLevel: 3, desc: "Spawner pasukan • upgrade Lv. 1–3" },
  // ---- Unit baru: semua maksimal Lv. 3 dengan stat per level ----
  flame: {
    name: "Flame", cost: 100, gem: 55, range: 85, damage: 5, rate: 0.3, color: "#ff8a3d", icon: "🔥", air: false, maxLevel: 3,
    levels: [{ damage: 5, range: 85, rate: 0.3 }, { damage: 8, range: 92, rate: 0.28 }, { damage: 12, range: 100, rate: 0.25 }],
    desc: "Ledakan api AOE ke semua musuh darat di sekitar + membakar"
  },
  ballista: {
    name: "Ballista", cost: 130, gem: 70, range: 200, damage: 55, rate: 1.7, color: "#e8d9a8", icon: "🔱", air: true, maxLevel: 3,
    levels: [{ damage: 50, range: 200, rate: 1.75 }, { damage: 78, range: 215, rate: 1.6 }, { damage: 115, range: 230, rate: 1.45, pierce: true }],
    desc: "Panah tembus semua musuh dalam satu garis"
  },
  totem: {
    name: "Totem", cost: 120, gem: 100, range: 110, damage: 0, rate: 0, color: "#8fd6a5", icon: "🗿", air: false, maxLevel: 3, support: true,
    levels: [{ range: 110, dmgBuff: 0.15, rateBuff: 0 }, { range: 130, dmgBuff: 0.22, rateBuff: 0.05 }, { range: 150, dmgBuff: 0.3, rateBuff: 0.1 }],
    desc: "Aura: tower di sekitarnya lebih kuat"
  },
  mine: {
    name: "Mine", cost: 150, gem: 90, range: 0, damage: 0, rate: 0, color: "#ffd166", icon: "⛏️", air: false, maxLevel: 3, income: true,
    levels: [{ income: 32 }, { income: 54 }, { income: 76 }],
    desc: "Menghasilkan gold di akhir tiap wave"
  },
  slinger: {
    name: "Slinger", cost: 40, gem: 15, range: 110, damage: 13, rate: 0.46, color: "#c9b27a", icon: "🪨", air: false, desc: "Super murah • tembakan cepat • hanya darat"
  },
  petasan: {
    name: "Petasan", cost: 60, gem: 30, range: 105, damage: 22, rate: 0.95, color: "#ff6a4a", icon: "🧨", air: false, desc: "Murah • ledakan kecil mengenai musuh bergerombol • hanya darat"
  },
  mortar: {
    name: "Mortar", cost: 135, gem: 75, range: 190, damage: 80, rate: 2.3, color: "#b9a27a", icon: "🧨", air: false, maxLevel: 3,
    levels: [{ damage: 72, range: 190, rate: 2.4, splash: 55 }, { damage: 110, range: 205, rate: 2.2, splash: 62 }, { damage: 155, range: 220, rate: 2, splash: 70 }],
    desc: "Artileri jarak jauh, ledakan AOE besar • hanya darat"
  },
  hexer: {
    name: "Hexer", cost: 95, gem: 65, range: 150, damage: 6, rate: 1.0, color: "#c58bff", icon: "🔮", air: true, maxLevel: 3, debuff: true,
    levels: [{ damage: 6, range: 150, rate: 1.0, amp: 0.18 }, { damage: 10, range: 160, rate: 0.92, amp: 0.27 }, { damage: 15, range: 175, rate: 0.82, amp: 0.36, spread: true }],
    desc: "Kutukan: musuh terkena damage ekstra dari semua sumber"
  },
  // ================== UNIT GACHA HALLOWEEN (maks Lv 3) ==================
  pumpkin: {
    name: "Labu Meledak", gacha: true, rarity: "common", cost: 80, range: 120, damage: 30, rate: 1.5, color: "#ff9a2e", icon: "🎃", air: false, maxLevel: 3,
    levels: [{ damage: 28, range: 120, rate: 1.5, splash: 42 }, { damage: 44, range: 128, rate: 1.4, splash: 48 }, { damage: 64, range: 136, rate: 1.3, splash: 54 }],
    desc: "Melempar labu yang meledak kecil • hanya darat",
    note: "⚔ 30 • ◎ 120 • Ledakan 42 / 48 / 54"
  },
  candle: {
    name: "Lilin Api", gacha: true, rarity: "common", cost: 60, range: 110, damage: 10, rate: 0.55, color: "#ffd27a", icon: "🕯️", air: true, maxLevel: 3,
    levels: [{ damage: 9, range: 110, rate: 0.58, burn: 3 }, { damage: 14, range: 118, rate: 0.53, burn: 5 }, { damage: 21, range: 126, rate: 0.48, burn: 8 }],
    desc: "Tembakan cepat yang membakar target",
    note: "⚔ 10 • ◎ 110 • Bakar 3 / 5 / 8 per detik"
  },
  ghost: {
    name: "Hantu", gacha: true, rarity: "uncommon", cost: 120, range: 150, damage: 26, rate: 0.8, color: "#cfe3ff", icon: "👻", air: true, pierce: true, maxLevel: 3,
    levels: [{ damage: 24, range: 150, rate: 0.82 }, { damage: 37, range: 160, rate: 0.77 }, { damage: 55, range: 170, rate: 0.72 }],
    desc: "Serangan roh menembus armor • bisa kena udara",
    note: "⚔ 26 • ◎ 150 • Tembus armor"
  },
  web: {
    name: "Jaring Laba-laba", gacha: true, rarity: "uncommon", cost: 100, range: 100, damage: 0, rate: 0, color: "#e6e6ee", icon: "🕸️", air: false, maxLevel: 3, support: true,
    levels: [{ range: 100, slow: 0.68 }, { range: 115, slow: 0.58 }, { range: 130, slow: 0.49 }],
    desc: "Aura memperlambat semua musuh di sekitar (darat & udara)",
    note: "Aura ◎ 100 / 115 / 130 • Perlambat 35% / 45% / 55%",
    info: lv => `Aura radius ${lv.range} • musuh melambat ${Math.round((1 - lv.slow) * 100)}% (darat & udara)`
  },
  graveyard: {
    name: "Kuburan", gacha: true, rarity: "rare", cost: 190, range: 0, damage: 0, rate: 0, color: "#7fae6b", icon: "🪦", air: false, maxLevel: 3, rally: true,
    levels: [{ zombies: 2, hp: 120, dmg: 12, respawn: 7 }, { zombies: 3, hp: 150, dmg: 15, respawn: 6 }, { zombies: 4, hp: 190, dmg: 20, respawn: 5 }],
    desc: "Membangkitkan zombie yang menahan jalan musuh",
    note: "Zombie 2 / 3 / 4 • HP 130 → 210",
    info: lv => `Zombie maks ${lv.zombies} • HP ${lv.hp} • damage ${lv.dmg} • bangkit tiap ${lv.respawn} dtk`
  },
  witch: {
    name: "Penyihir", gacha: true, rarity: "rare", cost: 170, range: 140, damage: 20, rate: 1.0, color: "#b44cff", icon: "🧙", air: false, maxLevel: 3,
    levels: [{ damage: 18, range: 140, rate: 1.02, pool: 50, slow: 0.7, dps: 6 }, { damage: 29, range: 150, rate: 0.97, pool: 56, slow: 0.6, dps: 10 }, { damage: 42, range: 160, rate: 0.92, pool: 62, slow: 0.5, dps: 15 }],
    desc: "Ramuan: kolam racun yang memperlambat • hanya darat",
    note: "⚔ 20 • ◎ 140 • Kolam racun + perlambat",
    info: lv => `Damage ${lv.damage} • kolam ${lv.dps}/dtk + melambat ${Math.round((1 - lv.slow) * 100)}% • radius ${lv.pool}`
  },
  vampire: {
    name: "Vampir", gacha: true, rarity: "legend", cost: 230, range: 170, damage: 70, rate: 1.1, color: "#d1304a", icon: "🧛", air: true, maxLevel: 3,
    levels: [{ damage: 64, range: 170, rate: 1.12, targets: 3 }, { damage: 98, range: 180, rate: 1.02, targets: 4 }, { damage: 145, range: 190, rate: 0.92, targets: 5 }],
    desc: "Kawanan kelelawar menyerang banyak musuh sekaligus",
    note: "⚔ 70 • ◎ 170 • Hingga 3 / 4 / 5 target",
    info: lv => `Damage ${lv.damage} ke hingga ${lv.targets} musuh sekaligus • Jangkauan ${lv.range}`
  },
  reaper: {
    name: "Malaikat Maut", gacha: true, rarity: "mythical", cost: 320, range: 200, damage: 90, rate: 1.3, color: "#8b8fa8", icon: "💀", air: true, pierce: true, maxLevel: 3,
    levels: [{ damage: 85, range: 200, rate: 1.35, exec: 0.2 }, { damage: 130, range: 215, rate: 1.25, exec: 0.27 }, { damage: 195, range: 230, rate: 1.15, exec: 0.35 }],
    desc: "Mengeksekusi musuh dengan HP rendah (bos butuh HP lebih rendah lagi)",
    note: "⚔ 90 • ◎ 200 • Eksekusi < 20% / 27% / 35% HP",
    info: lv => `Damage ${lv.damage} (tembus armor) • Eksekusi musuh < ${Math.round(lv.exec * 100)}% HP • Jangkauan ${lv.range}`
  },
  druid: {
    name: "Druid", cost: 145, gem: 75, range: 155, damage: 22, rate: 1.05, color: "#72d18b", icon: "🌿", air: true, maxLevel: 3,
    levels: [{ damage: 22, range: 155, rate: 1.05 }, { damage: 35, range: 170, rate: 0.95 }, { damage: 52, range: 185, rate: 0.85, pierce: true }],
    desc: "Penembak alam seimbang untuk darat & udara; Lv 3 menembus armor",
    note: "⚔ 22 • ◎ 155 • Darat & udara"
  },
  bloodmoon: {
    name: "Bulan Darah", gacha: true, rarity: "secret", cost: 450, range: 0, damage: 0, rate: 0, color: "#e0364a", icon: "🌕", air: false, maxLevel: 3, support: true, unique: true,
    levels: [{ dmgBuff: 0.16, rateBuff: 0.04, nova: 60, novaEvery: 9 }, { dmgBuff: 0.24, rateBuff: 0.07, nova: 110, novaEvery: 8 }, { dmgBuff: 0.32, rateBuff: 0.1, nova: 180, novaEvery: 7 }],
    desc: "Buff SEMUA tower + sambaran bulan ke seluruh musuh • maks 1 per game",
    note: "Buff global +20% / 30% / 40% damage • Nova 60 / 110 / 180",
    info: lv => `Buff semua tower +${Math.round(lv.dmgBuff * 100)}% damage, +${Math.round(lv.rateBuff * 100)}% kecepatan • Nova ${lv.nova} damage tiap ${lv.novaEvery} dtk`
  }
};
// ================== UNIT EVOLVE (hanya dari Evolve, tidak bisa dibeli / dipasang di slot) ==================
const EVOLVE_COST = 3, TOKEN_RATE = 0.004, TOKEN_RATE_BOSS = 0.06, TOKEN_PITY = 300;
const evolveMap = { flame: "blazed", poison: "toxic", archer: "crossbow", cannon: "howitzer", ice: "blizzard", tesla: "storm", sniper: "railgun" };
function effKey(k) { return evolveMap[k] && save.evolved && save.evolved[k] && save.evoOn && save.evoOn[k] ? evolveMap[k] : k; }
Object.assign(towerTypes, {
  blazed: {
    name: "Blazed", evolved: true, from: "flame", cost: 300, range: 105, damage: 14, rate: 0.26, color: "#ff5a1f", icon: "🌋", air: false, maxLevel: 1, skillCd: 7,
    levels: [{ damage: 14, range: 105, rate: 0.26, burn: 11 }],
    desc: "Evolusi Flame • skill Inferno",
    note: "⚔ 14 AOE • ◎ 105 • Inferno tiap 7 dtk",
    info: lv => `AOE api • Damage ${lv.damage} • Bakar ${lv.burn}/dtk • ⚡ Inferno tiap 7 dtk: ledakan 5× damage + bakar parah ke semua musuh darat`
  },
  toxic: {
    name: "Toxic Acid", evolved: true, from: "poison", cost: 520, range: 170, damage: 62, rate: 0.7, color: "#7dff3a", icon: "🧪", air: false, pierce: true, maxLevel: 1,
    levels: [{ damage: 62, range: 170, rate: 0.7, pool: 70, dps: 12, corrode: 0.3 }],
    desc: "Evolusi Poison • asam pengikis armor",
    note: "⚔ 62 • ◎ 170 • Korosi armor -30%",
    info: lv => `Damage ${lv.damage} (tembus armor) • ⚡ Korosi: armor musuh -${Math.round(lv.corrode * 100)}% untuk SEMUA tower • Musuh yang mati meledakkan genangan asam`
  },
  crossbow: {
    name: "Crossbow", evolved: true, from: "archer", cost: 340, range: 190, damage: 74, rate: 0.5, color: "#ffe08a", icon: "🏹", air: true, maxLevel: 1,
    levels: [{ damage: 74, range: 190, rate: 0.5 }],
    desc: "Evolusi Archer • Volley Tembus",
    note: "⚔ 74 • ◎ 190 • Volley tiap tembakan ke-4",
    info: lv => `Damage ${lv.damage} • Darat & udara • ⚡ Tiap tembakan ke-4: Volley Tembus 2,4× damage menembus semua musuh sejajar (abaikan armor)`
  }
});

// ================== UNIT RAID SHOP (hanya bisa dibeli dengan 🔷 Crystal) ==================
Object.assign(towerTypes, {
  merchant: {
    name: "Pedagang", raid: true, crystal: 70, cost: 70, range: 0, damage: 0, rate: 0, color: "#ffd166", icon: "💰", air: false, maxLevel: 3, income: true, unique: true,
    levels: [{ income: 16 }, { income: 26 }, { income: 38 }],
    desc: "Murah • gold tambahan tiap wave selesai • maks 1 per game"
  },
  titan: {
    name: "Titan Cannon", raid: true, crystal: 150, cost: 320, range: 210, damage: 210, rate: 3.0, color: "#6fb7ff", icon: "🚀", air: false, maxLevel: 3,
    levels: [{ damage: 210, range: 210, rate: 3.0, splash: 78 }, { damage: 320, range: 225, rate: 2.8, splash: 88 }, { damage: 480, range: 240, rate: 2.5, splash: 100 }],
    desc: "Meriam raksasa: ledakan AOE sangat besar • hanya darat",
    note: "⚔ 210 • ◎ 210 • Ledakan 78 / 88 / 100"
  },
  howitzer: {
    name: "Howitzer", evolved: true, from: "cannon", cost: 480, range: 150, damage: 120, rate: 1.7, color: "#c9d36a", icon: "🚀", air: false, maxLevel: 1, skillCd: 9,
    levels: [{ damage: 120, range: 150, rate: 1.7, splash: 58 }],
    desc: "Evolusi Cannon • skill Barrage",
    note: "⚔ 120 AOE • ◎ 150 • Barrage tiap 9 dtk",
    info: lv => `Peluru artileri AOE ${lv.damage} • ⚡ Barrage tiap 9 dtk: 6 peluru jatuh bersamaan ke 6 musuh terdepan`
  },
  blizzard: {
    name: "Blizzard", evolved: true, from: "ice", cost: 420, range: 150, damage: 26, rate: 0.7, color: "#bff4ff", icon: "🌨️", air: true, maxLevel: 1, skillCd: 10,
    levels: [{ damage: 26, range: 150, rate: 0.7, splash: 55 }],
    desc: "Evolusi Ice • skill Deep Freeze",
    note: "⚔ 26 • ◎ 150 • Deep Freeze tiap 10 dtk",
    info: lv => `Serpihan es memperlambat area • membeku tiap 3 tembakan • ⚡ Deep Freeze tiap 10 dtk: SEMUA musuh dalam jangkauan membeku 2,5 dtk (bos hanya melambat)`
  },
  storm: {
    name: "Storm Coil", evolved: true, from: "tesla", cost: 460, range: 170, damage: 48, rate: 0.8, color: "#ffe36b", icon: "🌩️", air: true, maxLevel: 1, skillCd: 8,
    levels: [{ damage: 48, range: 170, rate: 0.8 }],
    desc: "Evolusi Tesla • skill Thunder Strike",
    note: "⚔ 48 • ◎ 170 • Petir 4 lompatan",
    info: lv => `Petir memantul ke 4 musuh • ⚡ Thunder Strike tiap 8 dtk: sambaran 3× damage ke SEMUA musuh dalam jangkauan (darat & udara) dan menyetrum sesaat`
  },
  railgun: {
    name: "Railgun", evolved: true, from: "sniper", cost: 560, range: 270, damage: 150, rate: 1.5, color: "#7af0ff", icon: "⚡", air: true, maxLevel: 1, skillCd: 6,
    levels: [{ damage: 150, range: 270, rate: 1.5 }],
    desc: "Evolusi Sniper • skill Headshot",
    note: "⚔ 150 tembus • ◎ 270 • Headshot tiap 6 dtk",
    info: lv => `Sinar menembus semua musuh dalam satu garis • ⚡ Headshot tiap 6 dtk: tembakan 4× damage`
  },
  chrono: {
    name: "Penjaga Waktu", raid: true, crystal: 120, cost: 260, range: 150, damage: 0, rate: 0, color: "#7be0d0", icon: "⏳", air: false, maxLevel: 3, support: true,
    levels: [{ range: 150, slow: 0.62, rateBuff: 0.1 }, { range: 175, slow: 0.52, rateBuff: 0.15 }, { range: 200, slow: 0.44, rateBuff: 0.2 }],
    desc: "Aura waktu: memperlambat musuh & mempercepat tower sekitar",
    note: "Aura ◎ 150 / 175 / 200 • Musuh melambat 38% / 48% / 56% • Tower +10% / 15% / 20% kecepatan",
    info: lv => `Aura radius ${lv.range} • musuh melambat ${Math.round((1 - lv.slow) * 100)}% • tower sekitar +${Math.round(lv.rateBuff * 100)}% kecepatan serang`
  },
  phoenix: {
    name: "Phoenix", raid: true, crystal: 200, cost: 280, range: 175, damage: 55, rate: 1.0, color: "#ff7a2e", icon: "🦅", air: true, maxLevel: 3,
    levels: [{ damage: 55, range: 175, rate: 1.0, targets: 3, burn: 8 }, { damage: 78, range: 185, rate: 0.92, targets: 4, burn: 12 }, { damage: 110, range: 195, rate: 0.85, targets: 5, burn: 18 }],
    desc: "Burung api: menyambar banyak musuh sekaligus & membakar • darat & udara",
    note: "⚔ 55 • ◎ 175 • Hingga 3 / 4 / 5 target + bakar 8 / 12 / 18",
    info: lv => `Damage ${lv.damage} ke hingga ${lv.targets} musuh • Bakar ${lv.burn}/dtk • Jangkauan ${lv.range}`
  }
});

const towerKeys = Object.keys(towerTypes);
const ownableKeys = towerKeys.filter(k => !towerTypes[k].evolved);
const shopKeys = towerKeys.filter(k => !towerTypes[k].gacha && !towerTypes[k].raid && !towerTypes[k].evolved);
const gachaKeys = towerKeys.filter(k => towerTypes[k].gacha);
const raidKeys = towerKeys.filter(k => towerTypes[k].raid);

// Keseimbangan v6.2: semua harga tower (dan otomatis biaya upgrade) dipotong.
const PRICE_SCALE = 0.8;
for (const k in towerTypes) towerTypes[k].cost = Math.max(10, Math.round(towerTypes[k].cost * PRICE_SCALE / 5) * 5);

const enemyTypes = {
  slime:  { label: "Slime",  icon: "🟢", hp: 1,   speed: 48, reward: 8,  radius: 11, color: "#79d68a", armor: 0,    dmg: 5 },
  runner: { label: "Lari",   icon: "💨", hp: 0.55, speed: 84, reward: 7,  radius: 9,  color: "#7ad7f0", armor: 0,    dmg: 4, evasive: true },
  tank:   { label: "Tank",   icon: "🛡️", hp: 2.3, speed: 34, reward: 15, radius: 15, color: "#f2a65a", armor: 0.3,  dmg: 12 },
  flyer:  { label: "Terbang", icon: "🦇", hp: 0.8, speed: 56, reward: 10, radius: 10, color: "#c9a7ff", armor: 0,    dmg: 0, flying: true },
  boss:   { label: "Bos",    icon: "👑", hp: 6,   speed: 27, reward: 45, radius: 19, color: "#e66a91", armor: 0.25, dmg: 25, boss: true },
  raidboss: { label: "Raid Boss", icon: "👹", hp: 16, speed: 22, reward: 200, radius: 28, color: "#b3123f", armor: 0.3, dmg: 40, boss: true, leak: 3 }
};

// ---------- Peta ----------
// Koordinat mengikuti ukuran canvas 900 x 520.
const mapDefs = {
  forest: {
    id: "forest", name: "Hutan", icon: "🌲", stars: 1, hpMult: 1, gemMult: 1,
    desc: "Jalur berkelok klasik di antara pepohonan. Cocok untuk pemula.",
    theme: { bg: "#78bd66", spotA: "#69ae5d", spotB: "#8acb73", edge: "#6a9a55", road: "#d7bd7a", dash: "#e8d39a", water: "#52c5dc", rim: "#4b8b53", base: "house" },
    path: [{ x: -20, y: 105 }, { x: 155, y: 105 }, { x: 155, y: 205 }, { x: 340, y: 205 }, { x: 340, y: 120 }, { x: 535, y: 120 }, { x: 535, y: 325 }, { x: 720, y: 325 }, { x: 720, y: 245 }, { x: 856, y: 245 }],
    obstacles: [
      { x: 785, y: 78, r: 48, name: "kolam", kind: "pond" },
      { x: 65, y: 370, r: 24, name: "pohon", kind: "tree" }, { x: 825, y: 420, r: 24, name: "pohon", kind: "tree" },
      { x: 65, y: 245, r: 24, name: "pohon", kind: "tree" }, { x: 845, y: 155, r: 24, name: "pohon", kind: "tree" }
    ]
  },
  desert: {
    id: "desert", name: "Padang Pasir", icon: "🏜️", stars: 2, hpMult: 1.3, gemMult: 1.25,
    desc: "Jalur panjang bersiku di antara kaktus dan oasis. Musuh sedikit lebih tangguh.",
    theme: { bg: "#e6c885", spotA: "#d8b673", spotB: "#f0d79d", edge: "#b98a4a", road: "#c99a5b", dash: "#dfbb82", water: "#3fb7cf", rim: "#7aa65a", base: "house" },
    path: [{ x: -20, y: 420 }, { x: 200, y: 420 }, { x: 200, y: 140 }, { x: 430, y: 140 }, { x: 430, y: 380 }, { x: 650, y: 380 }, { x: 650, y: 150 }, { x: 856, y: 150 }],
    obstacles: [
      { x: 90, y: 200, r: 40, name: "oasis", kind: "pond" },
      { x: 320, y: 300, r: 22, name: "kaktus", kind: "cactus" }, { x: 540, y: 220, r: 22, name: "kaktus", kind: "cactus" },
      { x: 780, y: 300, r: 22, name: "kaktus", kind: "cactus" }, { x: 90, y: 330, r: 22, name: "kaktus", kind: "cactus" },
      { x: 330, y: 470, r: 20, name: "batu", kind: "rock" }, { x: 760, y: 450, r: 20, name: "batu", kind: "rock" }, { x: 700, y: 50, r: 20, name: "batu", kind: "rock" }
    ]
  },
  castle: {
    id: "castle", name: "Gerbang Kerajaan", icon: "🏰", stars: 3, hpMult: 1.5, gemMult: 1.5,
    desc: "Lorong sempit di halaman kastil. Ruang tower terbatas, musuh paling tangguh.",
    theme: { bg: "#8d929b", spotA: "#80858e", spotB: "#9ba1aa", edge: "#5a5f69", road: "#c4b394", dash: "#dacfb3", water: "#5cb8d6", rim: "#5d6470", base: "gate" },
    path: [{ x: -20, y: 70 }, { x: 700, y: 70 }, { x: 700, y: 190 }, { x: 160, y: 190 }, { x: 160, y: 310 }, { x: 700, y: 310 }, { x: 700, y: 440 }, { x: 856, y: 440 }],
    obstacles: [
      { x: 430, y: 410, r: 34, name: "air mancur", kind: "pond" },
      { x: 60, y: 130, r: 20, name: "pilar", kind: "pillar" }, { x: 60, y: 400, r: 20, name: "pilar", kind: "pillar" },
      { x: 300, y: 480, r: 20, name: "pilar", kind: "pillar" }, { x: 560, y: 480, r: 20, name: "pilar", kind: "pillar" },
      { x: 800, y: 300, r: 20, name: "pilar", kind: "pillar" }, { x: 800, y: 150, r: 20, name: "pilar", kind: "pillar" }
    ]
  }
};
mapDefs.volcano = {
  id: "volcano", name: "Gunung Berapi", icon: "🌋", stars: 4, hpMult: 1.6, gemMult: 1.8,
  desc: "Zig-zag panjang di tanah vulkanik. Musuh paling tangguh, hadiah terbesar.",
  theme: { bg: "#3d2c2a", spotA: "#4b3532", spotB: "#2f2220", edge: "#d0521c", road: "#5e4b43", dash: "#8c7468", water: "#ff7a1a", rim: "#7a2e12", shine: "#ffd27a77", rockA: "#2e2523", rockB: "#4f403b", base: "gate" },
  path: [{ x: -20, y: 260 }, { x: 130, y: 260 }, { x: 130, y: 90 }, { x: 330, y: 90 }, { x: 330, y: 430 }, { x: 520, y: 430 }, { x: 520, y: 150 }, { x: 700, y: 150 }, { x: 700, y: 380 }, { x: 856, y: 380 }],
  obstacles: [
    { x: 230, y: 300, r: 36, name: "kolam lava", kind: "pond" }, { x: 610, y: 330, r: 36, name: "kolam lava", kind: "pond" },
    { x: 60, y: 420, r: 20, name: "batu", kind: "rock" }, { x: 230, y: 480, r: 20, name: "batu", kind: "rock" },
    { x: 430, y: 260, r: 20, name: "batu", kind: "rock" }, { x: 620, y: 60, r: 20, name: "batu", kind: "rock" },
    { x: 780, y: 230, r: 20, name: "batu", kind: "rock" }, { x: 800, y: 475, r: 20, name: "batu", kind: "rock" }
  ]
};
mapDefs.crystal = {
  id: "crystal", name: "Gua Kristal", icon: "💎", stars: 4, hpMult: 1.75, gemMult: 2.0, flyFrom: 4, flyW: 0.18,
  desc: "Gua bercahaya dengan jalur memutar panjang. Musuh sangat kuat, tetapi hadiahnya besar.",
  theme: { bg: "#182d45", spotA: "#1e405c", spotB: "#243a63", edge: "#3a6b8a", road: "#6b718f", dash: "#b0c5df", water: "#45e0e5", rim: "#296b84", shine: "#d6ffff99", rockA: "#49607d", rockB: "#82a7c7", base: "gate" },
  path: [{ x: -20, y: 110 }, { x: 180, y: 110 }, { x: 180, y: 410 }, { x: 370, y: 410 }, { x: 370, y: 90 }, { x: 570, y: 90 }, { x: 570, y: 430 }, { x: 760, y: 430 }, { x: 760, y: 250 }, { x: 856, y: 250 }],
  obstacles: [
    { x: 75, y: 300, r: 25, name: "kristal", kind: "rock" }, { x: 270, y: 210, r: 30, name: "kristal", kind: "rock" },
    { x: 470, y: 270, r: 28, name: "kristal", kind: "rock" }, { x: 680, y: 150, r: 26, name: "kristal", kind: "rock" },
    { x: 820, y: 380, r: 28, name: "danau kristal", kind: "pond" }, { x: 90, y: 475, r: 20, name: "batu", kind: "rock" },
    { x: 480, y: 485, r: 20, name: "batu", kind: "rock" }
  ]
};
mapDefs.halloween = {
  id: "halloween", event: true, name: "Lembah Hantu", icon: "🎃", stars: 3, hpMult: 1.35, gemMult: 1.3, flyFrom: 2, flyW: 0.22,
  desc: "EVENT HALLOWEEN: jalur tangga berliku di pemakaman berkabut. Banyak kelelawar! Hadiah Halloween Coin 🎃.",
  theme: { bg: "#2b2040", spotA: "#35274d", spotB: "#221833", edge: "#4c2f6e", road: "#74647f", dash: "#a698b4", water: "#74ff74", rim: "#2f6b34", shine: "#ccffcc77", base: "gate" },
  path: [{ x: -20, y: 430 }, { x: 140, y: 430 }, { x: 140, y: 250 }, { x: 300, y: 250 }, { x: 300, y: 100 }, { x: 460, y: 100 }, { x: 460, y: 420 }, { x: 620, y: 420 }, { x: 620, y: 180 }, { x: 760, y: 180 }, { x: 760, y: 300 }, { x: 856, y: 300 }],
  obstacles: [
    { x: 60, y: 300, r: 18, name: "batu nisan", kind: "tomb" }, { x: 220, y: 350, r: 18, name: "batu nisan", kind: "tomb" },
    { x: 540, y: 60, r: 18, name: "batu nisan", kind: "tomb" }, { x: 240, y: 485, r: 18, name: "batu nisan", kind: "tomb" }, { x: 800, y: 470, r: 18, name: "batu nisan", kind: "tomb" },
    { x: 220, y: 170, r: 24, name: "pohon mati", kind: "deadtree" }, { x: 380, y: 250, r: 24, name: "pohon mati", kind: "deadtree" }, { x: 700, y: 400, r: 24, name: "pohon mati", kind: "deadtree" },
    { x: 380, y: 370, r: 18, name: "labu", kind: "pumpkin" }, { x: 60, y: 120, r: 18, name: "labu", kind: "pumpkin" }, { x: 830, y: 120, r: 18, name: "labu", kind: "pumpkin" }, { x: 60, y: 490, r: 18, name: "labu", kind: "pumpkin" },
    { x: 540, y: 300, r: 34, name: "kuali beracun", kind: "pond" }
  ]
};
mapDefs.raid = {
  id: "raid", raid: true, name: "Arena Raid", icon: "👹", stars: 4, hpMult: 1.5, gemMult: 0,
  desc: "Arena kuno tempat Raid Boss menunggu. 10 wave penuh bos!",
  theme: { bg: "#2a1a24", spotA: "#33202c", spotB: "#22141c", edge: "#7a2340", road: "#6b5560", dash: "#a58a97", water: "#ff3d6e", rim: "#5a1830", shine: "#ffb3c677", rockA: "#3b2a33", rockB: "#5d4553", base: "gate" },
  path: [{ x: -20, y: 260 }, { x: 200, y: 260 }, { x: 200, y: 120 }, { x: 420, y: 120 }, { x: 420, y: 400 }, { x: 640, y: 400 }, { x: 640, y: 200 }, { x: 856, y: 200 }],
  obstacles: [
    { x: 60, y: 110, r: 20, name: "pilar", kind: "pillar" }, { x: 60, y: 430, r: 20, name: "pilar", kind: "pillar" },
    { x: 310, y: 300, r: 22, name: "batu", kind: "rock" }, { x: 530, y: 250, r: 22, name: "batu", kind: "rock" },
    { x: 530, y: 60, r: 20, name: "pilar", kind: "pillar" }, { x: 760, y: 340, r: 34, name: "kolam darah", kind: "pond" },
    { x: 310, y: 470, r: 20, name: "pilar", kind: "pillar" }, { x: 790, y: 80, r: 22, name: "batu", kind: "rock" }
  ]
};
const mapKeys = Object.keys(mapDefs).filter(k => !mapDefs[k].raid);
const PATH_HALF_WIDTH = 38;
let map, path, BASE, PATH_LENGTH, FLY_LENGTH, obstacles;
function setMap(id) {
  map = mapDefs[id] || mapDefs.forest;
  path = map.path;
  BASE = path[path.length - 1];
  PATH_LENGTH = path.slice(1).reduce((sum, p, i) => sum + Math.hypot(p.x - path[i].x, p.y - path[i].y), 0);
  FLY_LENGTH = Math.hypot(BASE.x - path[0].x, BASE.y - path[0].y);
  obstacles = map.obstacles.concat([{ x: BASE.x, y: BASE.y - 27, r: 44, name: "markas", kind: "base" }]);
  bgCache = null;
}

// ---------- Mode kesulitan ----------
const diffDefs = {
  easy:   { name: "Easy",   icon: "🌱", hp: 0.75, spd: 0.92, lives: 20, gold: 300, bonus: 1.25, reward: 0.6, desc: "Musuh lemah & lambat" },
  medium: { name: "Medium", icon: "⚔️", hp: 1.0,  spd: 1.0,  lives: 15, gold: 240, bonus: 1.0,  reward: 1.0, desc: "Standar" },
  hard:   { name: "Hard",   icon: "🔥", hp: 1.35, spd: 1.08, lives: 10, gold: 190, bonus: 0.9,  reward: 1.5, desc: "Musuh tebal, nyawa tipis" },
  insane: { name: "Insane", icon: "💀", hp: 1.7,  spd: 1.15, lives: 6,  gold: 150, bonus: 0.8,  reward: 2.5, desc: "Hampir mustahil" }
};
const diffKeys = Object.keys(diffDefs);
function diff() { return diffDefs[save.diff] || diffDefs.medium; }
function bestKey(id) { return !save.diff || save.diff === "medium" || !diffDefs[save.diff] ? id : `${id}@${save.diff}`; }
function bestOf(id) { return save.mapBest[bestKey(id)] || 0; }

// ---------- State ----------
let health, gold, wave, towers, enemies, bullets, friendlyUnits, poisonPuddles, fx, meteors;
let selectedType, selectedTower, hover, meteorArmed, meteorCooldown;
let waveActive, paused, gameOver, speed, spawnQueue, spawnTimer, lastTime, animationId;
let adminGod = false, adminUnlocked = false, autoTimer = 0, runMode = "normal", lastCrystals = 0, runTokens = 0;
let wavePlans, kills, baseFlash, moonFlash, lastCoins = 0, totalGoldEarned, loadout = ["archer"], runRewarded = false;

function resetGame() {
  autoTimer = 0; runTokens = 0; lastCrystals = 0; health = diff().lives; gold = diff().gold; wave = 0; kills = 0; totalGoldEarned = 0;
  towers = []; enemies = []; bullets = []; friendlyUnits = []; poisonPuddles = []; fx = []; meteors = [];
  selectedType = loadout[0]; selectedTower = null; hover = null; runRewarded = false;
  meteorArmed = false; meteorCooldown = 12; baseFlash = 0; moonFlash = 0;
  waveActive = false; paused = false; gameOver = false; speed = 1;
  spawnQueue = []; spawnTimer = 0; lastTime = 0;
  wavePlans = Array.from({ length: MAX_WAVE }, (_, i) => buildWavePlan(i + 1));
  document.querySelectorAll(".tower-btn").forEach(b => b.classList.toggle("selected", b.dataset.tower === selectedType));
  ui.overlay.classList.remove("hidden");
  ui.overlayTitle.textContent = `${map.icon} ${map.name} • ${diff().icon} ${diff().name}`;
  const best = bestOf(map.id);
  ui.overlayText.textContent = (best ? `Rekormu di sini: ${best >= MAX_WAVE ? "menang!" : "wave " + best}. ` : "") + (map.raid ? "RAID: 10 wave penuh bos. Raid Boss menunggu di wave 10! Hadiah: 🔷 Crystal." : "Pasang tower di rumput, lalu mulai wave pertama.");
  ui.startBtn.textContent = "Mulai permainan";
  ui.pauseBtn.textContent = "⏸ Jeda";
  ui.message.textContent = "Tips: Ice memperlambat musuh, Cannon & Poison tidak bisa kena musuh terbang 🦇, BARACK dibatasi 2 regu aktif.";
  ui.canvasWrap && ui.canvasWrap.classList.remove("armed");
  renderDiff();
  updateUI();
  draw();
}

// ---------- Helper ----------
function distance(a, b) { return Math.hypot(a.x - b.x, a.y - b.y); }
function setText(el, value) { value = String(value); if (el.textContent !== value) el.textContent = value; }
function setHTML(el, value) { if (el.dataset.last !== value) { el.dataset.last = value; el.innerHTML = value; } }
function maxLevel(tower) { return towerTypes[tower.type].maxLevel || 5; }
function upgradeCost(tower) {
  if (!tower || tower.level >= maxLevel(tower)) return Infinity;
  return Math.round(towerTypes[tower.type].cost * tower.level * 0.7);
}
function sellValue(tower) { return Math.floor(tower.spent * 0.65); }
function levelData(tower) { const t = towerTypes[tower.type]; return t.levels ? t.levels[tower.level - 1] : null; }
// Aura Totem: tower di dalam jangkauan mendapat bonus damage / kecepatan.
function towerBuff(tower) {
  let d = 0, r = 0;
  for (const o of towers) {
    if (o === tower) continue;
    if (o.type === "totem") {
      const lv = levelData(o);
      if (distance(o, tower) <= lv.range) { d = Math.max(d, lv.dmgBuff); r = Math.max(r, lv.rateBuff); }
    } else if (o.type === "chrono") {
      const lv = levelData(o);
      if (distance(o, tower) <= lv.range) r = Math.max(r, lv.rateBuff);
    } else if (o.type === "bloodmoon") { // buff global
      const lv = levelData(o);
      d = Math.max(d, lv.dmgBuff); r = Math.max(r, lv.rateBuff);
    }
  }
  return { d, r };
}
function baseDamage(tower) {
  const lv = levelData(tower);
  return lv ? lv.damage : Math.round(towerTypes[tower.type].damage * (1 + (tower.level - 1) * 0.6));
}
function towerDamage(tower) { return Math.round(baseDamage(tower) * (1 + towerBuff(tower).d)); }
function towerRange(tower) {
  const lv = levelData(tower);
  return lv ? (lv.range || 0) : Math.round(towerTypes[tower.type].range * (1 + (tower.level - 1) * 0.05));
}
function towerRate(tower) {
  const lv = levelData(tower);
  const base = lv ? lv.rate : towerTypes[tower.type].rate * (1 - (tower.level - 1) * 0.05);
  return base / (1 + towerBuff(tower).r);
}
function barrackRoster(level) {
  if (level === 1) return "3 Ksatria";
  if (level === 2) return "4 Ksatria + 2 Pemanah";
  return "4 Ksatria + 2 Pemanah Elite + 1 Gladiator";
}

function segmentPoint(x, y, a, b) {
  const dx = b.x - a.x, dy = b.y - a.y;
  const length2 = dx * dx + dy * dy;
  const t = Math.max(0, Math.min(1, ((x - a.x) * dx + (y - a.y) * dy) / length2));
  return { x: a.x + t * dx, y: a.y + t * dy };
}
function nearestPathPoint(x, y) {
  let best = null, bestD = Infinity;
  for (let i = 0; i < path.length - 1; i++) {
    const p = segmentPoint(x, y, path[i], path[i + 1]);
    const d = Math.hypot(x - p.x, y - p.y);
    if (d < bestD) { bestD = d; best = p; }
  }
  return best;
}
function pointOnPath(x, y) {
  const p = nearestPathPoint(x, y);
  return Math.hypot(x - p.x, y - p.y) < PATH_HALF_WIDTH;
}
function canPlace(p) {
  if (p.x < 22 || p.x > W - 22 || p.y < 22 || p.y > H - 22) return "Terlalu dekat tepi peta.";
  if (pointOnPath(p.x, p.y)) return "Tower tidak bisa dipasang di jalan. Cari area rumput!";
  const ob = obstacles.find(o => distance(o, p) < o.r + 16);
  if (ob) return `Ada ${ob.name} di sini. Pilih tempat lain.`;
  if (towers.some(t => distance(t, p) < 42)) return "Terlalu dekat dengan tower lain. Beri sedikit jarak.";
  return null;
}
function canvasPoint(event) {
  const rect = canvas.getBoundingClientRect();
  return {
    x: (event.clientX - rect.left) * canvas.width / rect.width,
    y: (event.clientY - rect.top) * canvas.height / rect.height
  };
}

// ---------- Suara (WebAudio, semua disintesis lewat kode) ----------
let audioCtx = null, audioOut = null, noiseBuf = null, audioSynth = null;
const lastSfx = {}, recentSfx = [];

function makeSynth(ac, out, noiseBuffer) {
  const self = { k: 1 };
  const tone = (f, d, o = {}) => {
    const t0 = ac.currentTime + (o.at || 0), osc = ac.createOscillator(), g = ac.createGain();
    osc.type = o.type || "sine";
    osc.frequency.setValueAtTime(f, t0);
    if (o.to) osc.frequency.exponentialRampToValueAtTime(Math.max(20, o.to), t0 + d);
    if (o.vib) {
      const l = ac.createOscillator(), lg = ac.createGain();
      l.frequency.value = o.vib; lg.gain.value = f * 0.04; l.connect(lg); lg.connect(osc.frequency); l.start(t0); l.stop(t0 + d + 0.05);
    }
    const vol = (o.vol == null ? 0.06 : o.vol) * self.k;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol, t0 + (o.att || 0.005));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    if (o.lp) { const f2 = ac.createBiquadFilter(); f2.type = "lowpass"; f2.frequency.value = o.lp; osc.connect(f2); f2.connect(g); } else osc.connect(g);
    g.connect(out); osc.start(t0); osc.stop(t0 + d + 0.03);
  };
  const noise = (d, o = {}) => {
    const t0 = ac.currentTime + (o.at || 0), src = ac.createBufferSource(), g = ac.createGain(), f = ac.createBiquadFilter();
    src.buffer = noiseBuffer; src.loop = true;
    f.type = o.type || "lowpass"; f.Q.value = o.q || 0.8;
    f.frequency.setValueAtTime(o.f || 1000, t0);
    if (o.to) f.frequency.exponentialRampToValueAtTime(Math.max(30, o.to), t0 + d);
    const vol = (o.vol == null ? 0.06 : o.vol) * self.k;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol, t0 + (o.att || 0.004));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    src.connect(f); f.connect(g); g.connect(out); src.start(t0, Math.random() * 0.8); src.stop(t0 + d + 0.03);
  };
  self.tone = tone; self.noise = noise;
  return self;
}
// Penyetel volume otomatis per suara (hasil pengukuran) agar semua seimbang
const sfxTrim = {"click":2.17,"tab":2.58,"equip":2.78,"buy":1.16,"error":2.24,"start":1.85,"place":1.03,"upgrade":2.34,"sell":1.34,"token":1.47,"evolve":1.3,"wave":1.78,"bosswarn":1.24,"roar":0.95,"leak":0.69,"meteor":0.49,"nova":0.82,"inferno":0.62,"volley":2.38,"win":0.55,"lose":2.38,"gacha:common":3.0,"gacha:uncommon":3.0,"gacha:rare":3.0,"gacha:legend":1.87,"gacha:mythical":1.45,"gacha:secret":1.35,"kill:slime":1.14,"kill:runner":1.47,"kill:tank":0.51,"kill:flyer":1.25,"kill:boss":0.46,"kill:raidboss":0.54,"boom":1.04,"shoot":3.0,"t_archer":1.07,"t_crossbow":1.36,"t_cannon":0.53,"t_titan":0.55,"t_mortar":0.81,"t_ice":1.26,"t_slinger":1.6,"t_petasan":1.2,"t_howitzer":0.5,"t_blizzard":1.2,"t_storm":0.9,"t_railgun":0.5,"t_poison":1.6,"t_toxic":1.07,"t_magic":2.29,"t_sniper":0.44,"t_tesla":0.92,"t_flame":1.4,"t_blazed":1.04,"t_ballista":0.56,"t_hexer":0.88,"t_druid":1.22,"t_witch":2.21,"t_vampire":1.54,"t_phoenix":1.89,"t_reaper":0.51,"t_ghost":2.79,"t_pumpkin":0.77,"t_candle":1.21,"t_web":1.58,"t_chrono":3.0,"t_tower":3.0};

// Perpustakaan bunyi: tiap entri (S = synth, a = argumen varian)
const sfxLib = {
  // ---- UI ----
  click:  S => { S.tone(900, 0.05, { type: "triangle", to: 620, vol: 0.05 }); },
  tab:    S => { S.tone(520, 0.05, { type: "triangle", vol: 0.04 }); S.tone(780, 0.06, { type: "triangle", vol: 0.04, at: 0.04 }); },
  equip:  S => { S.tone(440, 0.06, { type: "square", vol: 0.03, lp: 2500 }); S.tone(660, 0.09, { type: "square", vol: 0.03, lp: 2500, at: 0.05 }); },
  buy:    S => { S.tone(1318, 0.09, { type: "square", vol: 0.04, lp: 4000 }); S.tone(1760, 0.2, { type: "square", vol: 0.04, lp: 4000, at: 0.08 }); S.noise(0.12, { type: "highpass", f: 6000, vol: 0.02, at: 0.08 }); },
  error:  S => { S.tone(150, 0.12, { type: "sawtooth", vol: 0.05, lp: 700 }); S.tone(120, 0.16, { type: "sawtooth", vol: 0.05, lp: 700, at: 0.1 }); },
  start:  S => { S.tone(262, 0.12, { type: "square", vol: 0.04, lp: 2200 }); S.tone(392, 0.12, { type: "square", vol: 0.04, lp: 2200, at: 0.1 }); S.tone(523, 0.25, { type: "square", vol: 0.045, lp: 2200, at: 0.2 }); },
  // ---- Aksi di game ----
  place:  S => { S.tone(190, 0.14, { to: 80, vol: 0.12 }); S.noise(0.06, { type: "bandpass", f: 1800, vol: 0.05 }); S.tone(660, 0.1, { type: "triangle", vol: 0.04, at: 0.06 }); },
  upgrade:S => { [523, 659, 784, 1047].forEach((f, i) => S.tone(f, 0.12, { type: "triangle", vol: 0.055, at: i * 0.06 })); S.noise(0.25, { type: "highpass", f: 7000, vol: 0.02, at: 0.15 }); },
  sell:   S => { S.tone(1568, 0.07, { type: "square", vol: 0.035, lp: 4500 }); S.tone(2093, 0.16, { type: "square", vol: 0.035, lp: 4500, at: 0.06 }); S.noise(0.1, { type: "highpass", f: 5000, vol: 0.025 }); },
  token:  S => { [1568, 2093, 2637].forEach((f, i) => S.tone(f, 0.18, { type: "sine", vol: 0.06, at: i * 0.07 })); S.noise(0.3, { type: "highpass", f: 8000, vol: 0.02, at: 0.1 }); },
  evolve: S => {
    [262, 330, 392, 523].forEach((f, i) => { S.tone(f, 0.9, { type: "sawtooth", vol: 0.035, lp: 1800, at: i * 0.12 }); });
    [1047, 1319, 1568, 2093].forEach((f, i) => S.tone(f, 0.35, { type: "triangle", vol: 0.05, at: 0.45 + i * 0.08 }));
    S.noise(0.9, { type: "highpass", f: 5000, to: 9000, vol: 0.025, at: 0.4 }); S.tone(65, 0.7, { vol: 0.12, to: 40, at: 0.4 });
  },
  wave:   S => { S.tone(196, 0.45, { type: "sawtooth", vol: 0.05, lp: 900, att: 0.06 }); S.tone(294, 0.45, { type: "sawtooth", vol: 0.04, lp: 900, att: 0.06, at: 0.02 }); S.noise(0.12, { f: 200, vol: 0.12 }); S.noise(0.12, { f: 200, vol: 0.1, at: 0.22 }); },
  bosswarn: S => { S.tone(110, 0.8, { type: "sawtooth", vol: 0.07, lp: 500, att: 0.08, to: 92 }); S.tone(55, 0.9, { vol: 0.14, att: 0.1 }); S.noise(0.7, { f: 250, vol: 0.06 }); },
  roar:   S => { S.tone(95, 0.9, { type: "sawtooth", vol: 0.09, lp: 700, vib: 9, to: 58 }); S.tone(190, 0.8, { type: "square", vol: 0.04, lp: 600, vib: 11, to: 110 }); S.noise(0.9, { f: 900, to: 150, vol: 0.09 }); S.tone(50, 0.9, { vol: 0.14, att: 0.05 }); },
  leak:   S => { S.tone(110, 0.4, { to: 40, vol: 0.2 }); S.tone(170, 0.3, { type: "sawtooth", vol: 0.06, lp: 600, to: 70 }); S.noise(0.3, { f: 700, to: 100, vol: 0.12 }); },
  meteor: S => { S.tone(1100, 0.5, { to: 160, vol: 0.05 }); S.noise(0.55, { type: "bandpass", f: 2500, to: 300, vol: 0.04 }); S.noise(0.7, { f: 600, to: 60, vol: 0.2, at: 0.45 }); S.tone(80, 0.7, { to: 28, vol: 0.22, at: 0.45 }); },
  nova:   S => { S.tone(110, 1.0, { vol: 0.1, att: 0.02 }); S.tone(165, 1.0, { vol: 0.07, att: 0.02 }); S.tone(55, 1.0, { vol: 0.14, to: 38 }); S.noise(0.9, { type: "bandpass", f: 1200, to: 200, vol: 0.06 }); S.tone(1760, 0.5, { type: "triangle", vol: 0.03, at: 0.05 }); },
  inferno:S => { S.noise(0.9, { type: "bandpass", f: 300, to: 1800, q: 0.6, vol: 0.16 }); S.noise(0.7, { f: 500, to: 80, vol: 0.2, at: 0.25 }); S.tone(70, 0.8, { to: 32, vol: 0.2, at: 0.2 }); S.tone(220, 0.6, { type: "sawtooth", vol: 0.04, lp: 700, to: 110 }); },
  volley: S => { [0, 0.05, 0.1].forEach(at => { S.tone(170, 0.14, { type: "sawtooth", vol: 0.045, lp: 1300, to: 70, at }); S.noise(0.08, { type: "bandpass", f: 2600, vol: 0.05, at }); }); },
  win:    S => { const n = [523, 659, 784, 1047]; n.forEach((f, i) => { S.tone(f, 0.25, { type: "square", vol: 0.045, lp: 3000, at: i * 0.13 }); S.tone(f / 2, 0.25, { type: "triangle", vol: 0.05, at: i * 0.13 }); }); [1047, 1319, 1568].forEach(f => S.tone(f, 1.1, { type: "triangle", vol: 0.05, at: 0.55 })); S.noise(0.8, { type: "highpass", f: 7000, vol: 0.02, at: 0.55 }); },
  lose:   S => { [392, 370, 330, 262].forEach((f, i) => S.tone(f, 0.4, { type: "sawtooth", vol: 0.05, lp: 900, at: i * 0.28, vib: 5 })); S.tone(65, 1.2, { vol: 0.12, to: 40, at: 0.8 }); },
  gacha:  (S, r) => {
    const sets = { common: [660], uncommon: [660, 880], rare: [660, 880, 1100], legend: [523, 659, 784, 1047, 1319], mythical: [392, 523, 659, 784, 1047, 1319, 1568], secret: [196, 262, 330, 392, 523, 659, 784, 1047, 1319, 1568, 2093] };
    const n = sets[r] || sets.common;
    n.forEach((f, i) => S.tone(f, 0.35, { type: "triangle", vol: 0.05, at: i * 0.09 }));
    if (r === "legend" || r === "mythical" || r === "secret") { S.noise(1.0, { type: "highpass", f: 6000, to: 10000, vol: 0.03, at: 0.2 }); S.tone(98, 1.0, { vol: 0.12 }); }
    if (r === "mythical" || r === "secret") S.tone(r === "secret" ? 55 : 82, 1.4, { type: "sawtooth", vol: 0.06, lp: 400, vib: 4 });
    if (r === "secret") { [1568, 2093, 2637].forEach((f, i) => S.tone(f, 0.8, { type: "sine", vol: 0.05, at: 0.9 + i * 0.1 })); S.tone(40, 1.6, { vol: 0.2, at: 0.6 }); }
  },
  // ---- Kematian musuh (varian per jenis) ----
  kill:   (S, k) => {
    if (k === "boss" || k === "raidboss") { S.tone(100, 0.6, { to: 35, vol: 0.2 }); S.noise(0.6, { f: 800, to: 90, vol: 0.18 }); S.tone(440, 0.35, { type: "triangle", vol: 0.04, to: 120, at: 0.05 }); if (k === "raidboss") S.tone(55, 1.2, { vol: 0.16, to: 30, at: 0.2 }); }
    else if (k === "tank") { S.tone(240, 0.12, { type: "square", vol: 0.04, lp: 1200, to: 120 }); S.noise(0.12, { type: "bandpass", f: 1500, vol: 0.06 }); S.tone(90, 0.22, { to: 45, vol: 0.12 }); }
    else if (k === "flyer") { S.tone(1300, 0.14, { type: "sawtooth", vol: 0.035, lp: 3000, to: 380 }); S.noise(0.08, { type: "highpass", f: 4000, vol: 0.03 }); }
    else if (k === "runner") { S.tone(950, 0.07, { type: "triangle", vol: 0.05, to: 480 }); S.noise(0.05, { type: "highpass", f: 5000, vol: 0.025 }); }
    else { S.tone(520, 0.09, { to: 190, vol: 0.07 }); S.tone(300, 0.07, { to: 150, vol: 0.04, at: 0.03 }); S.noise(0.05, { type: "bandpass", f: 900, vol: 0.03 }); }
  },
  boom:   S => { S.tone(105, 0.3, { to: 42, vol: 0.12 }); S.noise(0.28, { f: 800, to: 120, vol: 0.09 }); },
  shoot:  S => { S.tone(300, 0.05, { type: "square", vol: 0.02, lp: 1500 }); },
  // ---- Suara tembakan tiap unit ----
  t_archer:   S => { S.tone(240, 0.11, { type: "triangle", vol: 0.06, to: 110, lp: 1800 }); S.noise(0.07, { type: "bandpass", f: 2600, to: 1200, vol: 0.04 }); },
  t_crossbow: S => { S.tone(170, 0.13, { type: "sawtooth", vol: 0.05, lp: 1300, to: 70 }); S.noise(0.08, { type: "bandpass", f: 2200, vol: 0.05 }); S.tone(900, 0.04, { type: "square", vol: 0.02, at: 0.02, lp: 2000 }); },
  t_cannon:   S => { S.tone(125, 0.28, { to: 42, vol: 0.2 }); S.noise(0.26, { f: 1000, to: 140, vol: 0.14 }); },
  t_titan:    S => { S.tone(85, 0.5, { to: 30, vol: 0.26 }); S.noise(0.5, { f: 900, to: 90, vol: 0.18 }); S.tone(220, 0.25, { type: "sawtooth", vol: 0.04, lp: 600, to: 90 }); },
  t_mortar:   S => { S.tone(95, 0.22, { to: 48, vol: 0.17 }); S.noise(0.16, { f: 600, to: 120, vol: 0.1 }); S.tone(320, 0.28, { type: "triangle", vol: 0.03, to: 900, at: 0.06 }); },
  t_howitzer: S => { S.tone(90, 0.4, { to: 30, vol: 0.24 }); S.noise(0.4, { f: 800, to: 100, vol: 0.17 }); S.tone(180, 0.2, { type: "sawtooth", vol: 0.04, lp: 500, to: 60 }); },
  t_blizzard: S => { S.tone(1318, 0.3, { vol: 0.05 }); S.tone(1760, 0.3, { vol: 0.045, at: 0.04 }); S.tone(2349, 0.32, { vol: 0.035, at: 0.09 }); S.noise(0.12, { type: "highpass", f: 6000, vol: 0.04 }); },
  t_storm:    S => { S.tone(2000, 0.2, { type: "sawtooth", vol: 0.045, lp: 6000, to: 200 }); S.noise(0.2, { type: "bandpass", f: 2800, q: 2, vol: 0.08 }); S.tone(110, 0.25, { to: 50, vol: 0.1, at: 0.04 }); S.noise(0.1, { type: "highpass", f: 5000, vol: 0.05, at: 0.1 }); },
  t_railgun:  S => { S.tone(1800, 0.2, { type: "sawtooth", vol: 0.05, lp: 5000, to: 200 }); S.noise(0.06, { type: "highpass", f: 3000, vol: 0.12 }); S.tone(90, 0.3, { to: 40, vol: 0.12, at: 0.03 }); },
  intro:      S => { [262, 330, 392, 523, 659].forEach((f, i) => S.tone(f, 0.55, { type: "triangle", vol: 0.06, at: i * 0.09 })); S.tone(130, 0.9, { to: 65, vol: 0.12 }); S.noise(0.7, { type: "highpass", f: 3500, to: 900, vol: 0.05 }); },
  t_slinger:  S => { S.tone(260, 0.05, { type: "triangle", vol: 0.05, to: 520 }); S.noise(0.05, { type: "highpass", f: 3000, vol: 0.04, at: 0.04 }); S.tone(180, 0.07, { vol: 0.05, to: 120, at: 0.07 }); },
  t_petasan:  S => { S.noise(0.1, { type: "highpass", f: 5000, vol: 0.07 }); S.tone(160, 0.12, { type: "square", vol: 0.05, lp: 1200, to: 70, at: 0.03 }); S.noise(0.12, { f: 1500, to: 300, vol: 0.06, at: 0.05 }); },
  t_ice:      S => { S.tone(1568, 0.28, { vol: 0.05 }); S.tone(2093, 0.3, { vol: 0.04, at: 0.045 }); S.noise(0.08, { type: "highpass", f: 7000, vol: 0.03 }); },
  t_poison:   S => { S.tone(300, 0.1, { to: 720, vol: 0.06 }); S.tone(380, 0.09, { to: 820, vol: 0.05, at: 0.07 }); S.noise(0.1, { type: "bandpass", f: 700, vol: 0.04 }); },
  t_toxic:    S => { S.tone(220, 0.14, { to: 640, vol: 0.07 }); S.tone(300, 0.1, { to: 900, vol: 0.05, at: 0.08 }); S.noise(0.16, { type: "bandpass", f: 600, to: 1600, vol: 0.06 }); S.tone(120, 0.18, { type: "sawtooth", vol: 0.03, lp: 500 }); },
  t_magic:    S => { S.tone(880, 0.16, { type: "triangle", vol: 0.05, to: 1760 }); S.tone(1320, 0.12, { type: "sine", vol: 0.04, at: 0.06 }); S.noise(0.1, { type: "highpass", f: 8000, vol: 0.02, at: 0.04 }); },
  t_sniper:   S => { S.noise(0.07, { type: "highpass", f: 2200, vol: 0.14 }); S.tone(640, 0.16, { to: 85, vol: 0.12 }); S.noise(0.25, { f: 500, to: 120, vol: 0.05, at: 0.07 }); },
  t_tesla:    S => { S.tone(2200, 0.15, { type: "sawtooth", vol: 0.045, lp: 6000, to: 260 }); S.noise(0.13, { type: "bandpass", f: 3200, q: 2, vol: 0.07 }); S.noise(0.08, { type: "highpass", f: 5000, vol: 0.05, at: 0.06 }); },
  t_flame:    S => { S.noise(0.2, { type: "bandpass", f: 450, to: 1500, q: 0.7, vol: 0.1 }); S.tone(90, 0.18, { type: "sawtooth", vol: 0.03, lp: 400 }); },
  t_blazed:   S => { S.noise(0.26, { type: "bandpass", f: 350, to: 1900, q: 0.6, vol: 0.13 }); S.tone(75, 0.24, { type: "sawtooth", vol: 0.05, lp: 400, to: 50 }); S.noise(0.1, { type: "highpass", f: 4500, vol: 0.03, at: 0.08 }); },
  t_ballista: S => { S.noise(0.06, { type: "bandpass", f: 1500, vol: 0.09 }); S.tone(210, 0.14, { to: 70, vol: 0.14 }); S.noise(0.14, { type: "bandpass", f: 3000, to: 900, vol: 0.04, at: 0.03 }); },
  t_hexer:    S => { S.tone(210, 0.22, { type: "sawtooth", vol: 0.05, lp: 650, to: 130, vib: 12 }); S.tone(88, 0.25, { vol: 0.08 }); S.noise(0.12, { type: "bandpass", f: 500, vol: 0.03 }); },
  t_druid:    S => { S.tone(660, 0.14, { type: "sine", vol: 0.05, to: 880, vib: 8 }); S.noise(0.12, { type: "bandpass", f: 3200, q: 1.5, vol: 0.04 }); },
  t_witch:    S => { S.tone(420, 0.09, { to: 900, vol: 0.05 }); S.tone(520, 0.09, { to: 1050, vol: 0.05, at: 0.08 }); S.noise(0.12, { type: "bandpass", f: 900, vol: 0.04, at: 0.02 }); },
  t_vampire:  S => { S.noise(0.07, { type: "bandpass", f: 2600, q: 2, vol: 0.05 }); S.noise(0.07, { type: "bandpass", f: 2900, q: 2, vol: 0.05, at: 0.09 }); S.tone(1500, 0.1, { type: "triangle", vol: 0.03, to: 800, at: 0.03 }); },
  t_phoenix:  S => { S.tone(1300, 0.2, { type: "sawtooth", vol: 0.035, lp: 4000, to: 2300 }); S.noise(0.18, { type: "bandpass", f: 500, to: 1700, vol: 0.08 }); S.tone(1900, 0.12, { type: "sine", vol: 0.03, at: 0.1 }); },
  t_reaper:   S => { S.noise(0.16, { type: "highpass", f: 3500, to: 1500, vol: 0.07 }); S.tone(520, 0.24, { type: "triangle", vol: 0.05, to: 120 }); S.tone(220, 0.8, { vol: 0.05, at: 0.08, vib: 5 }); },
  t_ghost:    S => { S.tone(650, 0.3, { vol: 0.04, vib: 7, to: 900 }); S.tone(980, 0.3, { vol: 0.02, vib: 6, at: 0.05 }); },
  t_pumpkin:  S => { S.tone(210, 0.16, { to: 75, vol: 0.12 }); S.noise(0.12, { type: "bandpass", f: 700, vol: 0.07 }); },
  t_candle:   S => { S.noise(0.06, { type: "highpass", f: 4200, vol: 0.04 }); S.tone(1900, 0.05, { type: "triangle", vol: 0.03 }); S.tone(2400, 0.04, { type: "triangle", vol: 0.02, at: 0.03 }); },
  t_web:      S => { S.noise(0.06, { type: "bandpass", f: 2200, vol: 0.04 }); S.tone(900, 0.07, { type: "triangle", vol: 0.03, to: 1700 }); },
  t_chrono:   S => { S.tone(1300, 0.04, { type: "square", vol: 0.03, lp: 3000 }); S.tone(980, 0.05, { type: "square", vol: 0.03, lp: 3000, at: 0.07 }); },
  t_tower:    S => { S.tone(300, 0.05, { type: "square", vol: 0.02, lp: 1500 }); }
};
const sfxQuiet = name => name.startsWith("t_") || name === "kill" || name === "shoot";

function sfx(name, arg) {
  if (save.muted) return;
  const now = Date.now();
  const gap = name.startsWith("t_") ? 45 : name === "kill" ? 38 : name === "click" ? 25 : 60;
  if (lastSfx[name] && now - lastSfx[name] < gap) return;
  lastSfx[name] = now;
  try {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    if (!audioCtx) {
      audioCtx = new AC();
      const comp = audioCtx.createDynamicsCompressor(); comp.threshold.value = -16; comp.ratio.value = 5;
      audioOut = audioCtx.createGain(); audioOut.gain.value = 0.9;
      audioOut.connect(comp); comp.connect(audioCtx.destination);
      noiseBuf = audioCtx.createBuffer(1, audioCtx.sampleRate, audioCtx.sampleRate);
      const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      audioSynth = makeSynth(audioCtx, audioOut, noiseBuf);
    }
    if (audioCtx.state === "suspended") audioCtx.resume();
    // batasi ledakan suara: efek 'kecil' dilewati kalau sudah terlalu ramai
    while (recentSfx.length && now - recentSfx[0] > 120) recentSfx.shift();
    if (sfxQuiet(name) && recentSfx.length > 9) return;
    recentSfx.push(now);
    const fn = sfxLib[name] || (name.startsWith("t_") ? sfxLib.t_tower : null);
    if (fn) { audioSynth.k = sfxTrim[arg ? `${name}:${arg}` : name] || 1; fn(audioSynth, arg); }
  } catch (e) { /* suara opsional */ }
}

// ---------- Efek visual ----------
function addText(x, y, text, color = "#fff", size = 13) {
  if (fx.length > 160) return;
  fx.push({ k: "text", x, y, text, color, size, life: 0.85, max: 0.85 });
}
function addRing(x, y, r, color, life = 0.35) { fx.push({ k: "ring", x, y, r, color, life, max: life }); }
function addZap(a, b, color, life = 0.14) { fx.push({ k: "zap", x: a.x, y: a.y, x2: b.x, y2: b.y, color, life, max: life }); }
function addSlash(tower, e, color) {
  fx.push({ k: "slash", x: e.x, y: e.y, ang: Math.atan2(e.y - tower.y, e.x - tower.x), color, life: 0.3, max: 0.3 });
}
function addArrow(a, b, color, life = 0.2, w = 3, ext) {
  fx.push({ k: "arrow", x: a.x, y: a.y, x2: b.x, y2: b.y, color, life, max: life, w });
}
function addJet(a, b, c1, c2, life = 0.28) { fx.push({ k: "jet", x: a.x, y: a.y, x2: b.x, y2: b.y, color: c1, color2: c2, life, max: life }); }
function addBurst(x, y, color, n = 8) {
  for (let i = 0; i < n && fx.length < 220; i++) {
    const ang = Math.random() * Math.PI * 2, sp = 40 + Math.random() * 90;
    fx.push({ k: "spark", x, y, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp - 30, color, life: 0.5, max: 0.5 });
  }
}
function updateFx(step) {
  for (const f of fx) {
    f.life -= step;
    if (f.k === "text") f.y -= 24 * step;
    if (f.k === "spark") { f.x += f.vx * step; f.y += f.vy * step; f.vy += 160 * step; }
  }
  fx = fx.filter(f => f.life > 0);
}

// ---------- Wave ----------
function baseHp(n) { return 30 + n * 8 + n * n * 2.6; }

function buildRaidPlan(n) {
  const total = 8 + n * 2, plan = [];
  const tankW = n >= 2 ? 0.3 : 0.1, flyW = n >= 3 ? 0.12 : 0, runW = 0.18;
  for (let i = 0; i < total; i++) {
    const r = Math.random();
    plan.push(r < tankW ? "tank" : r < tankW + flyW ? "flyer" : r < tankW + flyW + runW ? "runner" : "slime");
  }
  const bosses = n >= 3 ? Math.floor(n / 3) : 0;
  for (let b = 0; b < bosses; b++) plan[Math.floor(total * (b + 1) / (bosses + 1))] = "boss";
  if (n === MAX_WAVE) plan[total - 1] = "raidboss";
  return plan;
}
function buildWavePlan(n) {
  if (map.raid) return buildRaidPlan(n);
  const total = 6 + n * 2;
  const tankW = n >= 4 ? 0.18 : 0, flyW = n >= (map.flyFrom || 3) ? (map.flyW || 0.16) : 0, runW = n >= 2 ? 0.2 : 0;
  const plan = [];
  for (let i = 0; i < total; i++) {
    const r = Math.random();
    if (r < tankW) plan.push("tank");
    else if (r < tankW + flyW) plan.push("flyer");
    else if (r < tankW + flyW + runW) plan.push("runner");
    else plan.push("slime");
  }
  if (n === 5 || n >= 7) plan[total - 1] = "boss";
  if (n === 10) plan[Math.floor(total / 2)] = "boss";
  return plan;
}
function countPlan(plan) {
  const counts = {};
  plan.forEach(t => { counts[t] = (counts[t] || 0) + 1; });
  return counts;
}
function planText(plan) {
  const counts = countPlan(plan);
  return Object.keys(enemyTypes).filter(k => counts[k]).map(k => `<span class="chip" title="${enemyTypes[k].label}">${enemyTypes[k].icon} ×${counts[k]}</span>`).join(" ");
}

function beginWave() {
  if (waveActive || gameOver || wave >= MAX_WAVE) return;
  wave++;
  waveActive = true;
  spawnQueue = wavePlans[wave - 1].slice();
  spawnTimer = 0;
  ui.message.textContent = `Wave ${wave} dimulai! Bersiap menghadapi ${spawnQueue.length} musuh.`;
  ui.overlay.classList.add("hidden");
  sfx("wave");
  updateUI();
}

function spawnEnemy(typeKey) {
  const t = enemyTypes[typeKey];
  if (t.boss) sfx(typeKey === "raidboss" ? "roar" : "bosswarn");
  const maxHp = Math.round(baseHp(wave) * t.hp * map.hpMult * diff().hp);
  enemies.push({
    type: typeKey, flying: !!t.flying, evasive: !!t.evasive, boss: !!t.boss,
    x: path[0].x, y: path[0].y, pathIndex: 0, dist: 0, progress: 0,
    total: t.flying ? FLY_LENGTH : PATH_LENGTH,
    hp: maxHp, maxHp, armor: t.armor, dmg: t.dmg,
    speed: (t.speed + wave * (t.boss ? 0.6 : 1.5)) * diff().spd,
    reward: t.reward, radius: t.radius, color: t.color, leak: t.leak || 1, corrodeTimer: 0, corrode: 0,
    slowTimer: 0, slowFactor: 1, freezeTimer: 0, poisonTimer: 0, poisonDamage: 0, burnTimer: 0, burnDps: 0, hexTimer: 0, hexAmp: 0,
    attackCd: 0, attackFlash: 0, hitFlash: 0, t: Math.random() * 6
  });
}

// ---------- Damage ----------
function damageEnemy(e, amount, opts = {}) {
  if (e.hp <= 0) return;
  const armor = e.corrodeTimer > 0 ? Math.max(0, e.armor - e.corrode) : e.armor;
  const real = amount * (e.hexTimer > 0 ? 1 + e.hexAmp : 1) * (1 - (opts.pierce ? 0 : armor));
  e.hp -= real;
  if (!opts.dot) e.hitFlash = 0.1;
  if (!opts.dot && real >= 20) addText(e.x + (Math.random() * 10 - 5), e.y - e.radius - 10, Math.round(real), "#fff3b0", 12);
}
function enemyTargetable(e, air) { return e.hp > 0 && (air || !e.flying); }

// ---------- BARACK ----------
function spawnBarrackSquad(barrack) {
  const livingSquads = new Set(friendlyUnits.filter(u => u.barrackId === barrack.id).map(u => u.squadId));
  if (livingSquads.size >= 2) return;
  const level = barrack.level;
  const squadId = `${barrack.id}-${Date.now()}-${Math.random()}`;
  let slot = 0;
  const make = (kind, count, upgraded = false) => {
    for (let i = 0; i < count; i++, slot++) {
      const maxHp = kind === "gladiator" ? 180 : kind === "knight" ? 94 : upgraded ? 46 : 30;
      friendlyUnits.push({
        kind, upgraded, barrackId: barrack.id, squadId,
        x: barrack.x, y: barrack.y + 18,
        rally: barrack.rally,
        ox: ((slot % 3) - 1) * 16 + (Math.random() * 4 - 2), oy: (Math.floor(slot / 3) - 1) * 14 + (Math.random() * 4 - 2),
        hp: maxHp, maxHp,
        speed: kind === "gladiator" ? 40 : kind === "knight" ? 52 : upgraded ? 56 : 52,
        damage: kind === "gladiator" ? 34 : kind === "knight" ? 16 : upgraded ? 18 : 10,
        range: kind === "archer" ? (upgraded ? 145 : 120) : kind === "gladiator" ? 30 : 27,
        attackRate: kind === "gladiator" ? 0.8 : kind === "knight" ? 1.05 : upgraded ? 0.9 : 1.15,
        cooldown: Math.random() * 0.5, attackFlash: 0, hitFlash: 0, dead: false
      });
    }
  };
  make("knight", level >= 2 ? 4 : 3);
  if (level >= 2) make("archer", 2, level >= 3);
  if (level >= 3) make("gladiator", 1);
}

const LEASH = 105; // seberapa jauh pasukan mengejar musuh dari titik kumpul
function moveToward(unit, target, step) {
  const d = distance(unit, target);
  if (d < 1.5) return;
  const move = Math.min(d, unit.speed * step);
  unit.x += (target.x - unit.x) / d * move;
  unit.y += (target.y - unit.y) / d * move;
}

function updateFriendlyUnits(step) {
  for (const unit of friendlyUnits) {
    unit.cooldown -= step;
    unit.attackFlash = Math.max(0, unit.attackFlash - step);
    unit.hitFlash = Math.max(0, unit.hitFlash - step);
    const home = { x: unit.rally.x + unit.ox, y: unit.rally.y + unit.oy };
    if (unit.kind === "archer") {
      // Pemanah menembak dari belakang, boleh mengenai musuh terbang.
      const target = enemies.filter(e => e.hp > 0 && distance(unit, e) <= unit.range)
        .sort((a, b) => b.progress - a.progress)[0];
      if (target) {
        if (unit.cooldown <= 0) {
          damageEnemy(target, unit.damage);
          addZap(unit, target, "#f1e2b4", 0.1);
          unit.cooldown = unit.attackRate; unit.attackFlash = 0.12;
        }
      } else moveToward(unit, home, step);
    } else {
      // Petarung jarak dekat mengejar musuh darat di sekitar titik kumpul.
      const target = enemies.filter(e => e.hp > 0 && !e.flying && distance(e, unit.rally) <= LEASH)
        .sort((a, b) => distance(unit, a) - distance(unit, b))[0];
      if (target) {
        const reach = unit.range + target.radius;
        if (distance(unit, target) <= reach) {
          if (unit.cooldown <= 0) {
            damageEnemy(target, unit.damage);
            unit.cooldown = unit.attackRate; unit.attackFlash = 0.12;
          }
        } else moveToward(unit, target, step);
      } else moveToward(unit, home, step);
    }
  }
  friendlyUnits = friendlyUnits.filter(u => !u.dead && u.hp > 0);
}

// ---------- Musuh ----------
function engageRadius(enemy, unit) {
  return unit.kind === "archer" ? enemy.radius + 14 : enemy.radius + unit.range + 6;
}
function moveEnemy(e, amount) {
  if (e.flying) {
    const d = distance(e, BASE);
    const move = Math.min(d, amount);
    if (d > 0) { e.x += (BASE.x - e.x) / d * move; e.y += (BASE.y - e.y) / d * move; }
    e.dist += move;
  } else {
    let remaining = amount;
    while (remaining > 0 && e.pathIndex < path.length - 1) {
      const target = path[e.pathIndex + 1];
      const d = distance(e, target);
      if (d <= remaining) {
        e.x = target.x; e.y = target.y; e.pathIndex++;
        remaining -= d; e.dist += d;
      } else {
        e.x += (target.x - e.x) / d * remaining;
        e.y += (target.y - e.y) / d * remaining;
        e.dist += remaining; remaining = 0;
      }
    }
  }
  e.progress = Math.min(1, e.dist / e.total);
}
function enemyArrived(e) {
  return e.flying ? distance(e, BASE) < 2 : e.pathIndex >= path.length - 1;
}

function updateEnemies(step) {
  for (const e of enemies) {
    e.t += step;
    e.hitFlash = Math.max(0, e.hitFlash - step);
    e.attackFlash = Math.max(0, e.attackFlash - step);
    e.hexTimer = Math.max(0, e.hexTimer - step);
    e.freezeTimer = Math.max(0, e.freezeTimer - step);
    e.slowTimer = Math.max(0, e.slowTimer - step);
    if (e.corrodeTimer > 0) e.corrodeTimer -= step;
    if (e.type === "raidboss" && !e.enraged && e.hp > 0 && e.hp <= e.maxHp * 0.5) {
      e.enraged = true; e.speed *= 1.4; e.color = "#ff2d55";
      addText(e.x, e.y - e.radius - 24, "👹 MENGAMUK!", "#ff6b8a", 18);
      addRing(e.x, e.y, 120, "#ff2d55", 0.8); sfx("roar");
      for (let i = 0; i < 3; i++) spawnEnemy("runner");
    }
    e.attackCd -= step;
    if (e.hp <= 0 || e.freezeTimer > 0) continue;
    // Musuh darat berhenti dan melawan pasukan yang menghadang.
    if (!e.flying && !e.evasive) {
      const blocker = friendlyUnits.filter(u => u.hp > 0 && distance(u, e) <= engageRadius(e, u))
        .sort((a, b) => distance(a, e) - distance(b, e))[0];
      if (blocker) {
        if (e.attackCd <= 0) {
          blocker.hp -= e.dmg; blocker.hitFlash = 0.1;
          e.attackCd = 1; e.attackFlash = 0.15;
        }
        continue;
      }
    }
    moveEnemy(e, e.speed * (e.slowTimer > 0 ? e.slowFactor : 1) * step);
  }
}

// ---------- Tower ----------
function applyHex(target, amp) {
  target.hexAmp = Math.max(target.hexTimer > 0 ? target.hexAmp : 0, amp);
  target.hexTimer = 3.5;
}
function setSlow(e, factor, dur) {
  if (e.boss) factor = 1 - (1 - factor) * 0.5; // bos lebih tahan perlambatan
  if (e.slowTimer <= 0 || factor < e.slowFactor) e.slowFactor = factor;
  e.slowTimer = Math.max(e.slowTimer, dur);
}
function applySlow(target, level) {
  let factor = Math.max(0.3, 0.55 - 0.05 * (level - 1));
  if (target.boss) factor = 1 - (1 - factor) * 0.5; // bos lebih tahan perlambatan
  if (target.slowTimer <= 0 || factor < target.slowFactor) target.slowFactor = factor;
  target.slowTimer = Math.max(target.slowTimer, 2.2 + 0.2 * level);
}

function updateTowers(step) {
  for (const tower of towers) {
    tower.flash = Math.max(0, (tower.flash || 0) - step);
    if (tower.swing > 0) tower.swing = Math.max(0, tower.swing - step);
    if (tower.type === "graveyard") { updateGraveyard(tower, step); continue; }
    if (tower.type === "barrack") {
      tower.spawnCooldown -= step;
      if (tower.spawnCooldown <= 0) {
        spawnBarrackSquad(tower);
        tower.spawnCooldown = Math.max(4.8, 6.8 - (tower.level - 1) * 0.75);
      }
      continue;
    }
    const stats = towerTypes[tower.type];
    if (tower.type === "web" || tower.type === "chrono") applyWeb(tower);
    else if (tower.type === "bloodmoon") updateBloodMoon(tower, step);
    if (stats.support || stats.income) continue;
    tower.cooldown -= step;
    if (stats.skillCd) tower.skillTimer = (tower.skillTimer == null ? stats.skillCd : tower.skillTimer) - step;
    const range = towerRange(tower);
    const target = enemies.filter(e => enemyTargetable(e, stats.air) && distance(tower, e) <= range)
      .sort((a, b) => b.progress - a.progress)[0];
    if (target) tower.face = target.x < tower.x ? -1 : 1;
    if (target && tower.cooldown <= 0) {
      tower.shots = (tower.shots || 0) + 1;
      if (!(tower.type === "crossbow" && tower.shots % 4 === 0)) sfx("t_" + tower.type);
      if (tower.type === "flame" || tower.type === "blazed") { fireFlame(tower, target); continue; }
      if (tower.type === "vampire" || tower.type === "phoenix") { fireVampire(tower); continue; }
      if (tower.type === "crossbow" && tower.shots % 4 === 0) { fireVolley(tower, target); continue; }
      if (tower.type === "reaper") { fireReaper(tower, target); continue; }
      if (tower.type === "ballista") { fireBallista(tower, target); continue; }
      if (tower.type === "railgun") { fireRailgun(tower, target); continue; }
      if (stats.skillCd && tower.skillTimer <= 0 && (tower.type === "howitzer" || tower.type === "blizzard" || tower.type === "storm")) {
        tower.skillTimer = stats.skillCd; fireEvoSkill(tower, range); continue;
      }
      bullets.push({
        x: tower.x, y: tower.y, target, damage: towerDamage(tower), level: tower.level,
        speed: bulletSpeeds[tower.type] || 360,
        lvData: levelData(tower),
        color: stats.color, type: tower.type, pierce: !!stats.pierce || !!(levelData(tower) && levelData(tower).pierce),
        freeze: (tower.type === "ice" && tower.shots % 4 === 0) || (tower.type === "blizzard" && tower.shots % 3 === 0),
        sk: (() => { const k = skinOf(tower.type); return k && k.fx ? k : null; })(), tr: []
      });
      tower.cooldown = towerRate(tower);
      tower.flash = 0.1;
    }
  }
}

const bulletSpeeds = { slinger: 330, petasan: 300, howitzer: 260, blizzard: 400, storm: 520, toxic: 330, titan: 250, sniper: 620, cannon: 280, tesla: 500, mortar: 230, hexer: 420, pumpkin: 260, witch: 270, candle: 380 };

function applyWeb(tower) {
  const lv = levelData(tower);
  for (const e of enemies) if (e.hp > 0 && distance(tower, e) <= lv.range + e.radius) setSlow(e, lv.slow, 0.35);
}
function updateBloodMoon(tower, step) {
  const lv = levelData(tower);
  tower.novaTimer -= step;
  if (tower.novaTimer > 0) return;
  tower.novaTimer = lv.novaEvery;
  enemies.forEach(e => { if (e.hp > 0) damageEnemy(e, lv.nova, { pierce: true }); });
  moonFlash = 0.8;
  addRing(tower.x, tower.y, 380, "#ff3b5c", 0.7);
  addText(tower.x, tower.y - 32, "🌕 NOVA!", "#ff8a9c", 16);
  sfx("nova");
}
function updateGraveyard(tower, step) {
  tower.spawnCooldown -= step;
  if (tower.spawnCooldown > 0) return;
  const lv = levelData(tower);
  const alive = friendlyUnits.filter(u => u.barrackId === tower.id).length;
  if (alive < lv.zombies) {
    friendlyUnits.push({
      kind: "zombie", upgraded: false, barrackId: tower.id, squadId: tower.id,
      x: tower.x, y: tower.y + 18, rally: tower.rally,
      ox: ((alive % 3) - 1) * 16 + (Math.random() * 4 - 2), oy: (Math.floor(alive / 3) - 0.5) * 14 + (Math.random() * 4 - 2),
      hp: lv.hp, maxHp: lv.hp, speed: 42, damage: lv.dmg, range: 26, attackRate: 1.2,
      cooldown: Math.random() * 0.5, attackFlash: 0, hitFlash: 0, dead: false
    });
  }
  tower.spawnCooldown = lv.respawn;
}
function fireVampire(tower) {
  const lv = levelData(tower), dmg = towerDamage(tower), range = towerRange(tower);
  enemies.filter(e => e.hp > 0 && distance(tower, e) <= range).sort((a, b) => b.progress - a.progress).slice(0, lv.targets)
    .forEach(e => {
      damageEnemy(e, dmg); addZap(tower, e, towerTypes[tower.type].color, 0.15); addBurst(e.x, e.y, towerTypes[tower.type].color, 2);
      if (lv.burn) { e.burnTimer = Math.max(e.burnTimer, 2.5); e.burnDps = Math.max(e.burnDps, lv.burn); }
    });
  tower.cooldown = towerRate(tower);
  tower.flash = 0.1;
}
function fireReaper(tower, target) {
  const lv = levelData(tower), dmg = towerDamage(tower), range = towerRange(tower);
  const canExec = e => e.hp > 0 && distance(tower, e) <= range && e.hp / e.maxHp <= lv.exec * (e.boss ? 0.4 : 1);
  const victim = enemies.filter(canExec).sort((a, b) => b.progress - a.progress)[0] || target;
  if (canExec(victim)) { victim.hp = 0; addText(victim.x, victim.y - victim.radius - 14, "☠", "#ff5c7a", 20); }
  else damageEnemy(victim, dmg, { pierce: true });
  addSlash(tower, victim, "#aab0d8");
  tower.swing = 0.3;
  addBurst(victim.x, victim.y, "#8b8fa8", 6);
  tower.cooldown = towerRate(tower);
  tower.flash = 0.1;
}
function fireFlame(tower, target) {
  // AOE: semburan api menyapu SEMUA musuh darat dalam jangkauan tower.
  const dmg = towerDamage(tower), range = towerRange(tower), lvd = levelData(tower);
  const inferno = towerTypes[tower.type].skillCd && tower.skillTimer <= 0;
  if (inferno) { tower.skillTimer = towerTypes[tower.type].skillCd; addRing(tower.x, tower.y, range * 1.35, "#ff3b1f", 0.6); addText(tower.x, tower.y - 30, "🌋 INFERNO!", "#ff8a4d", 16); sfx("inferno"); }
  let hit = 0;
  for (const e of enemies) {
    const reach = inferno ? range * 1.35 : range;
    if (e.hp <= 0 || e.flying || distance(tower, e) > reach + e.radius) continue;
    damageEnemy(e, inferno ? dmg * 5 : dmg, inferno ? { pierce: true } : {});
    e.burnTimer = Math.max(e.burnTimer, inferno ? 3.5 : 2);
    e.burnDps = Math.max(e.burnDps, inferno ? 18 : (lvd && lvd.burn ? lvd.burn : 2 + tower.level * 1.5));
    if (hit++ < 8) addBurst(e.x, e.y, inferno ? "#ff3b1f" : "#ff8a3d", inferno ? 3 : 1);
  }
  addRing(tower.x, tower.y, range, "#ff9a3d", 0.12);
  addJet({ x: tower.x + (tower.face || 1) * 14, y: tower.y - 6 }, target, inferno ? "#ff3b1f" : "#ff8a3d", "#ffe08a");
  tower.cooldown = towerRate(tower);
  tower.flash = 0.12;
}
function fireRailgun(tower, target) {
  const stats = towerTypes.railgun, skill = tower.skillTimer <= 0;
  if (skill) tower.skillTimer = stats.skillCd;
  const dmg = towerDamage(tower) * (skill ? 4 : 1), range = towerRange(tower) + 40;
  const dx = target.x - tower.x, dy = target.y - tower.y, len = Math.hypot(dx, dy) || 1;
  const end = { x: tower.x + dx / len * range, y: tower.y + dy / len * range };
  for (const e of enemies) {
    if (e.hp <= 0) continue;
    const q = segmentPoint(e.x, e.y, tower, end);
    if (Math.hypot(e.x - q.x, e.y - q.y) < e.radius + 6) damageEnemy(e, dmg, { pierce: skill });
  }
  addArrow(tower, end, skill ? "#ffffff" : "#7af0ff", skill ? 0.3 : 0.18, skill ? 7 : 3.5);
  if (skill) { addText(tower.x, tower.y - 30, "🎯 HEADSHOT!", "#7af0ff", 14); sfx("volley"); }
  tower.cooldown = towerRate(tower);
  tower.flash = 0.12;
}
function fireEvoSkill(tower, range) {
  const dmg = towerDamage(tower);
  if (tower.type === "howitzer") {
    const list = enemies.filter(e => e.hp > 0 && !e.flying && distance(tower, e) <= range).sort((a, b) => b.progress - a.progress).slice(0, 6);
    const r = 55;
    list.forEach(t => {
      enemies.forEach(e => { if (e.hp > 0 && !e.flying) { const d = distance(e, t); if (d < r + e.radius) damageEnemy(e, dmg * (d <= r * 0.45 ? 1 : 0.7)); } });
      addRing(t.x, t.y, r, "#ffd08a", 0.4); addBurst(t.x, t.y, "#ffb347", 8);
    });
    addText(tower.x, tower.y - 30, "🎆 BARRAGE!", "#ffd08a", 14); sfx("meteor");
  } else if (tower.type === "blizzard") {
    enemies.forEach(e => {
      if (e.hp <= 0 || distance(tower, e) > range + e.radius) return;
      if (e.boss) { e.slowFactor = 0.4; e.slowTimer = Math.max(e.slowTimer, 3); }
      else e.freezeTimer = Math.max(e.freezeTimer, 2.5);
      damageEnemy(e, dmg * 0.5); addBurst(e.x, e.y, "#d9f8ff", 3);
    });
    addRing(tower.x, tower.y, range, "#bff4ff", 0.6);
    addText(tower.x, tower.y - 30, "❄ DEEP FREEZE!", "#bff4ff", 14); sfx("nova");
  } else if (tower.type === "storm") {
    enemies.forEach(e => {
      if (e.hp <= 0 || distance(tower, e) > range + e.radius) return;
      damageEnemy(e, dmg * 3, { pierce: true });
      if (!e.boss) e.freezeTimer = Math.max(e.freezeTimer, 0.7);
      addZap({ x: e.x + 6, y: e.y - 150 }, e, "#fff6a8", 0.3); addBurst(e.x, e.y, "#ffe36b", 4);
    });
    addRing(tower.x, tower.y, range, "#ffe36b", 0.4);
    addText(tower.x, tower.y - 30, "⚡ THUNDER STRIKE!", "#ffe36b", 14); sfx("nova");
  }
  tower.cooldown = towerRate(tower);
  tower.flash = 0.14;
}
function fireVolley(tower, target) {
  const dmg = Math.round(towerDamage(tower) * 2.4), range = towerRange(tower) + 50;
  const dx = target.x - tower.x, dy = target.y - tower.y, len = Math.hypot(dx, dy) || 1;
  const end = { x: tower.x + dx / len * range, y: tower.y + dy / len * range };
  for (const e of enemies) {
    if (e.hp <= 0) continue;
    const q = segmentPoint(e.x, e.y, tower, end);
    if (Math.hypot(e.x - q.x, e.y - q.y) < e.radius + 8) damageEnemy(e, dmg, { pierce: true });
  }
  for (let i = -1; i <= 1; i++) { const ox = -dy / len * i * 7, oy = dx / len * i * 7; addArrow({ x: tower.x + ox, y: tower.y + oy }, { x: end.x + ox, y: end.y + oy }, "#ffe9a8", 0.26, 2.2); }
  addText(tower.x, tower.y - 28, "VOLLEY!", "#ffe08a", 13);
  tower.cooldown = towerRate(tower);
  tower.flash = 0.14;
  sfx("volley");
}
function fireBallista(tower, target) {
  const dmg = towerDamage(tower), lv = levelData(tower);
  const range = towerRange(tower) + 60;
  const dx = target.x - tower.x, dy = target.y - tower.y, len = Math.hypot(dx, dy) || 1;
  const end = { x: tower.x + dx / len * range, y: tower.y + dy / len * range };
  for (const e of enemies) {
    if (e.hp <= 0) continue;
    const q = segmentPoint(e.x, e.y, tower, end);
    if (Math.hypot(e.x - q.x, e.y - q.y) < e.radius + 7) damageEnemy(e, dmg, { pierce: !!lv.pierce });
  }
  addArrow(tower, end, "#d9b36a", 0.22, 5);
  tower.cooldown = towerRate(tower);
  tower.flash = 0.1;
}

function updateBullets(step) {
  for (const bullet of bullets) {
    if (!bullet.target || bullet.target.hp <= 0) { bullet.dead = true; continue; }
    const target = bullet.target;
    const d = distance(bullet, target);
    const move = bullet.speed * step;
    if (bullet.sk) { bullet.tr.push({ x: bullet.x, y: bullet.y }); if (bullet.tr.length > 7) bullet.tr.shift(); }
    if (d > move + target.radius) {
      bullet.x += (target.x - bullet.x) / d * move;
      bullet.y += (target.y - bullet.y) / d * move;
      continue;
    }
    if (bullet.type === "mortar" || bullet.type === "pumpkin" || bullet.type === "titan" || bullet.type === "howitzer") {
      const r = bullet.lvData.splash;
      enemies.forEach(e => {
        if (e.hp <= 0 || e.flying) return;
        const d = distance(e, target);
        if (d < r + e.radius) damageEnemy(e, bullet.damage * (d <= r * 0.45 ? 1 : 0.7));
      });
      addRing(target.x, target.y, r, "#ffd08a", 0.35);
      addBurst(target.x, target.y, "#e0a458", 10);
      sfx("boom");
      bullet.dead = true; continue;
    }
    if (bullet.type === "witch") {
      const lv = bullet.lvData;
      damageEnemy(target, bullet.damage);
      poisonPuddles.push({ x: target.x, y: target.y, radius: lv.pool, timer: 3, damage: lv.dps, slow: lv.slow, color: "#b44cff" });
      addRing(target.x, target.y, lv.pool, "#b44cff", 0.3);
      bullet.dead = true; continue;
    }
    if (bullet.type === "hexer") {
      const lv = bullet.lvData;
      damageEnemy(target, bullet.damage);
      applyHex(target, lv.amp);
      addRing(target.x, target.y, target.radius + 10, "#c58bff", 0.3);
      if (lv.spread) {
        enemies.filter(e => e !== target && e.hp > 0 && distance(e, target) < 85)
          .sort((a, b) => distance(a, target) - distance(b, target)).slice(0, 2)
          .forEach(e => { applyHex(e, lv.amp * 0.6); addZap(target, e, "#c58bff", 0.2); });
      }
      bullet.dead = true; continue;
    }
    damageEnemy(target, bullet.damage, { pierce: bullet.pierce });
    if (bullet.lvData && bullet.lvData.burn) {
      target.burnTimer = Math.max(target.burnTimer, 2);
      target.burnDps = Math.max(target.burnDps, bullet.lvData.burn);
    }
    if (bullet.type === "blizzard") {
      const r = bullet.lvData.splash;
      enemies.forEach(e => {
        if (e.hp <= 0 || distance(e, target) > r + e.radius) return;
        if (e !== target) damageEnemy(e, bullet.damage * 0.5);
        applySlow(e, 4);
      });
      addRing(target.x, target.y, r, "#bff4ff", 0.3);
      if (bullet.freeze && !target.boss) { target.freezeTimer = 1.5; addText(target.x, target.y - target.radius - 16, "❄", "#d9f8ff", 14); }
    }
    if (bullet.type === "ice") {
      applySlow(target, bullet.level);
      if (bullet.freeze && !target.boss) {
        target.freezeTimer = 1.2;
        addText(target.x, target.y - target.radius - 16, "❄", "#d9f8ff", 14);
      }
    }
    if (bullet.type === "toxic") {
      const lv = bullet.lvData;
      target.poisonTimer = 3.2; target.poisonDamage = Math.max(target.poisonDamage, bullet.damage * 0.45);
      target.corrodeTimer = 4; target.corrode = lv.corrode; target.acid = true;
      poisonPuddles.push({ x: target.x, y: target.y, radius: lv.pool, timer: 2.4, damage: lv.dps, corrode: lv.corrode });
      addRing(target.x, target.y, lv.pool, "#7dff3a", 0.3);
    }
    if (bullet.type === "poison") {
      target.poisonTimer = 3.2;
      target.poisonDamage = Math.max(target.poisonDamage, bullet.damage * 0.5);
      poisonPuddles.push({ x: target.x, y: target.y, radius: 44 + bullet.level * 4, timer: 2, damage: 3.5 * (1 + (bullet.level - 1) * 0.35) });
    }
    if (bullet.type === "storm") {
      const hit = new Set([target]); let prev = target;
      [0.7, 0.55, 0.45, 0.35].forEach(f => {
        const nx = enemies.filter(e => e.hp > 0 && !hit.has(e) && distance(e, prev) < 90).sort((a, b) => distance(a, prev) - distance(b, prev))[0];
        if (!nx) return;
        hit.add(nx); damageEnemy(nx, bullet.damage * f); addZap(prev, nx, "#fff6a8", 0.2); prev = nx;
      });
    }
    if (bullet.type === "tesla") {
      // Sambaran listrik memantul ke maksimal 2 musuh lain yang berdekatan.
      const nearby = enemies.filter(e => e !== target && e.hp > 0 && distance(e, target) < 72)
        .sort((a, b) => distance(a, target) - distance(b, target)).slice(0, 2);
      nearby.forEach((e, i) => {
        damageEnemy(e, bullet.damage * (i === 0 ? 0.65 : 0.4));
        addZap(i === 0 ? target : nearby[0], e, "#9ff1ff", 0.18);
      });
    }
    if (bullet.type === "cannon" || bullet.type === "petasan") {
      const r = 48 + bullet.level * 3;
      enemies.forEach(e => { if (e !== target && !e.flying && distance(e, target) < r) damageEnemy(e, bullet.damage * 0.45); });
      addRing(target.x, target.y, r, "#ffd08a", 0.3);
      if (bullet.type === "petasan") addBurst(target.x, target.y, "#ff8a4d", 5);
    }
    bullet.dead = true;
  }
  bullets = bullets.filter(b => !b.dead);
}

function updatePoison(step) {
  for (const puddle of poisonPuddles) {
    puddle.timer -= step;
    for (const enemy of enemies) {
      if (enemy.hp > 0 && !enemy.flying && distance(puddle, enemy) <= puddle.radius) {
        damageEnemy(enemy, puddle.damage * step, { pierce: true, dot: true });
        if (puddle.corrode) { enemy.corrodeTimer = Math.max(enemy.corrodeTimer, 1); enemy.corrode = Math.max(enemy.corrode, puddle.corrode); }
        if (puddle.slow) setSlow(enemy, puddle.slow, 0.4);
        else {
          enemy.poisonTimer = Math.max(enemy.poisonTimer, 0.5);
          enemy.poisonDamage = Math.max(enemy.poisonDamage, 1.5);
        }
      }
    }
  }
  poisonPuddles = poisonPuddles.filter(p => p.timer > 0);
  for (const e of enemies) {
    if (e.burnTimer > 0 && e.hp > 0) {
      damageEnemy(e, e.burnDps * step, { pierce: true, dot: true });
      e.burnTimer = Math.max(0, e.burnTimer - step);
    }
    if (e.poisonTimer > 0 && e.hp > 0) {
      damageEnemy(e, e.poisonDamage * step, { pierce: true, dot: true });
      e.poisonTimer = Math.max(0, e.poisonTimer - step);
    }
  }
}

// ---------- Skill Meteor ----------
function meteorDamage() { return 110 + wave * 14; }
function castMeteor(p) {
  meteorArmed = false;
  ui.canvasWrap && ui.canvasWrap.classList.remove("armed");
  if (!waveActive || meteorCooldown > 0 || gameOver) return;
  meteors.push({ x: p.x, y: p.y, t: 0.55, max: 0.55, radius: 78 });
  meteorCooldown = METEOR_COOLDOWN;
  ui.message.textContent = "Meteor meluncur!";
  sfx("meteor");
  updateUI(); draw();
}
function updateMeteors(step) {
  for (const m of meteors) {
    m.t -= step;
    if (m.t > 0) continue;
    enemies.forEach(e => { if (e.hp > 0 && distance(e, m) <= m.radius) damageEnemy(e, meteorDamage()); });
    addRing(m.x, m.y, m.radius, "#ff9b54", 0.5);
    addBurst(m.x, m.y, "#ffb347", 18);
    m.done = true;
  }
  meteors = meteors.filter(m => !m.done);
}

// ---------- Update utama ----------
function update(dt) {
  if (paused || gameOver) return;
  const step = dt * speed;
  baseFlash = Math.max(0, baseFlash - step);
  moonFlash = Math.max(0, moonFlash - step);
  meteorCooldown = Math.max(0, meteorCooldown - step);

  if (waveActive && spawnQueue.length > 0) {
    spawnTimer -= step;
    if (spawnTimer <= 0) {
      spawnEnemy(spawnQueue.shift());
      spawnTimer = Math.max(0.38, 0.9 - wave * 0.035);
    }
  }

  updateEnemies(step);
  updateTowers(step);
  updateFriendlyUnits(step);
  updateBullets(step);
  updatePoison(step);
  updateMeteors(step);
  updateFx(step);

  for (const e of enemies) {
    if (e.hp <= 0) {
      e.dead = true; kills++;
      gold += e.reward; totalGoldEarned += e.reward;
      addText(e.x, e.y - e.radius - 6, `+${e.reward}`, "#ffd166", 13);
      addBurst(e.x, e.y, e.color, e.boss ? 16 : 7);
      sfx("kill", e.type);
      rollToken(e);
      if (e.acid) { poisonPuddles.push({ x: e.x, y: e.y, radius: 58, timer: 3, damage: 14, corrode: 0.3 }); addRing(e.x, e.y, 58, "#7dff3a", 0.35); }
    } else if (enemyArrived(e)) {
      e.dead = true;
      if (!adminGod) health -= e.leak || 1;
      baseFlash = 0.6;
      sfx("leak");
      if (health <= 0) { endGame(false); break; }
    }
  }
  enemies = enemies.filter(e => !e.dead);

  if (!gameOver && waveActive && spawnQueue.length === 0 && enemies.length === 0) {
    waveActive = false;
    if (wave >= MAX_WAVE) endGame(true);
    else {
      let bonus = Math.round((20 + wave * 3) * diff().bonus), mineGold = 0;
      towers.filter(t => t.type === "mine" || t.type === "merchant").forEach(t => {
        const inc = levelData(t).income; mineGold += inc;
        addText(t.x, t.y - 22, `+${inc}`, "#ffd166", 14);
      });
      gold += bonus + mineGold; totalGoldEarned += bonus + mineGold;
      if (wave > save.bestWave) { save.bestWave = wave; writeSave(); }
      if (save.auto) autoTimer = 2;
      ui.message.textContent = `Wave ${wave} selesai! Bonus ${bonus} gold${mineGold ? ` + ${mineGold} dari penghasil gold` : ""}. Mulai wave berikutnya saat siap.`;
    }
  }
  if (!waveActive && !gameOver && autoTimer > 0 && save.auto) {
    autoTimer -= dt;
    if (autoTimer <= 0) { autoTimer = 0; beginWave(); }
  }
  updateUI();
}

function rollToken(e) {
  save.tokenPity = (save.tokenPity || 0) + 1;
  if (save.tokenPity >= TOKEN_PITY || Math.random() < (e.boss ? TOKEN_RATE_BOSS : TOKEN_RATE)) {
    save.tokenPity = 0; save.tokens = (save.tokens || 0) + 1; runTokens++;
    addText(e.x, e.y - e.radius - 24, "+1 🧿", "#7df9ff", 16);
    ui.message.textContent = "🧿 Evolve Token didapat! Kumpulkan 3 untuk evolve tower level maks.";
    sfx("token"); writeSave();
  }
}

function grantReward(cleared, reached, won) {
  if (runRewarded) return 0;
  runRewarded = true;
  const gems = map.raid ? 0 : Math.round((cleared * 3 + (won ? 30 : 0)) * map.gemMult * diff().reward);
  save.gems += gems;
  lastCrystals = map.raid ? Math.round((cleared * 5 + (won ? 80 : 0)) * diff().reward) : 0;
  save.crystals = (save.crystals || 0) + lastCrystals;
  lastCoins = map.event ? Math.round((cleared * 2 + (won ? 20 : 0)) * diff().reward) : 0;
  save.coins += lastCoins;
  if (reached > bestOf(map.id)) save.mapBest[bestKey(map.id)] = reached;
  writeSave();
  return gems;
}

function endGame(won) {
  if (gameOver) return;
  gameOver = true; waveActive = false; meteorArmed = false;
  ui.canvasWrap && ui.canvasWrap.classList.remove("armed");
  const reached = won ? MAX_WAVE : wave;
  if (reached > save.bestWave) save.bestWave = reached;
  if (won) save.wins++;
  const gems = grantReward(won ? MAX_WAVE : Math.max(0, wave - 1), reached, won);
  ui.overlay.classList.remove("hidden");
  ui.overlayTitle.textContent = won ? "🏆 Kamu Menang!" : "💥 Markas Jatuh!";
  ui.overlayText.textContent = (won
    ? (map.raid ? "Raid Boss tumbang! Arena Raid ditaklukkan!" : `Semua ${MAX_WAVE} wave di ${map.name} berhasil dilewati. Pertahananmu solid!`)
    : `Kamu bertahan sampai wave ${wave}. Coba atur posisi tower dan upgrade lebih awal.`)
    + ` Musuh dikalahkan: ${kills}. Hadiah: ${map.raid ? `+${lastCrystals} 🔷` : `+${gems} 💎`}${lastCoins ? ` +${lastCoins} 🎃` : ""}${runTokens ? ` +${runTokens} 🧿` : ""}`;
  ui.startBtn.textContent = "Main lagi";
  ui.message.textContent = won ? "Selamat! Kamu menyelesaikan game." : "Game over. Tekan Main lagi untuk mencoba ulang.";
  sfx(won ? "win" : "lose");
  updateUI();
}

// ---------- UI ----------
function updateUI() {
  setText(ui.health, health);
  setText(ui.gold, gold);
  setText(ui.wave, `${wave} / ${MAX_WAVE}`);
  const mb = bestOf(map.id);
  setText(ui.best, mb >= MAX_WAVE ? "Menang ✔" : mb ? `Wave ${mb}` : "-");
  ui.waveBtn.disabled = waveActive || gameOver || wave >= MAX_WAVE;
  ui.pauseBtn.disabled = !waveActive || gameOver;
  ui.speedBtn.disabled = gameOver;
  setText(ui.speedBtn, `⏩ Kecepatan x${speed}`);
  setText(ui.autoBtn, save.auto ? "🔁 Auto: ON" : "🔁 Auto: OFF");
  ui.autoBtn.classList.toggle("on", !!save.auto);
  ui.meteorBtn.disabled = !waveActive || gameOver || meteorCooldown > 0;
  setText(ui.meteorBtn, meteorArmed ? "☄️ Pilih lokasi… (Esc batal)" : meteorCooldown > 0 ? `☄️ Meteor • ${Math.ceil(meteorCooldown)}d` : "☄️ Meteor (M)");
  ui.soundBtn.textContent = save.muted ? "🔇" : "🔊";
  ui.soundBtn.setAttribute("aria-label", save.muted ? "Suara mati" : "Suara menyala");

  const hasTower = Boolean(selectedTower);
  const cost = upgradeCost(selectedTower);
  ui.upgradeBtn.disabled = !hasTower || gameOver || cost === Infinity || gold < cost;
  setText(ui.upgradeBtn, hasTower && cost !== Infinity ? `⬆ Upgrade (${cost}🪙)` : "⬆ Upgrade");
  setText(ui.tokens, save.tokens || 0);
  ui.sellBtn.disabled = !hasTower || gameOver;
  setText(ui.sellBtn, hasTower ? `💰 Jual (${sellValue(selectedTower)}🪙)` : "💰 Jual");

  if (selectedTower && selectedTower.type === "barrack") {
    const next = selectedTower.level < 3 ? `Upgrade ${cost} gold` : "Level maksimum";
    setHTML(ui.selectionInfo, `<b>BARACK • Level ${selectedTower.level}</b><br>Squad: ${barrackRoster(selectedTower.level)}<br>${next}`);
  } else if (selectedTower) {
    const t = towerTypes[selectedTower.type];
    const lv = levelData(selectedTower);
    const next = selectedTower.level < maxLevel(selectedTower) ? `Upgrade ${cost} gold` : "Level maksimum";
    let detail;
    if (t.info) detail = t.info(lv);
    else if (t.income) detail = `Menghasilkan +${lv.income} gold tiap wave selesai`;
    else if (t.support) detail = `Aura radius ${lv.range} • +${Math.round(lv.dmgBuff * 100)}% damage${lv.rateBuff ? ` • +${Math.round(lv.rateBuff * 100)}% kecepatan` : ""}`;
    else {
      const dps = (towerDamage(selectedTower) / towerRate(selectedTower)).toFixed(0);
      const buff = towerBuff(selectedTower);
      detail = `Damage ${towerDamage(selectedTower)}${buff.d ? " (aura)" : ""} • Jangkauan ${towerRange(selectedTower)} • ~${dps} DPS`;
      if (lv && lv.burn) detail += ` • Bakar ${lv.burn}/dtk`;
      if (lv && lv.splash) detail += ` • Ledakan ${lv.splash}`;
      if (lv && lv.amp) detail += ` • Kutukan +${Math.round(lv.amp * 100)}% damage diterima${lv.spread ? " (menyebar)" : ""}`;
    }
    let extra = next;
    if (t.evolved) extra = `<span style="color:#ffd166">✨ EVOLVED</span>${t.skillCd ? ` • ${({ blazed: "Inferno", howitzer: "Barrage", blizzard: "Deep Freeze", storm: "Thunder", railgun: "Headshot" })[selectedTower.type] || "Skill"} ${Math.max(0, Math.ceil(selectedTower.skillTimer == null ? t.skillCd : selectedTower.skillTimer))}d` : ""}`;
    setHTML(ui.selectionInfo, `<b>${t.name} • ${t.evolved ? "EVO" : `Level ${selectedTower.level}/${maxLevel(selectedTower)}`}</b><br>${detail}<br>${extra}`);
  } else {
    setHTML(ui.selectionInfo, "Belum ada tower dipilih.");
  }

  if (waveActive) {
    const plan = wavePlans[wave - 1];
    const left = enemies.length + spawnQueue.length;
    setHTML(ui.wavePreview, `<b>Wave ${wave} berlangsung</b> • sisa ${left} musuh`);
    ui.waveFill.style.width = `${Math.round((1 - left / plan.length) * 100)}%`;
  } else if (!gameOver && wave < MAX_WAVE) {
    const plan = wavePlans[wave];
    const hasFlyer = plan.includes("flyer");
    setHTML(ui.wavePreview, `<b>Wave ${wave + 1} berikutnya:</b> ${planText(plan)}${hasFlyer ? '<br><small>🦇 hanya bisa dilukai Archer, Ice, Magic, Sniper, Tesla, Meteor & pemanah BARACK.</small>' : ""}`);
    ui.waveFill.style.width = "0%";
  } else {
    setHTML(ui.wavePreview, gameOver ? "Permainan selesai." : "Semua wave selesai.");
  }
}

function unitStatText(key) {
  const t = towerTypes[key], max = t.maxLevel || 5;
  if (t.evolved) return `${t.note} • EVOLVED`;
  let main;
  if (t.note) main = t.note;
  else if (t.income) main = `Gold/wave: ${t.levels.map(l => "+" + l.income).join(" / ")}`;
  else if (t.support) main = `Aura: ${t.levels.map(l => "+" + Math.round(l.dmgBuff * 100) + "%").join(" / ")} damage`;
  else if (t.rally) main = "Pasukan: 3 → 7 prajurit";
  else if (t.debuff) main = `⚔ ${t.damage} • ◎ ${t.range} • Kutukan ${t.levels.map(l => "+" + Math.round(l.amp * 100) + "%").join(" / ")}`;
  else if (t.levels && t.levels[0].splash) main = `⚔ ${t.damage} • ◎ ${t.range} • Ledakan ${t.levels.map(l => l.splash).join(" / ")}`;
  else main = `⚔ ${t.damage} • ◎ ${t.range}`;
  return `${main} • Maks Lv ${max}`;
}
function buildTowerButtons() {
  ui.towerGrid.innerHTML = loadout.map((key, i) => {
    const t = towerTypes[key];
    return `<button class="tower-btn${key === loadout[0] ? " selected" : ""}${t.gacha ? " gacha" : ""}"${t.gacha ? ` style="--rar:${rarities[t.rarity].color}"` : ""} data-tower="${key}" title="Tombol ${i + 1}">
      <span class="tower-icon">${chibiIcon(key)}</span>
      <span><b>${t.name}</b><small>${t.desc}</small><small class="stat-line">${unitStatText(key)}</small></span>
      <strong>${t.cost} 🪙</strong></button>`;
  }).join("");
  ui.towerGrid.querySelectorAll(".tower-btn").forEach(button => button.addEventListener("click", () => selectType(button.dataset.tower)));
}
function selectType(key) {
  selectedType = key;
  selectedTower = null;
  meteorArmed = false;
  document.querySelectorAll(".tower-btn").forEach(b => b.classList.toggle("selected", b.dataset.tower === key));
  updateUI(); draw();
}

// ---------- Input ----------
canvas.addEventListener("pointerdown", event => {
  if (gameOver) return;
  const p = canvasPoint(event);
  if (meteorArmed) { castMeteor(p); return; }
  // Jika menyentuh tower yang sudah ada, pilih tower tersebut.
  const found = [...towers].reverse().find(t => distance(t, p) < 22);
  if (found) {
    selectedTower = found;
    updateUI(); draw();
    return;
  }
  selectedTower = null;
  const type = towerTypes[selectedType];
  const problem = canPlace(p);
  if (problem) {
    ui.message.textContent = problem; sfx("error");
  } else if (type.unique && towers.some(t => t.type === selectedType)) {
    ui.message.textContent = `${type.name} hanya boleh 1 per permainan.`; sfx("error");
  } else if (gold < type.cost) {
    ui.message.textContent = "Gold belum cukup untuk membeli tower ini."; sfx("error");
  } else {
    const tower = { id: `tower-${Date.now()}-${Math.random()}`, x: p.x, y: p.y, type: selectedType, level: 1, cooldown: 0, spawnCooldown: 1.2, spent: type.cost, shots: 0, flash: 0 };
    if (type.rally) tower.rally = nearestPathPoint(p.x, p.y);
    tower.novaTimer = 3;
    towers.push(tower);
    gold -= type.cost;
    ui.message.textContent = `${type.name} berhasil dipasang!`;
    sfx("place");
  }
  updateUI(); draw();
});
canvas.addEventListener("pointermove", event => {
  hover = event.pointerType === "mouse" ? canvasPoint(event) : null;
  if (!animationId || paused) draw();
});
canvas.addEventListener("pointerleave", () => { hover = null; if (!animationId || paused) draw(); });

ui.startBtn.addEventListener("click", () => {
  if (gameOver) {
    if (animationId) cancelAnimationFrame(animationId);
    animationId = null;
    resetGame();
    loop(0);
    return;
  }
  ui.overlay.classList.add("hidden");
  if (wave === 0) beginWave();
  if (!animationId) loop(0);
});
ui.autoBtn.addEventListener("click", toggleAuto);
function toggleAuto() {
  save.auto = !save.auto; writeSave();
  if (save.auto && !waveActive && !gameOver && wave > 0 && wave < MAX_WAVE) autoTimer = 1;
  if (!save.auto) autoTimer = 0;
  updateUI();
}
ui.waveBtn.addEventListener("click", () => { beginWave(); if (!animationId && !gameOver) loop(0); });
function togglePause() {
  if (ui.pauseBtn.disabled) return;
  sfx("click");
  paused = !paused;
  ui.pauseBtn.textContent = paused ? "▶ Lanjut" : "⏸ Jeda";
  if (!paused && !animationId) loop(0);
  draw();
}
ui.pauseBtn.addEventListener("click", togglePause);
function cycleSpeed() { if (gameOver) return; sfx("click"); speed = speed === 1 ? 2 : speed === 2 ? 3 : 1; updateUI(); }
ui.speedBtn.addEventListener("click", cycleSpeed);
function doUpgrade() {
  if (!selectedTower || gameOver) return;
  const cost = upgradeCost(selectedTower);
  if (cost === Infinity) {
    ui.message.textContent = selectedTower.type === "barrack" ? "BARACK sudah mencapai level maksimum." : "Tower sudah mencapai level maksimum.";
    return;
  }
  if (gold < cost) { ui.message.textContent = "Gold belum cukup untuk upgrade."; sfx("error"); return; }
  gold -= cost;
  selectedTower.level++;
  selectedTower.spent += cost;
  addRing(selectedTower.x, selectedTower.y, 30, "#ffd166", 0.4);
  ui.message.textContent = `${towerTypes[selectedTower.type].name} naik ke level ${selectedTower.level}!`;
  sfx("upgrade");
  updateUI(); draw();
}
ui.upgradeBtn.addEventListener("click", doUpgrade);
function doSell() {
  if (!selectedTower || gameOver) return;
  gold += sellValue(selectedTower);
  const sold = selectedTower;
  towers = towers.filter(t => t !== sold);
  friendlyUnits = friendlyUnits.filter(u => u.barrackId !== sold.id); // pasukan ikut hilang
  selectedTower = null;
  ui.message.textContent = "Tower dijual. Sebagian gold dikembalikan.";
  sfx("sell");
  updateUI(); draw();
}
ui.sellBtn.addEventListener("click", doSell);
function armMeteor() {
  if (ui.meteorBtn.disabled) return;
  meteorArmed = !meteorArmed;
  selectedTower = null;
  ui.canvasWrap && ui.canvasWrap.classList.toggle("armed", meteorArmed);
  ui.message.textContent = meteorArmed ? "Ketuk peta untuk menjatuhkan Meteor." : "Meteor dibatalkan.";
  updateUI(); draw();
}
ui.meteorBtn.addEventListener("click", armMeteor);
ui.soundBtn.addEventListener("click", () => { const was = save.muted; save.muted = !save.muted; writeSave(); updateUI(); if (was) sfx("click"); });
ui.restartBtn.addEventListener("click", () => {
  if (animationId) cancelAnimationFrame(animationId);
  animationId = null;
  resetGame();
  loop(0);
});

// Pintasan keyboard
document.addEventListener("keydown", event => {
  if (event.ctrlKey || event.metaKey || event.altKey) return;
  if (event.target && /^(INPUT|SELECT|TEXTAREA)$/.test(event.target.tagName)) return;
  if (!L.lobby.hidden || !ui.overlay.classList.contains("hidden")) return;
  const key = event.key.toLowerCase();
  const num = parseInt(key, 10);
  if (num >= 1 && num <= loadout.length) selectType(loadout[num - 1]);
  else if (key === "a") toggleAuto();
  else if (key === "n") { if (!ui.waveBtn.disabled) ui.waveBtn.click(); }
  else if (key === "p") togglePause();
  else if (key === "f") cycleSpeed();
  else if (key === "u") doUpgrade();
  else if (key === "s" || key === "delete") doSell();
  else if (key === "m") armMeteor();
  else if (key === "escape") {
    selectedTower = null; meteorArmed = false;
    ui.canvasWrap && ui.canvasWrap.classList.remove("armed");
    updateUI(); draw();
  } else return;
  event.preventDefault();
});

// ---------- Gambar ----------
function strokePath(c) { c.beginPath(); c.moveTo(path[0].x, path[0].y); path.slice(1).forEach(p => c.lineTo(p.x, p.y)); c.stroke(); }
function drawObstacle(c, o, th) {
  const { x, y } = o;
  if (o.kind === "tree") {
    c.fillStyle = "#4b8a4b"; c.beginPath(); c.arc(x, y + 7, 22, 0, Math.PI * 2); c.fill();
    c.fillStyle = "#2f854f"; c.beginPath(); c.arc(x, y, 20, 0, Math.PI * 2); c.fill();
    c.fillStyle = "#46a963"; c.beginPath(); c.arc(x - 5, y - 6, 12, 0, Math.PI * 2); c.fill();
  } else if (o.kind === "pond") {
    const rx = o.r + 7, ry = o.r * 0.75;
    c.fillStyle = th.rim; c.beginPath(); c.ellipse(x, y + 2, rx, ry, -.2, 0, Math.PI * 2); c.fill();
    c.fillStyle = th.water; c.beginPath(); c.ellipse(x, y - 2, rx - 6, ry - 6, -.2, 0, Math.PI * 2); c.fill();
    c.fillStyle = th.shine || "#ffffff55"; c.beginPath(); c.ellipse(x - rx * 0.3, y - ry * 0.3, rx * 0.25, ry * 0.12, -.2, 0, Math.PI * 2); c.fill();
  } else if (o.kind === "cactus") {
    c.fillStyle = "#00000022"; c.beginPath(); c.ellipse(x, y + 20, 16, 5, 0, 0, Math.PI * 2); c.fill();
    c.fillStyle = "#3e8e4e"; c.strokeStyle = "#2c6b39"; c.lineWidth = 2;
    const rr = (px, py, w, h) => { c.beginPath(); c.roundRect ? c.roundRect(px, py, w, h, 6) : c.rect(px, py, w, h); c.fill(); c.stroke(); };
    rr(x - 6, y - 22, 12, 44); rr(x - 18, y - 8, 8, 20); rr(x + 10, y - 14, 8, 20);
    c.fillRect(x - 14, y + 2, 10, 6); c.fillRect(x + 4, y - 4, 10, 6);
  } else if (o.kind === "rock") {
    c.fillStyle = "#00000022"; c.beginPath(); c.ellipse(x, y + 14, 22, 6, 0, 0, Math.PI * 2); c.fill();
    c.fillStyle = th.rockA || "#9a8f7e"; c.beginPath(); c.ellipse(x, y + 2, 21, 15, 0, 0, Math.PI * 2); c.fill();
    c.fillStyle = th.rockB || "#b5aa97"; c.beginPath(); c.ellipse(x - 5, y - 3, 12, 8, -.3, 0, Math.PI * 2); c.fill();
  } else if (o.kind === "tomb") {
    c.fillStyle = "#0004"; c.beginPath(); c.ellipse(x, y + 17, 16, 5, 0, 0, Math.PI * 2); c.fill();
    c.fillStyle = "#6f6a7c"; c.beginPath(); c.moveTo(x - 12, y + 16); c.lineTo(x - 12, y - 6); c.arc(x, y - 6, 12, Math.PI, 0); c.lineTo(x + 12, y + 16); c.closePath(); c.fill();
    c.strokeStyle = "#4a4658"; c.lineWidth = 2.5; c.beginPath(); c.moveTo(x, y - 8); c.lineTo(x, y + 6); c.moveTo(x - 5, y - 2); c.lineTo(x + 5, y - 2); c.stroke();
  } else if (o.kind === "deadtree") {
    c.strokeStyle = "#1d1426"; c.lineCap = "round"; c.lineWidth = 7; c.beginPath(); c.moveTo(x, y + 20); c.lineTo(x, y - 6); c.stroke();
    c.lineWidth = 4; c.beginPath(); c.moveTo(x, y + 2); c.lineTo(x - 16, y - 16); c.moveTo(x, y - 4); c.lineTo(x + 15, y - 20); c.moveTo(x - 10, y - 11); c.lineTo(x - 18, y - 12); c.stroke();
    c.lineCap = "round";
  } else if (o.kind === "pumpkin") {
    c.fillStyle = "#0004"; c.beginPath(); c.ellipse(x, y + 14, 15, 4, 0, 0, Math.PI * 2); c.fill();
    c.fillStyle = "#f28c1e"; c.beginPath(); c.ellipse(x, y + 3, 16, 13, 0, 0, Math.PI * 2); c.fill();
    c.fillStyle = "#d46f0f"; c.beginPath(); c.ellipse(x - 7, y + 3, 5, 12, 0, 0, Math.PI * 2); c.ellipse(x + 7, y + 3, 5, 12, 0, 0, Math.PI * 2); c.fill();
    c.fillStyle = "#3f7d2f"; c.fillRect(x - 2, y - 13, 4, 7);
    c.fillStyle = "#ffe17a"; c.beginPath(); c.moveTo(x - 7, y); c.lineTo(x - 3, y - 4); c.lineTo(x - 1, y + 1); c.fill(); c.beginPath(); c.moveTo(x + 7, y); c.lineTo(x + 3, y - 4); c.lineTo(x + 1, y + 1); c.fill();
    c.fillRect(x - 6, y + 7, 12, 3);
  } else if (o.kind === "pillar") {
    c.fillStyle = "#00000028"; c.beginPath(); c.ellipse(x, y + 20, 20, 6, 0, 0, Math.PI * 2); c.fill();
    c.fillStyle = "#c9ccd3"; c.fillRect(x - 11, y - 18, 22, 38);
    c.fillStyle = "#aeb2ba"; c.fillRect(x + 3, y - 18, 8, 38);
    c.fillStyle = "#dfe2e8"; c.fillRect(x - 15, y - 24, 30, 8); c.fillRect(x - 15, y + 17, 30, 7);
  }
}
function drawBase(c, th) {
  c.save();
  c.translate(BASE.x - 856, BASE.y - 245);
  if (th.base === "gate") {
    c.fillStyle = "#6b7079"; c.fillRect(824, 176, 26, 58); c.fillRect(862, 176, 26, 58);
    c.fillStyle = "#aeb3bd"; c.fillRect(827, 180, 20, 54); c.fillRect(865, 180, 20, 54);
    for (const bx of [824, 832, 840, 862, 870, 878]) { c.fillStyle = "#6b7079"; c.fillRect(bx, 168, 8, 9); }
    c.fillStyle = "#6b7079"; c.fillRect(846, 196, 20, 38);
    c.fillStyle = "#3a2a20"; c.beginPath(); c.moveTo(849, 234); c.lineTo(849, 208); c.arc(856, 208, 7, Math.PI, 0); c.lineTo(863, 234); c.closePath(); c.fill();
    c.fillStyle = "#bd554d"; c.fillRect(853, 176, 6, 18); c.beginPath(); c.moveTo(853, 194); c.lineTo(856, 199); c.lineTo(859, 194); c.fill();
  } else {
    c.fillStyle = "#9b593b"; c.fillRect(835, 183, 42, 42);
    c.fillStyle = "#e8e4d4"; c.fillRect(842, 194, 28, 31);
    c.fillStyle = "#bd554d"; c.beginPath(); c.moveTo(829, 195); c.lineTo(856, 170); c.lineTo(883, 195); c.closePath(); c.fill();
    c.fillStyle = "#4d2e22"; c.fillRect(851, 208, 10, 17);
  }
  c.restore();
  c.fillStyle = "#fff"; c.font = "bold 12px system-ui"; c.textAlign = "center"; c.textBaseline = "alphabetic";
  c.strokeStyle = "#0006"; c.lineWidth = 3; c.strokeText("BASE", BASE.x, BASE.y + 25); c.fillText("BASE", BASE.x, BASE.y + 25);
}
function paintBackground(c) {
  const th = map.theme;
  c.fillStyle = th.bg; c.fillRect(0, 0, W, H);
  // Pola dasar
  if (map.id === "castle") {
    c.strokeStyle = "#00000018"; c.lineWidth = 1;
    for (let x = 0; x <= W; x += 60) { c.beginPath(); c.moveTo(x, 0); c.lineTo(x, H); c.stroke(); }
    for (let y = 0; y <= H; y += 60) { c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); }
  }
  for (let i = 0; i < 130; i++) {
    const x = (i * 97 + 23) % W, y = (i * 61 + 19) % H;
    if (!pointOnPath(x, y)) {
      c.fillStyle = i % 2 ? th.spotA : th.spotB;
      c.beginPath(); c.ellipse(x, y, map.id === "forest" ? 3 : 4, map.id === "forest" ? 6 : 3, -.3, 0, Math.PI * 2); c.fill();
    }
  }
  if (map.id === "halloween") {
    c.fillStyle = "#ffffffaa";
    for (let i = 0; i < 45; i++) { c.fillRect((i * 173 + 31) % W, (i * 97 + 11) % 200, 2, 2); }
    const g = c.createRadialGradient(790, 62, 10, 790, 62, 70);
    g.addColorStop(0, "#fff3b855"); g.addColorStop(1, "#fff3b800");
    c.fillStyle = g; c.beginPath(); c.arc(790, 62, 70, 0, Math.PI * 2); c.fill();
    c.fillStyle = "#f7e9a8"; c.beginPath(); c.arc(790, 62, 30, 0, Math.PI * 2); c.fill();
    c.fillStyle = "#e3d089"; c.beginPath(); c.arc(780, 54, 6, 0, Math.PI * 2); c.arc(800, 70, 4, 0, Math.PI * 2); c.fill();
  }
  obstacles.forEach(o => drawObstacle(c, o, th));
  // Jalan
  c.lineCap = "round"; c.lineJoin = "round";
  c.strokeStyle = th.edge; c.lineWidth = 74; strokePath(c);
  c.strokeStyle = th.road; c.lineWidth = 62; strokePath(c);
  c.strokeStyle = th.dash; c.lineWidth = 3; c.setLineDash([10, 12]); strokePath(c); c.setLineDash([]);
  drawBase(c, th);
}
let bgCache = null;
function drawBackground() {
  if (!bgCache) {
    try {
      bgCache = document.createElement("canvas");
      bgCache.width = W; bgCache.height = H;
      paintBackground(bgCache.getContext("2d"));
    } catch (e) { bgCache = null; paintBackground(ctx); return; }
  }
  ctx.drawImage(bgCache, 0, 0);
}

// ===============================
// KARAKTER CHIBI: semua unit digambar dengan kode (tanpa file gambar).
// Tiap unit = "look" (parameter penampilan). Skin nanti cukup mengganti warna di look.
// ===============================
const CB_OUT = "#241616";
function cbBlob(g, x, y, rx, ry, fill, lw = 3) {
  g.beginPath(); g.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
  if (fill) { g.fillStyle = fill; g.fill(); }
  if (lw) { g.lineWidth = lw; g.strokeStyle = CB_OUT; g.stroke(); }
}
function cbPoly(g, pts, fill, lw = 3) {
  g.beginPath(); pts.forEach((p, i) => (i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]))); g.closePath();
  if (fill) { g.fillStyle = fill; g.fill(); }
  if (lw) { g.lineWidth = lw; g.strokeStyle = CB_OUT; g.lineJoin = "round"; g.stroke(); }
}
function cbRect(g, x, y, w, h, r, fill, lw = 3) {
  g.beginPath();
  if (g.roundRect) g.roundRect(x, y, w, h, r); else g.rect(x, y, w, h);
  if (fill) { g.fillStyle = fill; g.fill(); }
  if (lw) { g.lineWidth = lw; g.strokeStyle = CB_OUT; g.stroke(); }
}
function cbGlow(g, x, y, r, color, a = 0.55) {
  g.save(); g.globalAlpha = a; g.fillStyle = color; g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill(); g.restore();
}
function cbFlame(g, x, y, s, t, c1 = "#ff8a3d", c2 = "#ffd166") {
  const w = Math.sin(t * 9) * 1.5 * s;
  cbPoly(g, [[x - 5 * s, y], [x - 6 * s, y - 7 * s], [x + w, y - 17 * s], [x + 6 * s, y - 7 * s], [x + 5 * s, y]], c1, 2);
  cbPoly(g, [[x - 2.5 * s, y], [x - 3 * s, y - 5 * s], [x + w * 0.6, y - 11 * s], [x + 3 * s, y - 5 * s], [x + 2.5 * s, y]], c2, 0);
}

// ---------- Senjata (koordinat lokal: tangan di (21,-24), menghadap kanan) ----------
let cbSwing = 0;
function cbWeapon(g, w, fl, t) {
  const c = w.c || "#8a5a2c", c2 = w.c2 || "#fff";
  g.save(); g.translate(21, -24);
  if (w.t === "bow") {
    g.beginPath(); g.arc(-4, 0, 22, -1.15, 1.15); g.lineWidth = 5; g.strokeStyle = CB_OUT; g.stroke();
    g.lineWidth = 2.6; g.strokeStyle = c; g.stroke();
    g.beginPath(); g.moveTo(-4 + 22 * Math.cos(-1.15), 22 * Math.sin(-1.15)); g.lineTo(-4 + 22 * Math.cos(1.15), 22 * Math.sin(1.15)); g.lineWidth = 1.4; g.strokeStyle = "#fff"; g.stroke();
    cbPoly(g, [[-6, -1.5], [18, -1.5], [24, 0], [18, 1.5], [-6, 1.5]], "#e8e0cf", 1.8);
    if (fl > 0) cbGlow(g, 26, 0, 8, "#fff6c0");
  } else if (w.t === "crossbow" || w.t === "ballista") {
    const big = w.t === "ballista" ? 1.35 : 1;
    g.scale(big, big);
    cbRect(g, -8, -3, 30, 6, 2, "#8a5a2c", 2.5);
    g.beginPath(); g.moveTo(14, -17); g.quadraticCurveTo(24, 0, 14, 17); g.lineWidth = 5; g.strokeStyle = CB_OUT; g.stroke();
    g.lineWidth = 2.6; g.strokeStyle = c; g.stroke();
    g.beginPath(); g.moveTo(14, -17); g.lineTo(6, 0); g.lineTo(14, 17); g.lineWidth = 1.4; g.strokeStyle = "#fff"; g.stroke();
    cbPoly(g, [[4, -1.5], [30, -1.5], [36, 0], [30, 1.5], [4, 1.5]], c2 === "#fff" ? "#e8e0cf" : c2, 1.8);
    if (fl > 0) cbGlow(g, 38, 0, 9, "#fff6c0");
  } else if (w.t === "staff" || w.t === "leafstaff") {
    g.rotate(0.1); cbRect(g, -2.5, -36, 5, 62, 2, "#8a5a2c", 2.5);
    if (w.t === "leafstaff") { cbPoly(g, [[0, -34], [-9, -44], [0, -58], [9, -44]], c, 2.5); g.beginPath(); g.moveTo(0, -36); g.lineTo(0, -54); g.lineWidth = 1.5; g.strokeStyle = "#ffffff99"; g.stroke(); }
    else { cbGlow(g, 0, -42, 12 + fl * 30, c, 0.28); cbBlob(g, 0, -42, 8, 8, c, 3); cbBlob(g, -2, -44, 2.5, 2.5, "#fff", 0); }
  } else if (w.t === "sword") {
    g.rotate(0.9); cbRect(g, -3.5, -40, 7, 34, 2, "#dfe8f2", 2.5); cbRect(g, -8, -8, 16, 5, 2, "#c99a2e", 2.5); cbRect(g, -2.5, -3, 5, 10, 2, "#7a4a2a", 2.5);
  } else if (w.t === "rifle") {
    cbRect(g, -10, -4, 16, 8, 3, "#6b4a2a", 2.5);
    cbRect(g, 4, -2.5, 40, 5, 2, "#3b4048", 2.5);
    cbRect(g, 14, -8, 12, 4, 2, "#222831", 2);
    if (fl > 0) { cbGlow(g, 46, 0, 12, "#ffe9a8"); }
  } else if (w.t === "torch") {
    g.rotate(0.25); cbRect(g, -2.5, -26, 5, 38, 2, "#6b3a1a", 2.5);
    cbFlame(g, 0, -26, 1.3 + fl * 4, t, w.c || "#ff8a3d", "#ffd166");
    if (fl > 0) cbGlow(g, 0, -32, 22, "#ff9a3d", 0.45);
  } else if (w.t === "flask") {
    g.translate(8, -14);
    cbRect(g, -3, -14, 6, 8, 2, "#dfe8f2", 2.5);
    cbBlob(g, 0, 0, 10, 10, c, 3); cbBlob(g, -3, -3, 3, 3, "#ffffffaa", 0);
    cbBlob(g, 3 + Math.sin(t * 5) * 2, -16 - ((t * 20) % 8), 2.5, 2.5, c + "cc", 1.5);
    if (fl > 0) cbGlow(g, 0, 0, 16, c, 0.5);
  } else if (w.t === "coil") {
    g.rotate(0.1); cbRect(g, -3, -26, 6, 44, 2, "#59616e", 2.5);
    for (let i = 0; i < 3; i++) cbRect(g, -6, -22 + i * 8, 12, 4, 2, "#c98a3a", 2);
    cbBlob(g, 0, -32, 8, 8, c, 3); cbGlow(g, 0, -32, 12 + fl * 30, c, 0.35);
    g.beginPath(); g.moveTo(0, -38); g.lineTo(5, -44); g.lineTo(1, -46); g.lineTo(7, -54); g.lineWidth = 2; g.strokeStyle = (Math.floor(t * 12) % 2) ? "#fff" : c; g.stroke();
  } else if (w.t === "orb") {
    const f = Math.sin(t * 3) * 2.5;
    g.translate(2, -26 + f); cbGlow(g, 0, 0, 14 + fl * 30, c, 0.3); cbBlob(g, 0, 0, 9, 9, c, 3); cbBlob(g, -3, -3, 3, 3, "#ffffffbb", 0);
  } else if (w.t === "scythe") {
    if (cbSwing > 0) { const p = 1 - cbSwing / 0.3; g.translate(0, 8); g.rotate(0.15 + (-1.5 + 3.4 * Math.min(1, p * 1.5)) * (1 - Math.max(0, p - 0.65) * 1.2)); g.translate(0, -8); }
    else g.rotate(0.15);
    cbRect(g, -2.5, -46, 5, 74, 2, "#6b5a4a", 2.5);
    g.beginPath(); g.moveTo(0, -46); g.quadraticCurveTo(26, -52, 30, -26); g.quadraticCurveTo(18, -40, 0, -38); g.closePath(); g.fillStyle = "#d8dcef"; g.fill(); g.lineWidth = 2.5; g.strokeStyle = CB_OUT; g.stroke();
    if (fl > 0) cbGlow(g, 20, -40, 16, "#aab0d8", 0.5);
  } else if (w.t === "hourglass") {
    const sp = Math.sin(t * 2) * 6;
    g.translate(4, -24 + sp * 0.2); g.rotate(sp * 0.004);
    cbRect(g, -9, -17, 18, 4, 2, "#c99a2e", 2.5); cbRect(g, -9, 13, 18, 4, 2, "#c99a2e", 2.5);
    cbPoly(g, [[-7, -13], [7, -13], [1.5, 0], [7, 13], [-7, 13], [-1.5, 0]], "#bfeee8cc", 2.5);
    cbPoly(g, [[-5, 11], [5, 11], [0, 5]], c, 0); g.fillStyle = c; g.fillRect(-.8, -6, 1.6, 8);
    if (fl > 0) cbGlow(g, 0, 0, 18, c, 0.45);
  } else if (w.t === "sling") {
    g.translate(4, -10);
    g.beginPath(); g.moveTo(0, 14); g.lineTo(0, -2); g.moveTo(0, -2); g.lineTo(-9, -16); g.moveTo(0, -2); g.lineTo(9, -16);
    g.lineWidth = 6; g.strokeStyle = CB_OUT; g.lineCap = "round"; g.stroke(); g.lineWidth = 3.4; g.strokeStyle = c; g.stroke();
    const pull = fl > 0 ? 0 : 7;
    g.beginPath(); g.moveTo(-9, -16); g.lineTo(0, -16 + pull); g.lineTo(9, -16); g.lineWidth = 1.8; g.strokeStyle = "#7a1d0a"; g.stroke();
    if (!fl) cbBlob(g, 0, -17 + pull, 3.6, 3.6, "#9a9aa4", 1.5); else cbGlow(g, 0, -24, 9, "#fff3c0", 0.5);
  } else if (w.t === "firecracker") {
    g.rotate(0.2); g.translate(2, -12);
    for (let i = -1; i <= 1; i++) cbRect(g, i * 6 - 3, -20 + Math.abs(i) * 2, 6, 22, 2, i ? "#d93a3a" : "#e8503a", 2);
    g.beginPath(); g.moveTo(0, -21); g.quadraticCurveTo(5, -27, 2, -31); g.lineWidth = 1.6; g.strokeStyle = "#3a2a1a"; g.stroke();
    cbBlob(g, 2, -32 - ((t * 6) % 2), 2.6 + Math.sin(t * 20), 2.6, (Math.floor(t * 8) % 2) ? "#ffd166" : "#fff6a8", 1);
    if (fl > 0) cbGlow(g, 0, -28, 16, "#ffd08a", 0.6);
  } else if (w.t === "coinbag") {
    g.translate(8, -12);
    cbBlob(g, 0, 0, 11, 11, "#a8742a", 3); cbRect(g, -5, -16, 10, 6, 2, "#c98a3a", 2.5);
    g.fillStyle = "#ffd166"; g.font = "bold 13px system-ui"; g.textAlign = "center"; g.fillText("$", 0, 5);
    const k = (t * 1.5) % 1; g.globalAlpha = 1 - k; cbBlob(g, 6, -18 - k * 14, 3.4, 3.4, "#ffd166", 1.5); g.globalAlpha = 1;
  } else if (w.t === "wand") {
    g.rotate(0.5); cbRect(g, -2, -26, 4, 34, 2, "#6b3a1a", 2); cbBlob(g, 0, -28, 5, 5, c, 2.5);
  }
  g.restore();
}

// ---------- Topi / rambut ----------
function cbHairBack(g, h) {
  if (!h) return;
  if (h.s === "long") { cbBlob(g, -17, 9, 8, 17, h.c); cbBlob(g, 17, 9, 8, 17, h.c); cbBlob(g, 0, -2, 22, 20, h.c); }
  else if (h.s === "bun") { cbBlob(g, 0, -17, 9, 9, h.c); }
}
function cbHairFront(g, h) {
  if (!h || h.s === "none") return;
  if (h.s === "spiky") {
    cbPoly(g, [[-21, -3], [-22, -16], [-14, -13], [-13, -26], [-5, -17], [0, -31], [5, -17], [13, -26], [14, -13], [22, -16], [21, -3], [12, -9], [4, -4], [-3, -10], [-12, -5]], h.c);
  } else {
    cbPoly(g, [[-21, -3], [-17, -17], [0, -22], [17, -17], [21, -3], [12, -9], [4, -4], [-3, -10], [-12, -5]], h.c);
  }
}
function cbHat(g, h, t) {
  if (!h) return;
  const c = h.c, a = h.a || "#ffd166";
  switch (h.t) {
    case "cap":
      cbPoly(g, [[-23, -6], [-18, -22], [0, -30], [18, -22], [23, -6], [8, -12], [-8, -12]], c);
      cbPoly(g, [[8, -24], [26, -34], [20, -20]], a, 2); break;
    case "wizard":
      cbPoly(g, [[-26, -10], [26, -10], [10, -14], [-6, -48], [-12, -14]], c); cbRect(g, -27, -14, 54, 8, 4, c);
      cbRect(g, -13, -18, 26, 5, 2, a, 2); cbBlob(g, 0, -14, 3, 3, "#ffe36b", 1.5); break;
    case "witch":
      cbPoly(g, [[-30, -9], [30, -9], [11, -13], [4, -38], [18, -52], [-8, -42], [-12, -13]], c); cbRect(g, -31, -13, 62, 8, 4, c);
      cbRect(g, -12, -18, 24, 5, 2, a, 2); cbRect(g, -3, -19, 6, 7, 1, "#ffe36b", 1.5); break;
    case "helm":
      cbPoly(g, [[-23, -4], [-21, -22], [0, -29], [21, -22], [23, -4], [14, -8], [-14, -8]], c);
      cbRect(g, -3, -30, 6, 26, 2, a, 2);
      if (h.p) cbPoly(g, [[0, -30], [12, -42 + Math.sin(t * 6) * 1.5], [16, -30]], h.p, 2.5); break;
    case "hood":
      cbPoly(g, [[-25, 6], [-24, -16], [-12, -29], [0, -32], [12, -29], [24, -16], [25, 6], [17, -5], [14, -15], [0, -20], [-14, -15], [-17, -5]], c);
      if (h.scarf) cbRect(g, -16, 13, 32, 8, 4, h.scarf); break;
    case "horns":
      cbPoly(g, [[-25, 6], [-24, -16], [-12, -27], [0, -29], [12, -27], [24, -16], [25, 6], [17, -5], [14, -15], [0, -20], [-14, -15], [-17, -5]], c);
      cbPoly(g, [[-18, -22], [-30, -42], [-9, -28]], a, 2.5); cbPoly(g, [[18, -22], [30, -42], [9, -28]], a, 2.5); break;
    case "goggles":
      cbRect(g, -22, -13, 44, 6, 2, c, 2.5);
      cbBlob(g, -9, -17, 8, 7, "#cfeeff", 2.5); cbBlob(g, 9, -17, 8, 7, "#cfeeff", 2.5);
      cbBlob(g, -9, -17, 4.5, 4, a, 0); cbBlob(g, 9, -17, 4.5, 4, a, 0); break;
    case "headband":
      cbRect(g, -22, -14, 44, 7, 2, c, 2.5); cbPoly(g, [[-21, -11], [-34, -6 + Math.sin(t * 5) * 2], [-33, -16], [-21, -14]], c, 2); break;
    case "leaf":
      for (let i = -2; i <= 2; i++) cbPoly(g, [[i * 8, -18], [i * 8 - 6, -26 - (2 - Math.abs(i)) * 2], [i * 8, -34 - (2 - Math.abs(i)) * 3], [i * 8 + 6, -26 - (2 - Math.abs(i)) * 2]], i % 2 ? a : c, 2); break;
    case "hardhat":
      cbPoly(g, [[-24, -6], [-20, -22], [0, -29], [20, -22], [24, -6]], c); cbRect(g, -26, -9, 52, 6, 3, c); cbBlob(g, 0, -20, 4, 4, "#fff6a8", 2); break;
    case "mask":
      cbRect(g, -14, 3, 28, 17, 6, c, 3); cbBlob(g, 0, 14, 5, 5, a, 2.5);
      cbRect(g, -22, -13, 44, 6, 2, "#3a3a3a", 2.5); cbBlob(g, -9, -17, 7, 6, "#bff4ff", 2.5); cbBlob(g, 9, -17, 7, 6, "#bff4ff", 2.5); break;
    case "crown":
      cbPoly(g, [[-18, -14], [-20, -30], [-9, -22], [0, -34], [9, -22], [20, -30], [18, -14]], c); cbBlob(g, 0, -22, 3, 3, a, 1.5); break;
  }
}

// ---------- Karakter manusia ----------
function cbHuman(g, L, st) {
  const t = st.t, fl = st.flash;
  const skin = L.skin || "#ffd7b0", outfit = L.outfit || "#888", trim = L.trim || "#d6a23a", boots = L.boots || "#6b3f22";
  if (L.cape) cbPoly(g, [[-13, -34], [13, -34], [20, -4], [-20, -4]], L.cape);
  if (L.wings) { const f = Math.sin(t * 9) * 6; cbPoly(g, [[-8, -30], [-34, -42 - f], [-26, -22], [-14, -16]], L.wings, 2.5); cbPoly(g, [[8, -30], [34, -42 - f], [26, -22], [14, -16]], L.wings, 2.5); }
  cbRect(g, -13, -14, 10, 14, 4, boots); cbRect(g, 3, -14, 10, 14, 4, boots);
  cbRect(g, -15, -36, 30, 26, 8, outfit);
  if (L.armor) { cbRect(g, -17, -37, 12, 8, 4, L.armor, 2.5); cbRect(g, 5, -37, 12, 8, 4, L.armor, 2.5); }
  g.fillStyle = trim; g.fillRect(-15, -20, 30, 5); g.lineWidth = 2; g.strokeStyle = CB_OUT; g.strokeRect(-15, -20, 30, 5);
  if (L.emblem) cbBlob(g, 0, -29, 4, 4, L.emblem, 2);
  cbBlob(g, -17, -27, 6, 8, outfit, 2.5); cbBlob(g, -17, -20, 5, 5, skin, 2.5);
  if (L.weapon) cbWeapon(g, L.weapon, fl, t);
  g.save(); g.translate(0, -52);
  if (L.hat && (L.hat.t === "hood" || L.hat.t === "horns")) { cbBlob(g, 0, 2, 23, 21, L.hat.c); }
  cbHairBack(g, L.hair);
  if (L.face === "skull") {
    cbBlob(g, 0, 0, 21, 19, "#f1f1f6");
    cbBlob(g, -8, 0, 5.5, 6.5, "#1a1220", 1.5); cbBlob(g, 8, 0, 5.5, 6.5, "#1a1220", 1.5);
    cbBlob(g, -8, 0, 1.8, 1.8, "#ff4d6d", 0); cbBlob(g, 8, 0, 1.8, 1.8, "#ff4d6d", 0);
    cbPoly(g, [[-2.5, 7], [2.5, 7], [0, 3]], "#1a1220", 1.5);
    for (let i = -2; i <= 2; i++) { g.beginPath(); g.moveTo(i * 3.4, 11); g.lineTo(i * 3.4, 16); g.lineWidth = 1.6; g.strokeStyle = CB_OUT; g.stroke(); }
  } else {
    cbBlob(g, 0, 0, 21, 19, skin);
    g.globalAlpha = 0.55; cbBlob(g, -12, 6, 4.2, 2.6, "#ff7d86", 0); cbBlob(g, 12, 6, 4.2, 2.6, "#ff7d86", 0); g.globalAlpha = 1;
    const ec = L.eye || "#1a1220";
    cbBlob(g, -8, 1, 3.4, 4.6, ec, 1.5); cbBlob(g, 8, 1, 3.4, 4.6, ec, 1.5);
    cbBlob(g, -7, -0.6, 1.3, 1.6, "#fff", 0); cbBlob(g, 9, -0.6, 1.3, 1.6, "#fff", 0);
    if (L.fangs) { g.beginPath(); g.arc(0, 8, 3.4, 0.15, Math.PI - 0.15); g.lineWidth = 1.8; g.strokeStyle = CB_OUT; g.stroke(); cbPoly(g, [[-3.2, 9.5], [-1.4, 9.8], [-2.4, 13.5]], "#fff", 1.2); cbPoly(g, [[3.2, 9.5], [1.4, 9.8], [2.4, 13.5]], "#fff", 1.2); }
    else { g.beginPath(); g.arc(0, 8, 2.6, 0.15, Math.PI - 0.15); g.lineWidth = 1.8; g.strokeStyle = CB_OUT; g.stroke(); }
    cbHairFront(g, L.hair);
  }
  cbHat(g, L.hat, t);
  g.restore();
  cbBlob(g, 17, -27, 6, 8, outfit, 2.5); cbBlob(g, 19, -20, 5, 5, skin, 2.5);
  if (L.bats) for (let i = 0; i < 2; i++) { const a = t * 2.2 + i * Math.PI; const bx = Math.cos(a) * 26, by = -52 + Math.sin(a) * 9; cbPoly(g, [[bx - 7, by - 3 - Math.sin(t * 14) * 3], [bx, by + 2], [bx + 7, by - 3 - Math.sin(t * 14) * 3], [bx + 3, by + 4], [bx - 3, by + 4]], "#3a1a3a", 1.8); }
}

// ---------- Bentuk non-manusia ----------
function cbFaceSimple(g, x, y, s = 1, ec = "#1a1220") {
  cbBlob(g, x - 6 * s, y, 2.8 * s, 3.8 * s, ec, 1.5); cbBlob(g, x + 6 * s, y, 2.8 * s, 3.8 * s, ec, 1.5);
  cbBlob(g, x - 5 * s, y - 1.2 * s, 1 * s, 1.3 * s, "#fff", 0); cbBlob(g, x + 7 * s, y - 1.2 * s, 1 * s, 1.3 * s, "#fff", 0);
  g.beginPath(); g.arc(x, y + 6 * s, 2.4 * s, 0.15, Math.PI - 0.15); g.lineWidth = 1.6; g.strokeStyle = CB_OUT; g.stroke();
}
function cbGunner(g, L, st) { // penembak kecil di belakang meriam
  g.save(); g.translate(-14, -14);
  cbRect(g, -9, -16, 18, 18, 6, L.outfit || "#5b6b8a");
  cbBlob(g, 0, -28, 14, 13, L.skin || "#ffd7b0"); cbFaceSimple(g, 0, -28, 0.8);
  g.save(); g.translate(0, -28); g.scale(0.7, 0.7); cbHat(g, { t: L.hatT || "hardhat", c: L.hat || "#c99a2e", a: "#ffd166", p: L.plume }, st.t); g.restore();
  g.restore();
}
function cbCannon(g, L, st) {
  const big = L.big ? 1.35 : 1, fl = st.flash, c = L.c || "#6c7686";
  g.save(); g.scale(big, big);
  cbGunner(g, L, st);
  const recoil = fl * -30;
  g.save(); g.translate(recoil, 0);
  if (L.mortar) {
    g.save(); g.translate(8, -14); g.rotate(-0.35);
    cbPoly(g, [[-9, 4], [-6, -26], [6, -26], [9, 4]], c); cbRect(g, -8, -29, 16, 6, 3, "#3b4048", 2.5);
    if (fl > 0) cbGlow(g, 0, -34, 12, "#ffd08a"); g.restore();
  } else {
    cbRect(g, -2, -26, 36, 14, 6, c); cbRect(g, 28, -29, 10, 20, 4, "#3b4048", 2.5);
    cbBlob(g, 38, -19, 2.5, 5, "#14171c", 0);
    if (L.fins) { cbPoly(g, [[0, -26], [-8, -34], [6, -26]], L.fins, 2); }
    if (fl > 0) cbGlow(g, 44, -19, 14, "#ffd08a");
  }
  g.restore();
  cbBlob(g, 4, -6, 11, 11, "#7a5a36", 3); cbBlob(g, 4, -6, 3.5, 3.5, "#3a2a16", 1.5);
  cbBlob(g, 26, -6, 11, 11, "#7a5a36", 3); cbBlob(g, 26, -6, 3.5, 3.5, "#3a2a16", 1.5);
  g.restore();
}
function cbTotem(g, L, st) {
  const t = st.t, cols = L.cols || ["#8fd6a5", "#d6a23a", "#c0584a"];
  cbRect(g, -16, -12, 32, 12, 4, "#6c5a44");
  for (let i = 0; i < 3; i++) {
    const y = -26 - i * 20;
    cbRect(g, -14, y - 10, 28, 20, 5, cols[i % 3]);
    cbBlob(g, -6, y - 2, 3, 3.6, "#1a1220", 1.5); cbBlob(g, 6, y - 2, 3, 3.6, "#1a1220", 1.5);
    g.beginPath(); g.moveTo(-5, y + 5); g.lineTo(5, y + 5); g.lineWidth = 2; g.strokeStyle = CB_OUT; g.stroke();
  }
  cbPoly(g, [[-24, -48], [-14, -56], [-14, -42]], "#d6584a", 2.5); cbPoly(g, [[24, -48], [14, -56], [14, -42]], "#4a8fd0", 2.5);
  cbGlow(g, 0, -50, 20 + Math.sin(t * 3) * 3, cols[0], 0.18);
}
function cbMine(g, L, st) {
  const t = st.t, M = L.m || "#7a5a36", X = L.x || "#ffd166", X2 = L.x ? cbShade(L.x, 0.3) : "#ffe58a";
  g.save(); g.translate(-12, 0);
  cbPoly(g, [[-16, -26], [28, -26], [22, -6], [-10, -6]], M); cbBlob(g, -6, -4, 6, 6, "#3a2a16", 2.5); cbBlob(g, 16, -4, 6, 6, "#3a2a16", 2.5);
  for (let i = 0; i < 4; i++) cbBlob(g, -8 + i * 8, -28 - (i % 2) * 3, 5, 4.5, i % 2 ? X : X2, 2);
  g.restore();
  g.save(); g.translate(18, 0);
  cbRect(g, -9, -34, 18, 26, 6, "#5a7a9a");
  cbBlob(g, 0, -46, 13, 12, "#ffd7b0"); cbFaceSimple(g, 0, -46, 0.75);
  g.save(); g.translate(0, -46); g.scale(0.65, 0.65); cbHat(g, { t: "hardhat", c: "#e0a02e" }, t); g.restore();
  const sw = Math.sin(t * 4) * 0.4; g.save(); g.translate(10, -28); g.rotate(-0.6 + sw);
  cbRect(g, -1.5, -22, 3, 30, 1.5, "#6b3a1a", 2); cbPoly(g, [[-12, -22], [12, -22], [8, -26], [-8, -26]], "#c0c6d0", 2); g.restore();
  g.restore();
  cbBlob(g, 0, -64, 3, 3, (Math.floor(t * 4) % 2) ? "#ffd166" : "#fff6a8", 1.5);
}
function cbSpider(g, L, st) {
  const t = st.t, c = L.c || "#e6e6ee";
  for (let i = 0; i < 4; i++) for (const sx of [-1, 1]) {
    const a = 0.35 + i * 0.28, w = Math.sin(t * 6 + i) * 2;
    g.beginPath(); g.moveTo(sx * 8, -20); g.lineTo(sx * (22 + i * 2), -30 + i * 8 + w); g.lineTo(sx * (28 + i * 3), -10 + i * 3);
    g.lineWidth = 5; g.strokeStyle = CB_OUT; g.stroke(); g.lineWidth = 2.6; g.strokeStyle = "#555a66"; g.stroke();
  }
  cbBlob(g, 0, -18, 17, 14, "#3a3f4c"); cbBlob(g, 0, -14, 9, 7, "#555a66", 0);
  cbBlob(g, 0, -38, 16, 14, c); cbFaceSimple(g, 0, -38, 0.85);
  cbBlob(g, -9, -48, 2, 2, "#1a1220", 0); cbBlob(g, 9, -48, 2, 2, "#1a1220", 0);
  // jaring kecil di tanah
  g.save(); g.globalAlpha = 0.5; g.strokeStyle = "#fff"; g.lineWidth = 1;
  for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3; g.beginPath(); g.moveTo(0, 4); g.lineTo(Math.cos(a) * 34, 4 + Math.sin(a) * 12); g.stroke(); }
  g.restore();
}
function cbGhost(g, L, st) {
  const t = st.t, f = Math.sin(t * 3) * 3;
  g.save(); g.translate(0, f - 6); g.globalAlpha = 0.95;
  g.beginPath(); g.moveTo(-18, -22); g.quadraticCurveTo(-18, -62, 0, -62); g.quadraticCurveTo(18, -62, 18, -22);
  g.lineTo(18, -4); for (let i = 0; i < 4; i++) g.quadraticCurveTo(14 - i * 9, 6 + (i % 2) * -4, 9 - i * 9, -4);
  g.lineTo(-18, -4); g.closePath(); g.fillStyle = L.c || "#dce9ff"; g.fill(); g.lineWidth = 3; g.strokeStyle = CB_OUT; g.stroke();
  cbFaceSimple(g, 0, -40, 1.05, "#1a1a3a");
  cbBlob(g, -12, -34, 4, 2.6, "#ffa0b8aa", 0); cbBlob(g, 12, -34, 4, 2.6, "#ffa0b8aa", 0);
  g.globalAlpha = 1; cbBlob(g, -22, -24 + Math.sin(t * 4) * 2, 6, 5, L.c || "#dce9ff", 2.5); cbBlob(g, 22, -24 - Math.sin(t * 4) * 2, 6, 5, L.c || "#dce9ff", 2.5);
  g.restore();
  cbGlow(g, 0, -30, 30, "#bcd4ff", 0.12);
}
function cbPumpkin(g, L, st) {
  const t = st.t, fl = st.flash, M = L.m || "#f28c1e", M2 = L.m ? cbShade(L.m, 0.15) : "#ff9d2e", X = L.x || "#ffd166";
  cbRect(g, -12, -12, 9, 12, 4, "#6b3f22"); cbRect(g, 3, -12, 9, 12, 4, "#6b3f22");
  cbBlob(g, 0, -30, 25, 20, M); cbBlob(g, -12, -30, 12, 19, M2, 2); cbBlob(g, 12, -30, 12, 19, M2, 2);
  cbPoly(g, [[-3, -50], [3, -50], [5, -58], [-1, -60]], "#4a8a2e", 2.5);
  cbPoly(g, [[-14, -34], [-6, -34], [-10, -42]], "#2a1608", 1); cbPoly(g, [[6, -34], [14, -34], [10, -42]], "#2a1608", 1);
  g.beginPath(); g.moveTo(-12, -24); g.lineTo(-7, -19); g.lineTo(-3, -24); g.lineTo(3, -19); g.lineTo(7, -24); g.lineTo(12, -24); g.lineTo(8, -16); g.lineTo(-8, -16); g.closePath(); g.fillStyle = "#2a1608"; g.fill();
  cbGlow(g, 0, -30, 14, X, 0.35 + Math.sin(t * 6) * 0.1 + fl * 2);
  cbBlob(g, 24, -22, 6, 7, M, 2.5);
}
function cbCandle(g, L, st) {
  const t = st.t, fl = st.flash, M = L.m || "#fff1c9", X = L.x || "#ff8a3d";
  cbRect(g, -12, -12, 9, 12, 4, "#6b3f22"); cbRect(g, 3, -12, 9, 12, 4, "#6b3f22");
  cbRect(g, -14, -52, 28, 42, 9, M);
  g.fillStyle = "#ffffff99"; g.fillRect(-9, -48, 4, 30);
  cbBlob(g, -10, -44, 5, 7, "#f6e3a8", 0);
  cbFaceSimple(g, 0, -33, 0.95);
  cbBlob(g, -10, -26, 3.5, 2.2, "#ffa0a0aa", 0); cbBlob(g, 10, -26, 3.5, 2.2, "#ffa0a0aa", 0);
  cbFlame(g, 0, -52, 1.2 + fl * 5, t, X, "#ffd166"); cbGlow(g, 0, -60, 18, X, 0.25 + fl * 3);
  cbBlob(g, -19, -30, 5, 6, M, 2.5); cbBlob(g, 19, -30, 5, 6, M, 2.5);
}
function cbMoon(g, L, st) {
  const t = st.t, M = L.m || "#e0364a", M2 = cbShade(M, -0.25), X = L.x || "#ff2d55";
  cbRect(g, -16, -12, 32, 12, 4, "#4a2a34"); cbRect(g, -9, -24, 18, 14, 3, "#6a3a46");
  const f = Math.sin(t * 2) * 2.5;
  cbGlow(g, 0, -50 + f, 30, X, 0.22);
  cbBlob(g, 0, -50 + f, 20, 20, M);
  cbBlob(g, -7, -58 + f, 5, 4, M2, 0); cbBlob(g, 9, -44 + f, 4, 3.5, M2, 0);
  cbFaceSimple(g, 0, -50 + f, 1, "#2a0a14");
  cbBlob(g, 0, -50 + f, 20, 20, null, 3);
}
function cbPhoenix(g, L, st) {
  const M = L.m || "#ff7a2e", M2 = L.m ? cbShade(L.m, 0.12) : M2, M3 = cbShade(M, -0.2), X = L.x || X, t = st.t, fl = st.flash, f = Math.sin(t * 5) * 3, w = Math.sin(t * 10) * 9;
  cbGlow(g, 0, -34, 30 + fl * 40, M, 0.2);
  cbPoly(g, [[-6, -30], [-42, -50 - w], [-34, -26], [-16, -16]], M2, 2.5); cbPoly(g, [[6, -30], [42, -50 - w], [34, -26], [16, -16]], M2, 2.5);
  cbPoly(g, [[-30, -34], [-40, -44 - w * 0.7], [-26, -28]], X, 1.5); cbPoly(g, [[30, -34], [40, -44 - w * 0.7], [26, -28]], X, 1.5);
  cbPoly(g, [[-12, -18], [-6, 2 + f], [0, -10], [6, 2 + f], [12, -18]], M3, 2.5);
  cbBlob(g, 0, -28 + f * 0.5, 16, 19, M);
  cbBlob(g, 0, -22 + f * 0.5, 10, 11, X, 0);
  cbBlob(g, 0, -50 + f * 0.5, 13, 12, M);
  cbPoly(g, [[-3, -50], [3, -50], [0, -44]], X, 2);
  cbBlob(g, -5, -53 + f * 0.5, 2.4, 3, "#1a1220", 1); cbBlob(g, 5, -53 + f * 0.5, 2.4, 3, "#1a1220", 1);
  cbPoly(g, [[-5, -60], [-2, -70], [1, -60]], "#ff4d1a", 2); cbPoly(g, [[0, -60], [4, -72], [7, -60]], "#ffb347", 2);
}
function cbGrave(g, L, st) {
  const t = st.t;
  cbBlob(g, 0, -2, 26, 8, "#3b4a35", 3);
  g.beginPath(); g.moveTo(-14, -2); g.lineTo(-14, -30); g.arc(0, -30, 14, Math.PI, 0); g.lineTo(14, -2); g.closePath(); g.fillStyle = L.m || "#9a97a8"; g.fill(); g.lineWidth = 3; g.strokeStyle = CB_OUT; g.stroke();
  g.strokeStyle = "#575466"; g.lineWidth = 2.6; g.beginPath(); g.moveTo(0, -38); g.lineTo(0, -20); g.moveTo(-6, -32); g.lineTo(6, -32); g.stroke();
  const up = (Math.sin(t * 2) + 1) * 3;
  cbRect(g, 15, -22 - up, 7, 18 + up, 3, "#7fb26a", 2.5); cbBlob(g, 18.5, -24 - up, 5, 5, "#7fb26a", 2.5);
}
function cbBarrack(g, L, st) {
  cbRect(g, -22, -32, 44, 34, 6, "#8a6a46"); cbRect(g, -17, -26, 34, 28, 4, "#d6b47a");
  cbPoly(g, [[-28, -30], [0, -56], [28, -30]], L.m || "#a0432e");
  cbRect(g, -6, -14, 12, 16, 5, "#5a3322");
  cbPoly(g, [[10, -52], [10, -66], [24, -60]], L.x || "#d93a3a", 2); g.beginPath(); g.moveTo(10, -52); g.lineTo(10, -42); g.lineWidth = 2.5; g.strokeStyle = CB_OUT; g.stroke();
  cbRect(g, -16, -24, 8, 8, 2, "#7a5a36", 2); cbRect(g, 8, -24, 8, 8, 2, "#7a5a36", 2);
}

// ---------- Daftar tampilan semua unit ----------
const chibiLooks = {
  archer:   { kind: "human", outfit: "#e08a2e", hair: { c: "#4a2c1a", s: "short" }, hat: { t: "cap", c: "#2f8f5b", a: "#ff5a5a" }, weapon: { t: "bow", c: "#b97a3c" } },
  cannon:   { kind: "cannon", c: "#6c7686", hat: "#c99a2e", hatT: "hardhat", outfit: "#5b6b8a" },
  ice:      { kind: "human", outfit: "#6fc0f0", trim: "#e8fbff", boots: "#3b5a86", skin: "#ffe6d2", hair: { c: "#cfefff", s: "long" }, hat: { t: "crown", c: "#bfeaff", a: "#7ad7ff" }, weapon: { t: "staff", c: "#bff4ff" } },
  poison:   { kind: "human", outfit: "#6a9a3a", trim: "#a7e36b", hair: { c: "#2c3a1a", s: "spiky" }, hat: { t: "goggles", c: "#4a5a2a", a: "#a7e36b" }, weapon: { t: "flask", c: "#a7e36b" } },
  magic:    { kind: "human", outfit: "#5b4fc7", trim: "#d6a23a", hair: { c: "#e8e0f0", s: "long" }, hat: { t: "wizard", c: "#3d3499", a: "#ffd166" }, weapon: { t: "staff", c: "#58e0ff" } },
  sniper:   { kind: "human", outfit: "#6b6b4a", trim: "#b8a06a", hair: { c: "#2a2a2a", s: "short" }, hat: { t: "hood", c: "#4a5a3a", scarf: "#c0584a" }, weapon: { t: "rifle" } },
  tesla:    { kind: "human", outfit: "#4a6fa5", trim: "#ffe36b", hair: { c: "#ffe9a0", s: "spiky" }, hat: { t: "goggles", c: "#59616e", a: "#7ce7ff" }, weapon: { t: "coil", c: "#7ce7ff" } },
  barrack:  { kind: "barrack" },
  flame:    { kind: "human", outfit: "#d9501e", trim: "#ffb347", hair: { c: "#ff8a3d", s: "spiky" }, hat: { t: "headband", c: "#7a1d0a" }, weapon: { t: "torch", c: "#ff8a3d" } },
  ballista: { kind: "human", outfit: "#8b6b3a", trim: "#d6a23a", hair: { c: "#6b3a1a", s: "short" }, hat: { t: "helm", c: "#b8a06a", a: "#7a5a2a" }, weapon: { t: "ballista", c: "#8a5a2c", c2: "#e8d9a8" } },
  totem:    { kind: "totem" },
  mine:     { kind: "mine" },
  mortar:   { kind: "cannon", mortar: true, c: "#a58a5a", hat: "#8c97a6", hatT: "hardhat", outfit: "#7a5a36" },
  hexer:    { kind: "human", outfit: "#5a2a7a", trim: "#c58bff", skin: "#f3dcff", hair: { c: "#c58bff", s: "long" }, hat: { t: "horns", c: "#3a1a55", a: "#c58bff" }, eye: "#7a1d8a", weapon: { t: "orb", c: "#c58bff" } },
  druid:    { kind: "human", outfit: "#3f8a4a", trim: "#d6c06a", hair: { c: "#8bd06a", s: "long" }, hat: { t: "leaf", c: "#4fa04a", a: "#72d18b" }, weapon: { t: "leafstaff", c: "#72d18b" } },
  pumpkin:  { kind: "pumpkin" },
  candle:   { kind: "candle" },
  ghost:    { kind: "ghost", c: "#dce9ff" },
  web:      { kind: "spider", c: "#e6e6ee" },
  graveyard:{ kind: "grave" },
  witch:    { kind: "human", outfit: "#3a2a5a", trim: "#b44cff", hair: { c: "#b44cff", s: "long" }, hat: { t: "witch", c: "#2a1a44", a: "#b44cff" }, weapon: { t: "flask", c: "#b44cff" } },
  vampire:  { kind: "human", outfit: "#2a1a2a", trim: "#c1243e", skin: "#f4e8ee", cape: "#c1243e", hair: { c: "#1a1020", s: "short" }, eye: "#c1243e", fangs: true, bats: true, weapon: { t: "orb", c: "#d1304a" } },
  reaper:   { kind: "human", outfit: "#2a2c3a", trim: "#8b8fa8", face: "skull", cape: "#1c1e2c", hat: { t: "hood", c: "#1c1e2c" }, weapon: { t: "scythe" } },
  bloodmoon:{ kind: "moon" },
  titan:    { kind: "cannon", big: true, c: "#6fb7ff", fins: "#ff6a4a", hat: "#e0a02e", hatT: "hardhat", outfit: "#2a4a7a" },
  chrono:   { kind: "human", outfit: "#2a8f86", trim: "#bfeee8", hair: { c: "#7be0d0", s: "long" }, hat: { t: "crown", c: "#7be0d0", a: "#fff" }, weapon: { t: "hourglass", c: "#7be0d0" } },
  phoenix:  { kind: "phoenix" },
  // evolusi
  blazed:   { kind: "human", outfit: "#8a1a0a", trim: "#ffb347", armor: "#c43a1a", emblem: "#ffb347", cape: "#ff5a1f", hair: { c: "#ff4a1f", s: "spiky" }, hat: { t: "horns", c: "#4a1008", a: "#ffb347" }, eye: "#7a0a00", weapon: { t: "torch", c: "#ff5a1f" } },
  toxic:    { kind: "human", outfit: "#3a5a2a", trim: "#7dff3a", armor: "#59712f", emblem: "#7dff3a", hair: { c: "#1f2a12", s: "short" }, hat: { t: "mask", c: "#556b3a", a: "#7dff3a" }, weapon: { t: "flask", c: "#7dff3a" } },
  howitzer: { kind: "cannon", mortar: true, big: true, c: "#5a6b4a", fins: "#ffcf4a", hat: "#c43a1a", hatT: "hardhat", outfit: "#3a4a2a" },
  blizzard: { kind: "human", outfit: "#3a8ad8", trim: "#ffffff", boots: "#1f3f6a", skin: "#ffe6d2", armor: "#bfe8ff", emblem: "#ffffff", cape: "#e8fbff", hair: { c: "#ffffff", s: "long" }, hat: { t: "crown", c: "#e8fbff", a: "#4ad0ff" }, weapon: { t: "staff", c: "#7ae0ff" } },
  storm:    { kind: "human", outfit: "#2a3f9a", trim: "#ffe36b", boots: "#14204a", armor: "#5a6ad0", emblem: "#ffe36b", cape: "#1a2a6a", hair: { c: "#fff2a0", s: "spiky" }, hat: { t: "goggles", c: "#2a3f9a", a: "#ffe36b" }, weapon: { t: "coil", c: "#ffe36b" } },
  railgun:  { kind: "human", outfit: "#2a2f3a", trim: "#7af0ff", boots: "#14161c", armor: "#3a4252", emblem: "#7af0ff", hair: { c: "#1a1a22", s: "short" }, hat: { t: "mask", c: "#2a2f3a", a: "#7af0ff" }, weapon: { t: "rifle" } },
  slinger:  { kind: "human", outfit: "#8a6a3a", trim: "#f0d9a0", boots: "#4a3016", hair: { c: "#6b3a1a", s: "short" }, hat: { t: "cap", c: "#7a5a2a", a: "#e0b84a" }, weapon: { t: "sling", c: "#8a5a2c" } },
  petasan:  { kind: "human", outfit: "#c0392b", trim: "#ffd166", boots: "#3a1a14", hair: { c: "#2a1a1a", s: "spiky" }, hat: { t: "headband", c: "#ffd166" }, weapon: { t: "firecracker", c: "#d93a3a" } },
  merchant: { kind: "human", outfit: "#2f7a5a", trim: "#ffd166", boots: "#4a3016", hair: { c: "#4a2c1a", s: "short" }, hat: { t: "cap", c: "#ffd166", a: "#2f7a5a" }, weapon: { t: "coinbag", c: "#ffd166" } },
  crossbow: { kind: "human", outfit: "#c8a23a", trim: "#fff2a8", armor: "#8c97a6", emblem: "#ff5a5a", cape: "#a02a2a", hair: { c: "#4a2c1a", s: "short" }, hat: { t: "helm", c: "#8c97a6", a: "#ffe08a", p: "#ff5a5a" }, weapon: { t: "crossbow", c: "#b97a3c", c2: "#ffe08a" } }
};

function chibiDraw(g, key, st, Lov) {
  cbSwing = st.swing || 0;
  const L = Lov || chibiLooks[key];
  if (!L) return false;
  switch (L.kind) {
    case "human": cbHuman(g, L, st); break;
    case "cannon": cbCannon(g, L, st); break;
    case "totem": cbTotem(g, L, st); break;
    case "mine": cbMine(g, L, st); break;
    case "spider": cbSpider(g, L, st); break;
    case "ghost": cbGhost(g, L, st); break;
    case "pumpkin": cbPumpkin(g, L, st); break;
    case "candle": cbCandle(g, L, st); break;
    case "moon": cbMoon(g, L, st); break;
    case "phoenix": cbPhoenix(g, L, st); break;
    case "grave": cbGrave(g, L, st); break;
    case "barrack": cbBarrack(g, L, st); break;
    default: return false;
  }
  return true;
}

// ===============================
// SKIN: tema warna + efek yang bisa dipakai SEMUA unit chibi.
// Rarity di atas Legend (Mythical & Secret) punya efek spesial (aura, partikel, jejak peluru).
// ===============================
function cbShade(hex, amt) {
  const n = parseInt(hex.slice(1), 16);
  let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
  const f = amt >= 0 ? 255 : 0, k = Math.abs(amt);
  r = Math.round(r + (f - r) * k); g = Math.round(g + (f - g) * k); b = Math.round(b + (f - b) * k);
  return "#" + [r, g, b].map(v => v.toString(16).padStart(2, "0")).join("");
}
function hslHex(h, s, l) {
  h = ((h % 360) + 360) % 360; s /= 100; l /= 100;
  const a = s * Math.min(l, 1 - l);
  const f = n => { const k = (n + h / 30) % 12; return Math.round(255 * (l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)))).toString(16).padStart(2, "0"); };
  return "#" + f(0) + f(8) + f(4);
}
// o=baju t=list b=sepatu h=topi a=aksen w=senjata cp=jubah ar=zirah | glow=aura Legend | fx+fc=efek spesial
const skinDefs = [
  // ---- Common ----
  { id: "hutan",   name: "Hutan",   r: "common", o: "#3f9a4f", t: "#d6c06a", b: "#5a3a1a", h: "#2f7a3f", a: "#8bd06a", w: "#6bbf5a" },
  { id: "pasir",   name: "Pasir",   r: "common", o: "#d9b46a", t: "#fff1c0", b: "#7a5a2a", h: "#b88a3a", a: "#e0553a", w: "#d9a43a" },
  { id: "samudra", name: "Samudra", r: "common", o: "#3a7fd0", t: "#bfe6ff", b: "#1f3f6a", h: "#2a5fa8", a: "#7ad7ff", w: "#4fb3e8" },
  { id: "senja",   name: "Senja",   r: "common", o: "#e0703a", t: "#ffd6a0", b: "#5a2a1a", h: "#b8451f", a: "#ffcf5a", w: "#ff9a3d" },
  { id: "mono",    name: "Monokrom",r: "common", o: "#8a8f99", t: "#e8ebf0", b: "#3a3f48", h: "#5c6370", a: "#c9ced8", w: "#aab0bb" },
  { id: "mint",    name: "Mint",    r: "common", o: "#5fd6b0", t: "#e8fff6", b: "#2a6a56", h: "#3fb08a", a: "#ffffff", w: "#8ff0d0" },
  { id: "kopi",    name: "Kopi",    r: "common", o: "#8a5a3a", t: "#e8cfa8", b: "#3a2414", h: "#6a4228", a: "#f5e0c0", w: "#b88a5a" },
  // ---- Uncommon ----
  { id: "sakura",  name: "Sakura",  r: "uncommon", o: "#f08fb8", t: "#fff0f6", b: "#7a3a55", h: "#e0689a", a: "#fff0a0", w: "#ff9ac4" },
  { id: "zamrud",  name: "Zamrud",  r: "uncommon", o: "#1f8a66", t: "#aaf0d6", b: "#0f4a38", h: "#136b4e", a: "#7dffc8", w: "#3de0a8" },
  { id: "tembaga", name: "Tembaga", r: "uncommon", o: "#b8663a", t: "#f5c28a", b: "#4a2a18", h: "#8a4a2a", a: "#5fd6b0", w: "#e0925a" },
  { id: "anggur",  name: "Anggur",  r: "uncommon", o: "#7a3fa8", t: "#e0b8ff", b: "#3a1a55", h: "#5a2a80", a: "#ffd166", w: "#b878f0" },
  { id: "langit",  name: "Langit",  r: "uncommon", o: "#6fb8ff", t: "#ffffff", b: "#3a5a8a", h: "#4a90e0", a: "#ffe9a0", w: "#a8d8ff" },
  { id: "matahari", name: "Matahari", r: "uncommon", o: "#f0c020", t: "#fff6b0", b: "#8a5a0a", h: "#d99a10", a: "#ff7a2e", w: "#ffd84a" },
  { id: "karang",   name: "Karang",   r: "uncommon", o: "#ff7a6a", t: "#ffe0d8", b: "#8a3a30", h: "#e0584a", a: "#7ae0d0", w: "#ff9a8a" },
  // ---- Rare ----
  { id: "kutub",   name: "Es Kutub",   r: "rare", o: "#9fe0ff", t: "#ffffff", b: "#3b6a96", h: "#6fc4ee", a: "#e8fbff", w: "#bff4ff", sk: "#ffeee8" },
  { id: "lava",    name: "Lava",       r: "rare", o: "#c43a1a", t: "#ffb347", b: "#3a0f08", h: "#7a1d0a", a: "#ff7a2e", w: "#ff5a1f" },
  { id: "racun",   name: "Racun",      r: "rare", o: "#5a8a2a", t: "#c8ff5a", b: "#243a10", h: "#2f4a15", a: "#a7e36b", w: "#8bd63a" },
  { id: "bulan",   name: "Malam Bulan",r: "rare", o: "#2a3a7a", t: "#bfc8ff", b: "#141a40", h: "#1a2250", a: "#ffe9a0", w: "#8fa0ff", cp: "#1a2250", cape: true },
  { id: "baja",    name: "Baja",       r: "rare", o: "#8a96a6", t: "#f0f4f8", b: "#3a424e", h: "#6b7685", a: "#ff5a5a", w: "#c8d0da", ar: "#5a6573", cp: "#7a2a2a", cape: true },
  { id: "ninja", name: "Ninja Bayangan", r: "rare", o: "#22252e", t: "#e0344a", b: "#0e0f14", h: "#15171e", a: "#e0344a", w: "#c8ccd6", cp: "#15171e", cape: true, ar: "#2e323e" },
  { id: "neon",  name: "Neon Siber",     r: "rare", o: "#2a1450", t: "#ff3df0", b: "#0f0a24", h: "#1a0f40", a: "#3dfff0", w: "#3dfff0", ar: "#4a1f8a", hr: "#ff3df0", eye: "#3dfff0" },
  // ---- Legend (aura cahaya) ----
  { id: "kerajaan", name: "Emas Kerajaan", r: "legend", o: "#e0b02e", t: "#fff2a8", b: "#6a460a", h: "#c98a1a", a: "#fff6c0", w: "#ffd166", cp: "#a02a2a", cape: true, ar: "#f0c84a", glow: "#ffd166" },
  { id: "samurai",  name: "Samurai Merah", r: "legend", o: "#b81f2f", t: "#f5d36a", b: "#1a1a22", h: "#7a0f1a", a: "#ffdf7a", w: "#e8e8f0", cp: "#3a0f14", cape: true, ar: "#2a2a34", glow: "#ff4d6d" },
  { id: "kristal",  name: "Kristal Biru",  r: "legend", o: "#3fc4e8", t: "#e8fdff", b: "#16506a", h: "#1f8ab0", a: "#ffffff", w: "#9ff4ff", ar: "#7ae0ff", glow: "#7ae0ff" },
  { id: "peri",     name: "Peri Hutan",    r: "legend", o: "#3fb86a", t: "#f0ffb0", b: "#1a4a2a", h: "#1f7a4a", a: "#fff59a", w: "#b8ff7a", cp: "#1f6a3a", cape: true, glow: "#b8ff7a" },
  { id: "suci", name: "Ksatria Suci", r: "legend", o: "#f4f1e8", t: "#ffd166", b: "#8a7a5a", h: "#e8e4d6", a: "#ffd166", w: "#fff6c0", cp: "#ffffff", cape: true, ar: "#fff6dc", glow: "#fff0a8" },
  // ---- Mythical (EFEK SPESIAL) ----
  { id: "naga",  name: "Naga Api",  r: "mythical", o: "#9a1408", t: "#ffb347", b: "#2a0a05", h: "#5a0e06", a: "#ffd166", w: "#ff6a1f", cp: "#ff4a1f", cape: true, ar: "#d6401a", hr: "#ff5a1f", fx: "fire",  fc: ["#ff6a1f", "#ffd166"], glow: "#ff6a1f",
    d: "Embun api naik dari tubuhnya, dua api mengorbit, dan peluru meninggalkan jejak api." },
  { id: "raja_es", name: "Raja Es", r: "mythical", o: "#7fd0ff", t: "#ffffff", b: "#2a5a8a", h: "#4aa8e8", a: "#e8fbff", w: "#bff4ff", cp: "#bfe8ff", cape: true, ar: "#a8e0ff", hr: "#e8fbff", sk: "#ffeee8", fx: "frost", fc: ["#9fe6ff", "#ffffff"], glow: "#9fe6ff",
    d: "Salju turun di sekelilingnya, kristal es mengorbit, dan peluru meninggalkan serpihan es." },
  { id: "petir", name: "Dewa Petir", r: "mythical", o: "#4a2a9a", t: "#ffe36b", b: "#1a0f40", h: "#2a1a6a", a: "#ffe36b", w: "#ffe36b", cp: "#3a1a8a", cape: true, ar: "#6a4ad0", hr: "#fff2a0", fx: "storm", fc: ["#ffe36b", "#a88aff"], glow: "#a88aff",
    d: "Kilat menyambar di sekeliling tubuhnya dan peluru berubah menjadi sambaran listrik." },
  { id: "sakura_dewi", name: "Dewi Sakura", r: "mythical", o: "#f7a8c8", t: "#ffffff", b: "#8a4a6a", h: "#ff7aa8", a: "#fff0f6", w: "#ffc0dc", cp: "#ffd6e8", cape: true, ar: "#ffb8d4", hr: "#ff9ac4", sk: "#fff0ea", fx: "sakura", fc: ["#ff9ac4", "#ffffff"], glow: "#ff9ac4",
    d: "Kelopak sakura berputar dan berguguran di sekelilingnya, dan peluru meninggalkan jejak kelopak." },
  { id: "bayangan", name: "Raja Bayangan", r: "mythical", o: "#1a1224", t: "#a06aff", b: "#0a0610", h: "#241838", a: "#c08aff", w: "#8a5aff", cp: "#241838", cape: true, ar: "#33224a", hr: "#6a3aa0", eye: "#c08aff", fx: "shadow", fc: ["#7a4ad0", "#2a1a44"], glow: "#7a4ad0",
    d: "Asap bayangan pekat mengepul dari tubuhnya, bola gelap mengorbit, dan peluru meninggalkan kabut ungu." },
  // ---- Secret (EFEK SPESIAL) ----
  { id: "void",  name: "Void Semesta", r: "secret", o: "#1a0f33", t: "#7af0ff", b: "#0a0518", h: "#2a1550", a: "#7af0ff", w: "#b07aff", cp: "#2a1550", cape: true, ar: "#3a2070", hr: "#b07aff", sk: "#e8dcff", eye: "#7af0ff", fx: "void", fc: ["#9a6aff", "#7af0ff"], glow: "#9a6aff",
    d: "Lubang hitam berputar di kakinya, bintang mengelilingi, dan peluru membawa debu galaksi." },
  { id: "pelangi", name: "Prisma Pelangi", r: "secret", rb: true, o: "#ff5a5a", t: "#ffffff", b: "#3a2a4a", h: "#5a8aff", a: "#ffffff", w: "#ffffff", cape: true, cp: "#ff5a5a", fx: "rainbow", fc: ["#ff5a8a", "#5aa0ff"], glow: "#ffffff",
    d: "Seluruh warnanya berputar menjadi pelangi, dengan cincin prisma dan peluru berjejak pelangi." },
  { id: "surya", name: "Dewa Matahari", r: "secret", o: "#ffb81f", t: "#fff6b0", b: "#7a3a0a", h: "#ff8a1f", a: "#fff6b0", w: "#ffe36b", cp: "#ff5a1f", cape: true, ar: "#ffd23f", hr: "#fff2a0", sk: "#ffe6cc", eye: "#ff5a1f", fx: "solar", fc: ["#ffb81f", "#ff5a1f"], glow: "#ffd23f",
    d: "Sinar matahari berputar di belakangnya, percikan api naik, tiga matahari kecil mengorbit, dan peluru berjejak api emas." },
];
const skinById = {}; skinDefs.forEach(s => { skinById[s.id] = s; });
function baseKeyOf(type) { return (towerTypes[type] && towerTypes[type].from) || type; }
function skinOf(type) {
  const id = (save.skinFor && save.skinFor[baseKeyOf(type)]) || save.skinAll;
  return id && id !== "none" ? skinById[id] || null : null;
}
function skinColor(sk, t) { return sk.rb ? hslHex(t * 70, 85, 62) : (sk.fc ? sk.fc[0] : sk.w); }

// ---- Look berkulit (di-cache) ----
const skinLookCache = {};
function skinnedLook(key, sk, t) {
  const L = chibiLooks[key];
  if (!sk || !L) return L;
  const rb = sk.rb ? Math.floor(t * 12) : 0;
  const ck = key + "|" + sk.id + "|" + rb;
  if (skinLookCache[ck]) return skinLookCache[ck];
  let P = sk;
  if (sk.rb) { const h = t * 70; P = { o: hslHex(h, 70, 52), t: hslHex(h + 50, 80, 82), b: hslHex(h + 200, 40, 28), h: hslHex(h + 120, 65, 50), a: hslHex(h + 180, 85, 78), w: hslHex(h + 250, 85, 70), cp: hslHex(h + 300, 60, 45), ar: hslHex(h + 160, 50, 48) }; }
  const N = Object.assign({}, L), m = P.m || P.o, x = P.x || P.a || P.t;
  if (L.kind === "human") {
    N.outfit = P.o; N.trim = P.t; N.boots = P.b;
    if (L.hat) N.hat = Object.assign({}, L.hat, { c: P.h, a: P.a || L.hat.a, p: L.hat.p ? (P.a || L.hat.p) : undefined, scarf: L.hat.scarf ? P.t : undefined });
    if (L.weapon) N.weapon = Object.assign({}, L.weapon, { c: P.w || L.weapon.c });
    if (P.cp && (L.cape || sk.cape)) N.cape = P.cp;
    if (L.armor && P.ar) N.armor = P.ar;
    if (L.emblem) N.emblem = P.a || L.emblem;
    if (P.hr && L.hair) N.hair = Object.assign({}, L.hair, { c: P.hr });
    if (P.sk && L.face !== "skull") N.skin = P.sk;
    if (P.eye) N.eye = P.eye;
  } else {
    N.m = m; N.x = x; if (L.kind === "totem") N.cols = [m, x, P.h || m];
    if (L.kind === "cannon") { N.c = m; if (L.fins) N.fins = x; N.outfit = P.o; N.hat = P.h; }
    if (L.kind === "ghost" || L.kind === "spider") N.c = m;
  }
  if (Object.keys(skinLookCache).length > 300) for (const k in skinLookCache) delete skinLookCache[k];
  skinLookCache[ck] = N;
  return N;
}

function cbPetal(g, x, y, rot, col) {
  g.save(); g.translate(x, y); g.rotate(rot); g.fillStyle = col; g.beginPath(); g.ellipse(0, 0, 4.2, 2.2, 0, 0, Math.PI * 2); g.fill();
  g.strokeStyle = "#ffffff99"; g.lineWidth = 0.8; g.beginPath(); g.moveTo(-3, 0); g.lineTo(3, 0); g.stroke(); g.restore();
}
// ---- Efek spesial (koordinat: kaki karakter di (0,0), ukuran dasar sc=0.72) ----
function skFrac(v) { return v - Math.floor(v); }
function skinFx(g, sk, t, phase, flash) {
  const fx = sk.fx || (sk.glow ? "glow" : null);
  if (!fx) return;
  const c1 = sk.rb ? hslHex(t * 70, 85, 62) : (sk.fc ? sk.fc[0] : sk.glow);
  const c2 = sk.rb ? hslHex(t * 70 + 120, 85, 66) : (sk.fc ? sk.fc[1] : sk.glow);
  const orbit = (n, rx, ry, cy, speed, draw) => {
    for (let i = 0; i < n; i++) {
      const a = t * speed + i * Math.PI * 2 / n, front = Math.sin(a) >= 0;
      if ((phase === "front") === front) draw(Math.cos(a) * rx, cy + Math.sin(a) * ry, i, front);
    }
  };
  if (phase === "back") {
    const gr = g.createRadialGradient(0, -14, 2, 0, -14, 36);
    gr.addColorStop(0, c1 + "55"); gr.addColorStop(1, c1 + "00");
    g.fillStyle = gr; g.beginPath(); g.arc(0, -14, 36, 0, Math.PI * 2); g.fill();
    g.save(); g.lineWidth = 2.2;
    if (fx === "rainbow") {
      for (let i = 0; i < 3; i++) { g.globalAlpha = 0.75; g.strokeStyle = hslHex(t * 90 + i * 55, 90, 62); g.beginPath(); g.ellipse(0, 3, 24 + i * 4, 7 + i * 1.5, 0, 0, Math.PI * 2); g.stroke(); }
    } else if (fx === "void") {
      g.fillStyle = "#0a0518aa"; g.beginPath(); g.ellipse(0, 3, 26, 8, 0, 0, Math.PI * 2); g.fill();
      for (let i = 0; i < 3; i++) { g.globalAlpha = 0.85; g.strokeStyle = i % 2 ? sk.fc[1] : sk.fc[0]; g.beginPath(); g.ellipse(0, 3, 26 - i * 5, 8 - i * 1.4, 0, t * (i % 2 ? 2.2 : -1.6) + i, t * (i % 2 ? 2.2 : -1.6) + i + 3.6); g.stroke(); }
    } else {
      g.globalAlpha = 0.55 + Math.sin(t * 3) * 0.15; g.strokeStyle = c1; g.beginPath(); g.ellipse(0, 3, 25, 7.5, 0, 0, Math.PI * 2); g.stroke();
    }
    g.restore();
    if (fx === "solar") {
      g.save(); g.translate(0, -28); g.rotate(t * 0.6);
      for (let i = 0; i < 10; i++) { g.rotate(Math.PI / 5); g.globalAlpha = 0.55; g.fillStyle = i % 2 ? sk.fc[0] : sk.fc[1]; g.beginPath(); g.moveTo(-3, 14); g.lineTo(0, 44 + Math.sin(t * 4 + i) * 4); g.lineTo(3, 14); g.closePath(); g.fill(); }
      g.restore();
    }
    if (fx === "sakura") orbit(4, 25, 7, -22, 1.6, (x, y, i) => cbPetal(g, x, y, t * 3 + i, "#ffb8d4"));
    if (fx === "shadow") orbit(3, 26, 7, -22, 1.4, (x, y) => { cbGlow(g, x, y, 10, "#7a4ad0", 0.3); cbBlob(g, x, y, 5, 5, "#140a22", 1.5); });
    if (fx === "fire") orbit(2, 26, 7, -20, 2.4, (x, y) => cbFlame(g, x, y + 6, 0.75, t, sk.fc[0], sk.fc[1]));
    if (fx === "frost") orbit(3, 25, 7, -22, 1.8, (x, y) => { cbPoly(g, [[x, y - 6], [x + 4, y], [x, y + 6], [x - 4, y]], "#bff4ff", 1.8); });
    if (fx === "void") orbit(2, 28, 8, -26, 1.9, (x, y) => { cbGlow(g, x, y, 9, sk.fc[0], 0.35); cbBlob(g, x, y, 4.5, 4.5, "#1a0a33", 2); });
    if (fx === "rainbow") orbit(5, 27, 8, -24, 2.1, (x, y, i) => { cbGlow(g, x, y, 5, hslHex(t * 90 + i * 72, 90, 65), 0.7); });
    return;
  }
  // ---- fase depan: partikel & kilat ----
  g.save();
  if (fx === "fire") {
    orbit(2, 26, 7, -20, 2.4, (x, y) => cbFlame(g, x, y + 6, 0.75, t, sk.fc[0], sk.fc[1]));
    for (let i = 0; i < 10; i++) { const ph = skFrac(t * 0.7 + i / 10), a = Math.sin(ph * Math.PI); g.globalAlpha = a; g.fillStyle = i % 2 ? sk.fc[0] : sk.fc[1]; g.beginPath(); g.arc(Math.sin(i * 5.1 + t * 2) * 15 * (0.4 + ph), -6 - ph * 56, 1.2 + (1 - ph) * 2.6, 0, Math.PI * 2); g.fill(); }
  } else if (fx === "frost") {
    orbit(3, 25, 7, -22, 1.8, (x, y) => { cbPoly(g, [[x, y - 6], [x + 4, y], [x, y + 6], [x - 4, y]], "#bff4ff", 1.8); });
    g.strokeStyle = "#ffffff"; g.lineWidth = 1.4;
    for (let i = 0; i < 12; i++) { const ph = skFrac(t * 0.35 + i / 12), x = Math.sin(i * 3.7 + t * 0.8) * 24, y = -62 + ph * 62; g.globalAlpha = Math.sin(ph * Math.PI); g.beginPath(); g.moveTo(x - 2.5, y); g.lineTo(x + 2.5, y); g.moveTo(x, y - 2.5); g.lineTo(x, y + 2.5); g.stroke(); }
  } else if (fx === "storm") {
    const seed = Math.floor(t * 9);
    for (let k = 0; k < 3; k++) {
      const r = skFrac(Math.sin(seed * 12.9898 + k * 78.233) * 43758.5453), ang = r * Math.PI * 2, len = 22 + skFrac(r * 91.7) * 16;
      g.strokeStyle = k % 2 ? sk.fc[1] : sk.fc[0]; g.lineWidth = 2; g.globalAlpha = 0.9; g.beginPath(); g.moveTo(0, -24);
      for (let s = 1; s <= 4; s++) { const j = (skFrac(Math.sin((seed + s) * 7.7 + k) * 999) - 0.5) * 9; g.lineTo(Math.cos(ang) * len * s / 4 - Math.sin(ang) * j, -24 + Math.sin(ang) * len * s / 4 * 0.8 + Math.cos(ang) * j); }
      g.stroke();
    }
    for (let i = 0; i < 6; i++) { const ph = skFrac(t * 1.3 + i / 6); g.globalAlpha = Math.sin(ph * Math.PI); g.fillStyle = sk.fc[0]; g.fillRect(Math.sin(i * 4.3 + t) * 22 - 1, -4 - ph * 54, 2.2, 2.2); }
  } else if (fx === "void") {
    orbit(2, 28, 8, -26, 1.9, (x, y) => { cbGlow(g, x, y, 9, sk.fc[0], 0.35); cbBlob(g, x, y, 4.5, 4.5, "#1a0a33", 2); });
    for (let i = 0; i < 12; i++) { const a = t * 0.9 + i * 0.52, tw = 0.5 + 0.5 * Math.sin(t * 5 + i * 2); g.globalAlpha = 0.35 + tw * 0.65; g.fillStyle = i % 2 ? sk.fc[1] : "#ffffff"; const s = 1 + tw * 1.8; g.fillRect(Math.cos(a) * (18 + (i % 3) * 6) - s / 2, -26 + Math.sin(a) * (24 + (i % 4) * 4) - s / 2, s, s); }
  } else if (fx === "rainbow") {
    orbit(5, 27, 8, -24, 2.1, (x, y, i) => { cbGlow(g, x, y, 5, hslHex(t * 90 + i * 72, 90, 65), 0.7); });
    for (let i = 0; i < 9; i++) { const ph = skFrac(t * 0.6 + i / 9); g.globalAlpha = Math.sin(ph * Math.PI); g.fillStyle = hslHex(t * 90 + i * 40, 95, 68); const x = Math.sin(i * 2.9 + t) * 20, y = -4 - ph * 56; cbPoly(g, [[x, y - 3.5], [x + 1.2, y - 1.2], [x + 3.5, y], [x + 1.2, y + 1.2], [x, y + 3.5], [x - 1.2, y + 1.2], [x - 3.5, y], [x - 1.2, y - 1.2]], g.fillStyle, 0); }
  } else if (fx === "sakura") {
    orbit(4, 25, 7, -22, 1.6, (x, y, i) => cbPetal(g, x, y, t * 3 + i, "#ffb8d4"));
    for (let i = 0; i < 12; i++) { const ph = skFrac(t * 0.3 + i / 12), x = Math.sin(i * 2.3 + ph * 5) * 22, y = -64 + ph * 66; g.globalAlpha = Math.sin(ph * Math.PI); cbPetal(g, x, y, t * 2 + i, i % 2 ? "#ffd6e8" : "#ff9ac4"); }
  } else if (fx === "shadow") {
    orbit(3, 26, 7, -22, 1.4, (x, y) => { cbGlow(g, x, y, 10, "#7a4ad0", 0.3); cbBlob(g, x, y, 5, 5, "#140a22", 1.5); });
    for (let i = 0; i < 8; i++) { const ph = skFrac(t * 0.5 + i / 8); g.globalAlpha = Math.sin(ph * Math.PI) * 0.7; g.fillStyle = i % 2 ? "#3a2060" : "#140a22"; g.beginPath(); g.arc(Math.sin(i * 3.1 + t) * 14, -4 - ph * 58, 3 + ph * 5, 0, Math.PI * 2); g.fill(); }
    g.globalAlpha = 0.8 + Math.sin(t * 6) * 0.2; g.fillStyle = "#c08aff"; g.fillRect(-9, -50, 4, 2.4); g.fillRect(5, -50, 4, 2.4);
  } else if (fx === "solar") {
    orbit(3, 27, 8, -26, 2.0, (x, y) => { cbGlow(g, x, y, 8, "#ffd23f", 0.6); cbBlob(g, x, y, 3.5, 3.5, "#fff6b0", 0); });
    for (let i = 0; i < 12; i++) { const ph = skFrac(t * 0.8 + i / 12), a2 = Math.sin(ph * Math.PI); g.globalAlpha = a2; g.fillStyle = i % 3 ? sk.fc[0] : "#fff6b0"; g.beginPath(); g.arc(Math.sin(i * 4.1 + t * 1.5) * 18 * (0.4 + ph), -6 - ph * 60, 1 + (1 - ph) * 2.4, 0, Math.PI * 2); g.fill(); }
  } else if (fx === "glow") {
    for (let i = 0; i < 3; i++) { const a = Math.sin(t * 3 + i * 2.1); if (a > 0) { g.globalAlpha = a; g.fillStyle = c1; const x = Math.sin(i * 7.3) * 18, y = -18 - i * 14; cbPoly(g, [[x, y - 3.5], [x + 1.1, y - 1.1], [x + 3.5, y], [x + 1.1, y + 1.1], [x, y + 3.5], [x - 1.1, y + 1.1], [x - 3.5, y], [x - 1.1, y - 1.1]], c1, 0); } }
  }
  if (flash > 0) cbGlow(g, 0, -28, 30, c1, Math.min(0.5, flash * 5));
  g.restore();
}
// Jejak peluru untuk skin ber-efek
function drawSkinTrail(g, b) {
  const sk = b.sk, tr = b.tr || [];
  const t = Date.now() / 1000;
  const col = i => sk.rb ? hslHex(t * 90 + i * 45, 90, 62) : (i % 2 ? sk.fc[1] : sk.fc[0]);
  g.save();
  for (let i = 0; i < tr.length; i++) {
    const p = tr[i], a = (i + 1) / (tr.length + 1);
    g.globalAlpha = a * 0.8; g.fillStyle = col(i);
    const r = (sk.fx === "frost" ? 2.6 : 3.4) * a + 0.6;
    if (sk.fx === "storm") { g.strokeStyle = col(i); g.lineWidth = 2; g.beginPath(); g.moveTo(p.x - 3, p.y - 2); g.lineTo(p.x + 1, p.y + 1); g.lineTo(p.x - 1, p.y + 3); g.stroke(); }
    else if (sk.fx === "sakura") { cbPetal(g, p.x, p.y, i * 1.3 + t * 4, i % 2 ? "#ffd6e8" : "#ff9ac4"); }
    else if (sk.fx === "frost") { g.fillRect(p.x - r, p.y - r, r * 2, r * 2); }
    else { g.beginPath(); g.arc(p.x + Math.sin(i * 3 + t * 9) * 1.2, p.y + Math.cos(i * 2 + t * 9) * 1.2, r, 0, Math.PI * 2); g.fill(); }
  }
  g.globalAlpha = 0.4; g.fillStyle = col(0); g.beginPath(); g.arc(b.x, b.y, 7, 0, Math.PI * 2); g.fill();
  g.restore();
}

// Menggambar satu karakter lengkap (aura, bayangan, karakter berkulit, efek)
function renderChibi(g, key, sk, x, footY, sc, t, o = {}) {
  const lv = o.level || 1, stt = towerTypes[key], face = o.face || 1, alpha = o.alpha == null ? 1 : o.alpha, fl = o.flash || 0;
  g.save(); g.globalAlpha = alpha; g.translate(x, footY);
  const k = sc / 0.72;
  g.save(); g.scale(k, k);
  if (o.ring !== false && (lv >= 3 || (stt && stt.evolved))) {
    g.save(); g.globalAlpha = alpha * (0.45 + Math.sin(t * 3) * 0.12);
    g.strokeStyle = (lv >= 5 || stt.evolved) ? "#ffd166" : stt.color; g.lineWidth = lv >= 5 || stt.evolved ? 3 : 2;
    g.beginPath(); g.ellipse(0, 2, 25, 8, 0, 0, Math.PI * 2); g.stroke(); g.restore();
  }
  if (sk && alpha >= 1) skinFx(g, sk, t, "back", fl);
  g.fillStyle = "#0000004d"; g.beginPath(); g.ellipse(0, 2, 17, 5, 0, 0, Math.PI * 2); g.fill();
  g.restore();
  g.save(); if (o.swing > 0) g.translate(face * Math.sin((1 - o.swing / 0.3) * Math.PI) * 9, 0);
  g.scale(sc * face, sc);
  chibiDraw(g, key, { t, flash: fl, swing: o.swing || 0 }, skinnedLook(key, sk, t));
  g.restore();
  if (sk && alpha >= 1) { g.save(); g.scale(k, k); skinFx(g, sk, t, "front", fl); g.restore(); }
  g.restore();
}

// Menggambar karakter chibi sebuah tower di canvas utama
function drawChibiTower(tower, alpha = 1, atx, aty) {
  if (!chibiLooks[tower.type]) return false;
  const x = atx == null ? tower.x : atx, y = aty == null ? tower.y : aty;
  const t = Date.now() / 1000 + tower.x * 0.013;
  renderChibi(ctx, tower.type, skinOf(tower.type), x, y + 17, 0.72, t, { level: tower.level || 1, face: tower.face || 1, alpha, flash: tower.flash || 0, swing: tower.swing || 0 });
  return true;
}

// Potret kecil untuk lobi / tombol tower (di-cache sebagai gambar)
const portraitCache = {};
function chibiIcon(key, size = 44, skinId) {
  const t = towerTypes[key];
  if (!chibiLooks[key]) return t.icon;
  const sk = skinId === undefined ? skinOf(key) : (skinById[skinId] || null), pk = key + "|" + (sk ? sk.id : "");
  if (portraitCache[pk] === undefined) {
    let url = "";
    try {
      const cv = document.createElement("canvas"); cv.width = 96; cv.height = 96;
      const g = cv.getContext("2d");
      const L = chibiLooks[key];
      const sc = L.big ? 0.8 : L.kind === "cannon" ? 1.0 : L.kind === "human" ? 1.1 : 1.15;
      const ox = L.kind === "cannon" ? (L.big ? 16 : 6) : L.kind === "mine" ? 6 : 0;
      g.translate(48 - ox * 0.5, 88); g.scale(sc, sc);
      g.globalAlpha = 0.28; cbBlob(g, 0, 2, 26, 7, "#000", 0); g.globalAlpha = 1;
      chibiDraw(g, key, { t: 1.3, flash: 0 }, skinnedLook(key, sk, 1.3));
      url = typeof cv.toDataURL === "function" ? cv.toDataURL("image/png") : "";
    } catch (e) { url = ""; }
    portraitCache[pk] = url;
  }
  return portraitCache[pk] ? `<img class="portrait" src="${portraitCache[pk]}" width="${size}" height="${size}" alt="${t.name}">` : t.icon;
}

function drawTower(tower) {
  const stats = towerTypes[tower.type];
  ctx.textBaseline = "alphabetic";
  if (tower === selectedTower) {
    if (stats.rally) {
      ctx.beginPath(); ctx.arc(tower.rally.x, tower.rally.y, LEASH, 0, Math.PI * 2);
      ctx.fillStyle = "#ffffff14"; ctx.fill(); ctx.strokeStyle = "#ffffff66"; ctx.lineWidth = 2; ctx.setLineDash([5, 5]); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = "#ffd166"; ctx.font = "16px system-ui"; ctx.textAlign = "center"; ctx.fillText("🚩", tower.rally.x, tower.rally.y + 5);
    } else {
      ctx.beginPath(); ctx.arc(tower.x, tower.y, towerRange(tower), 0, Math.PI * 2);
      ctx.fillStyle = "#ffffff18"; ctx.fill(); ctx.strokeStyle = "#ffffff66"; ctx.lineWidth = 2; ctx.setLineDash([5, 5]); ctx.stroke(); ctx.setLineDash([]);
    }
  }
  const drewChibi = drawChibiTower(tower);
  if (drewChibi) { /* karakter chibi sudah digambar */ }
  else if (tower.type === "barrack") {
    ctx.fillStyle = "#6c573f"; ctx.fillRect(tower.x - 17, tower.y - 12, 34, 30);
    ctx.fillStyle = "#d6b47a"; ctx.fillRect(tower.x - 12, tower.y - 7, 24, 25);
    ctx.fillStyle = "#7c4930"; ctx.beginPath(); ctx.moveTo(tower.x - 21, tower.y - 10); ctx.lineTo(tower.x, tower.y - 28); ctx.lineTo(tower.x + 21, tower.y - 10); ctx.closePath(); ctx.fill();
    ctx.fillStyle = "#4d2e22"; ctx.fillRect(tower.x - 5, tower.y + 5, 10, 13);
  } else if (tower.type === "graveyard") {
    ctx.fillStyle = "#3b4a35"; ctx.beginPath(); ctx.ellipse(tower.x, tower.y + 14, 22, 8, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#8a8795"; ctx.beginPath(); ctx.moveTo(tower.x - 11, tower.y + 14); ctx.lineTo(tower.x - 11, tower.y - 6); ctx.arc(tower.x, tower.y - 6, 11, Math.PI, 0); ctx.lineTo(tower.x + 11, tower.y + 14); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = "#575466"; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(tower.x, tower.y - 9); ctx.lineTo(tower.x, tower.y + 4); ctx.moveTo(tower.x - 5, tower.y - 3); ctx.lineTo(tower.x + 5, tower.y - 3); ctx.stroke();
  } else {
    ctx.fillStyle = "#6c573f"; ctx.beginPath(); ctx.arc(tower.x, tower.y + 5, 17, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = stats.color; ctx.beginPath(); ctx.arc(tower.x, tower.y, 15, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = (tower.level >= 5 || stats.evolved) ? "#ffd166" : "#253849"; ctx.lineWidth = 3; ctx.stroke();
    if (stats.evolved) {
      ctx.save(); ctx.globalAlpha = 0.5 + Math.sin(Date.now() / 250) * 0.2; ctx.strokeStyle = stats.color; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(tower.x, tower.y, 21, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
    }
    if (tower.flash > 0) {
      ctx.fillStyle = "#ffffff99"; ctx.beginPath(); ctx.arc(tower.x, tower.y, 15 + tower.flash * 40, 0, Math.PI * 2); ctx.fill();
    }
    ctx.font = "19px system-ui"; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillStyle = "#fff"; ctx.fillText(stats.icon, tower.x, tower.y + 1);
  }
  if ((tower.type === "totem" || tower.type === "web" || tower.type === "chrono") && tower !== selectedTower) {
    ctx.save(); ctx.globalAlpha = 0.25; ctx.strokeStyle = tower.type === "web" ? "#e6e6ee" : tower.type === "chrono" ? "#7be0d0" : "#8fd6a5"; ctx.lineWidth = 2; ctx.setLineDash([3, 6]);
    ctx.beginPath(); ctx.arc(tower.x, tower.y, towerRange(tower), 0, Math.PI * 2); ctx.stroke(); ctx.restore();
  }
  ctx.textBaseline = "alphabetic"; ctx.textAlign = "center";
  ctx.fillStyle = "#172338"; ctx.fillRect(tower.x - 14, tower.y + 20, 28, 13);
  ctx.fillStyle = "#fff"; ctx.font = "bold 10px system-ui"; ctx.fillText(stats.evolved ? "EVO" : "Lv" + tower.level, tower.x, tower.y + 30);
}

function drawEnemy(e) {
  const bob = Math.sin(e.t * 8) * 1.5;
  const lift = e.flying ? 14 + Math.sin(e.t * 5) * 2 : 0;
  const cx = e.x, cy = e.y - lift + (e.flying ? 0 : bob * 0.4);
  ctx.fillStyle = "#0003"; ctx.beginPath(); ctx.ellipse(e.x, e.y + 8, e.radius + 2, 6, 0, 0, Math.PI * 2); ctx.fill();
  if (e.flying) {
    const flap = Math.sin(e.t * 18) * 6;
    ctx.fillStyle = "#8d6bd0";
    ctx.beginPath(); ctx.moveTo(cx - 4, cy); ctx.lineTo(cx - 20, cy - 8 - flap); ctx.lineTo(cx - 12, cy + 6); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(cx + 4, cy); ctx.lineTo(cx + 20, cy - 8 - flap); ctx.lineTo(cx + 12, cy + 6); ctx.closePath(); ctx.fill();
  }
  ctx.fillStyle = e.color;
  ctx.beginPath(); ctx.ellipse(cx, cy, e.radius * (1 + bob * 0.02), e.radius * (1 - bob * 0.03), 0, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = e.armor >= 0.3 ? "#6b7280" : "#2a4a3c"; ctx.lineWidth = e.armor >= 0.3 ? 4 : 2; ctx.stroke();
  if (e.hitFlash > 0) { ctx.fillStyle = "#ffffffaa"; ctx.beginPath(); ctx.arc(cx, cy, e.radius, 0, Math.PI * 2); ctx.fill(); }
  if (e.slowTimer > 0 && e.freezeTimer <= 0) {
    ctx.strokeStyle = "#8be3ff"; ctx.lineWidth = 2; ctx.setLineDash([4, 3]);
    ctx.beginPath(); ctx.arc(cx, cy, e.radius + 3, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
  }
  if (e.freezeTimer > 0) {
    ctx.fillStyle = "#bdf1ff88"; ctx.beginPath(); ctx.arc(cx, cy, e.radius + 4, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = "#9beeff"; ctx.lineWidth = 3; ctx.stroke();
  }
  if (e.hexTimer > 0) {
    ctx.strokeStyle = "#c58bff"; ctx.lineWidth = 2; ctx.setLineDash([3, 3]);
    ctx.beginPath(); ctx.arc(cx, cy, e.radius + 6, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
  }
  if (e.burnTimer > 0) { ctx.fillStyle = "#ff8a3d"; ctx.beginPath(); ctx.arc(cx - e.radius * 0.6, cy - e.radius * 0.6, 3, 0, Math.PI * 2); ctx.fill(); }
  if (e.poisonTimer > 0) { ctx.fillStyle = "#8be04a"; ctx.beginPath(); ctx.arc(cx + e.radius * 0.6, cy - e.radius * 0.6, 3, 0, Math.PI * 2); ctx.fill(); }
  // mata
  ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(cx - 4, cy - 2, 2.6, 0, Math.PI * 2); ctx.arc(cx + 4, cy - 2, 2.6, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = e.type === "flyer" || e.boss ? "#c00" : "#122"; ctx.beginPath(); ctx.arc(cx - 4, cy - 2, 1.1, 0, Math.PI * 2); ctx.arc(cx + 4, cy - 2, 1.1, 0, Math.PI * 2); ctx.fill();
  if (e.boss) {
    ctx.fillStyle = "#ffd166"; ctx.beginPath();
    ctx.moveTo(cx - 10, cy - e.radius + 2); ctx.lineTo(cx - 10, cy - e.radius - 9); ctx.lineTo(cx - 4, cy - e.radius - 3);
    ctx.lineTo(cx, cy - e.radius - 11); ctx.lineTo(cx + 4, cy - e.radius - 3); ctx.lineTo(cx + 10, cy - e.radius - 9); ctx.lineTo(cx + 10, cy - e.radius + 2); ctx.closePath(); ctx.fill();
  }
  // bar nyawa
  const bw = e.boss ? 40 : 30, by = cy - e.radius - (e.boss ? 18 : 9);
  ctx.fillStyle = "#233"; ctx.fillRect(cx - bw / 2, by, bw, 4);
  ctx.fillStyle = "#ff5b63"; ctx.fillRect(cx - bw / 2, by, bw * Math.max(0, e.hp / e.maxHp), 4);
}

function drawFriendlyUnit(unit) {
  const colors = unit.kind === "zombie" ? "#7fae6b" : unit.kind === "gladiator" ? "#b64d46" : unit.kind === "knight" ? "#cbd5e1" : unit.upgraded ? "#f5d76e" : "#79b8e8";
  ctx.fillStyle = "#0003"; ctx.beginPath(); ctx.ellipse(unit.x, unit.y + 7, 10, 4, 0, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = colors; ctx.beginPath(); ctx.arc(unit.x, unit.y, unit.kind === "gladiator" ? 10 : 7, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = "#293748"; ctx.lineWidth = 2; ctx.stroke();
  if (unit.hitFlash > 0) { ctx.fillStyle = "#ff000088"; ctx.beginPath(); ctx.arc(unit.x, unit.y, 8, 0, Math.PI * 2); ctx.fill(); }
  ctx.fillStyle = "#f2d0a1"; ctx.beginPath(); ctx.arc(unit.x, unit.y - 2, 3, 0, Math.PI * 2); ctx.fill();
  if (unit.kind === "archer") {
    ctx.strokeStyle = unit.upgraded ? "#ffe17a" : "#6c472b"; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(unit.x + 7, unit.y, 5, -1.2, 1.2); ctx.stroke();
  } else {
    const swing = unit.attackFlash > 0 ? 6 : 0;
    ctx.strokeStyle = unit.kind === "gladiator" ? "#ffe0a3" : "#e5edf5"; ctx.lineWidth = unit.kind === "gladiator" ? 4 : 2.5;
    ctx.beginPath(); ctx.moveTo(unit.x + 4, unit.y - 4); ctx.lineTo(unit.x + 12 + swing, unit.y - 12 + swing); ctx.stroke();
  }
  ctx.fillStyle = "#263238"; ctx.fillRect(unit.x - 9, unit.y - 13, 18, 3);
  ctx.fillStyle = "#69e08b"; ctx.fillRect(unit.x - 9, unit.y - 13, 18 * Math.max(0, unit.hp / unit.maxHp), 3);
}

function drawFx() {
  for (const f of fx) {
    const a = Math.max(0, f.life / f.max);
    ctx.save(); ctx.globalAlpha = a;
    if (f.k === "text") {
      ctx.fillStyle = f.color; ctx.font = `bold ${f.size}px system-ui`; ctx.textAlign = "center"; ctx.textBaseline = "alphabetic";
      ctx.strokeStyle = "#0008"; ctx.lineWidth = 3; ctx.strokeText(f.text, f.x, f.y); ctx.fillText(f.text, f.x, f.y);
    } else if (f.k === "ring") {
      ctx.strokeStyle = f.color; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(f.x, f.y, f.r * (1.15 - a * 0.4), 0, Math.PI * 2); ctx.stroke();
    } else if (f.k === "zap") {
      ctx.strokeStyle = f.color; ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.moveTo(f.x, f.y);
      const mx = (f.x + f.x2) / 2 + (Math.random() * 10 - 5), my = (f.y + f.y2) / 2 + (Math.random() * 10 - 5);
      ctx.lineTo(mx, my); ctx.lineTo(f.x2, f.y2); ctx.stroke();
    } else if (f.k === "slash") {
      const p = 1 - a; // 0 -> 1
      ctx.translate(f.x, f.y); ctx.rotate(f.ang);
      for (let i = 0; i < 2; i++) {
        const r = 26 + i * 8, a0 = -1.25 + p * 0.5, a1 = a0 + 1.9 * Math.min(1, p * 2.6 + 0.2);
        ctx.beginPath(); ctx.arc(-6, 0, r, a0, a1); ctx.arc(-6 + 5, 0, r - 7 + i * 2, a1, a0, true); ctx.closePath();
        ctx.globalAlpha = a * (i ? 0.5 : 0.95); ctx.fillStyle = i ? f.color : "#ffffff"; ctx.fill();
      }
    } else if (f.k === "arrow") {
      const p = Math.min(1, (1 - a) * 1.25), dx = f.x2 - f.x, dy = f.y2 - f.y, len = Math.hypot(dx, dy) || 1, ux = dx / len, uy = dy / len;
      const hx = f.x + dx * p, hy = f.y + dy * p, tl = Math.min(len * p, 70);
      ctx.globalAlpha = a < 0.25 ? a * 4 : 1; ctx.strokeStyle = f.color; ctx.lineWidth = f.w;
      ctx.beginPath(); ctx.moveTo(hx - ux * tl, hy - uy * tl); ctx.lineTo(hx, hy); ctx.stroke();
      ctx.fillStyle = "#ffffff"; ctx.beginPath(); ctx.moveTo(hx + ux * 10, hy + uy * 10); ctx.lineTo(hx - uy * 5 - ux * 2, hy + ux * 5 - uy * 2); ctx.lineTo(hx + uy * 5 - ux * 2, hy - ux * 5 - uy * 2); ctx.closePath(); ctx.fill();
    } else if (f.k === "jet") {
      const p = 1 - a, dx = f.x2 - f.x, dy = f.y2 - f.y, len = Math.hypot(dx, dy) || 1, ux = dx / len, uy = dy / len, L2 = Math.min(len, 130) * Math.min(1, p * 3 + 0.7);
      const t0 = Date.now() / 1000;
      for (let k = 0; k < 2; k++) {
        const wd = (k ? 8 : 17) * (0.7 + a * 0.5);
        ctx.fillStyle = k ? f.color2 : f.color; ctx.globalAlpha = a * (k ? 0.95 : 0.7);
        ctx.beginPath(); ctx.moveTo(f.x, f.y);
        const steps = 6;
        for (let i = 1; i <= steps; i++) { const q = i / steps, w = wd * q + Math.sin(t0 * 40 + i * 2 + k) * 2; ctx.lineTo(f.x + ux * L2 * q - uy * w, f.y + uy * L2 * q + ux * w); }
        for (let i = steps; i >= 1; i--) { const q = i / steps, w = wd * q + Math.sin(t0 * 37 + i * 3 + k) * 2; ctx.lineTo(f.x + ux * L2 * q + uy * w, f.y + uy * L2 * q - ux * w); }
        ctx.closePath(); ctx.fill();
      }
    } else if (f.k === "spark") {
      ctx.fillStyle = f.color; ctx.beginPath(); ctx.arc(f.x, f.y, 2.5, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
  }
}

function drawMeteors() {
  for (const m of meteors) {
    const k = 1 - m.t / m.max; // 0 -> 1
    ctx.save();
    ctx.strokeStyle = "#ff7a45"; ctx.lineWidth = 3; ctx.setLineDash([6, 6]); ctx.globalAlpha = 0.5 + k * 0.4;
    ctx.beginPath(); ctx.arc(m.x, m.y, m.radius, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
    const rx = m.x + (1 - k) * 160, ry = m.y - (1 - k) * 320;
    ctx.globalAlpha = 1;
    ctx.fillStyle = "#ffb347"; ctx.beginPath(); ctx.arc(rx, ry, 14, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#ff5a2a"; ctx.beginPath(); ctx.arc(rx, ry, 9, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }
}

function drawHoverPreview() {
  if (!hover || gameOver || selectedTower || meteorArmed || !ui.overlay.classList.contains("hidden")) return;
  const type = towerTypes[selectedType];
  const problem = canPlace(hover);
  const ok = !problem && gold >= type.cost;
  ctx.save();
  if (type.range > 0) {
    ctx.beginPath(); ctx.arc(hover.x, hover.y, type.range, 0, Math.PI * 2);
    ctx.fillStyle = ok ? "#ffffff18" : "#ff5a5a18"; ctx.fill();
    ctx.strokeStyle = ok ? "#ffffff66" : "#ff7a7a99"; ctx.lineWidth = 2; ctx.setLineDash([5, 5]); ctx.stroke(); ctx.setLineDash([]);
  } else if (type.rally) {
    const rally = nearestPathPoint(hover.x, hover.y);
    ctx.beginPath(); ctx.arc(rally.x, rally.y, LEASH, 0, Math.PI * 2);
    ctx.fillStyle = ok ? "#ffffff12" : "#ff5a5a12"; ctx.fill();
    ctx.strokeStyle = ok ? "#ffffff55" : "#ff7a7a88"; ctx.lineWidth = 2; ctx.setLineDash([5, 5]); ctx.stroke(); ctx.setLineDash([]);
  }
  if (chibiLooks[selectedType]) {
    if (!ok) { ctx.fillStyle = "#ff3b3b55"; ctx.beginPath(); ctx.arc(hover.x, hover.y, 20, 0, Math.PI * 2); ctx.fill(); }
    drawChibiTower({ type: selectedType, x: hover.x, y: hover.y, level: 1, flash: 0, face: 1 }, ok ? 0.8 : 0.45);
  } else {
    ctx.globalAlpha = 0.75;
    ctx.fillStyle = ok ? type.color : "#ff6b6b";
    ctx.beginPath(); ctx.arc(hover.x, hover.y, 15, 0, Math.PI * 2); ctx.fill();
    ctx.globalAlpha = 1; ctx.font = "19px system-ui"; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillStyle = "#fff";
    ctx.fillText(type.icon, hover.x, hover.y + 1);
  }
  ctx.restore();
}

function drawMeteorCursor() {
  if (!meteorArmed || !hover) return;
  ctx.save();
  ctx.strokeStyle = "#ff9b54"; ctx.lineWidth = 3; ctx.setLineDash([6, 6]);
  ctx.beginPath(); ctx.arc(hover.x, hover.y, 78, 0, Math.PI * 2); ctx.stroke();
  ctx.restore();
}

function draw() {
  drawBackground();
  poisonPuddles.forEach(p => {
    ctx.save();
    ctx.globalAlpha = Math.max(0.2, Math.min(0.65, p.timer / 2 * 0.65));
    ctx.fillStyle = p.color || "#83e044";
    ctx.beginPath(); ctx.ellipse(p.x, p.y, p.radius, p.radius * 0.62, 0, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = "#3c8c2d"; ctx.lineWidth = 2; ctx.stroke();
    ctx.restore();
  });
  towers.forEach(drawTower);
  drawHoverPreview();
  friendlyUnits.forEach(drawFriendlyUnit);
  // musuh darat digambar dulu, lalu yang terbang di atasnya
  enemies.filter(e => !e.flying).forEach(drawEnemy);
  enemies.filter(e => e.flying).forEach(drawEnemy);
  bullets.forEach(b => {
    if (b.sk) drawSkinTrail(ctx, b);
    ctx.fillStyle = b.sk && b.sk.rb ? hslHex(Date.now() / 10, 90, 62) : b.sk ? b.sk.fc[0] : b.color;
    if (b.type === "sniper") {
      ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(Math.atan2(b.target.y - b.y, b.target.x - b.x));
      ctx.fillRect(-9, -2, 18, 4); ctx.restore();
    } else if (b.type === "poison") {
      ctx.beginPath(); ctx.arc(b.x, b.y, 5, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#eaffb7"; ctx.beginPath(); ctx.arc(b.x - 1, b.y - 1, 2, 0, Math.PI * 2); ctx.fill();
    } else if (b.type === "archer" || b.type === "crossbow") {
      const ang = Math.atan2(b.target.y - b.y, b.target.x - b.x);
      ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(ang);
      ctx.strokeStyle = "#e8e0cf"; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-12, 0); ctx.lineTo(7, 0); ctx.stroke();
      ctx.fillStyle = b.type === "crossbow" ? "#ffe08a" : "#cfd6e0"; ctx.beginPath(); ctx.moveTo(11, 0); ctx.lineTo(5, -3.2); ctx.lineTo(5, 3.2); ctx.closePath(); ctx.fill();
      ctx.fillStyle = "#ff5a5a"; ctx.fillRect(-13, -2.5, 4, 1.6); ctx.fillRect(-13, 0.9, 4, 1.6);
      ctx.restore();
    } else if (b.type === "tesla") {
      ctx.beginPath(); ctx.moveTo(b.x - 5, b.y - 4); ctx.lineTo(b.x + 1, b.y); ctx.lineTo(b.x - 2, b.y + 2); ctx.lineTo(b.x + 5, b.y + 5); ctx.strokeStyle = b.color; ctx.lineWidth = 3; ctx.stroke();
    } else {
      ctx.beginPath(); ctx.arc(b.x, b.y, b.type === "cannon" ? 6 : b.type === "mortar" ? 7 : 4, 0, Math.PI * 2); ctx.fill();
    }
  });
  drawMeteors();
  drawMeteorCursor();
  drawFx();
  if (moonFlash > 0) { ctx.fillStyle = `rgba(255,60,90,${Math.min(0.3, moonFlash * 0.4)})`; ctx.fillRect(0, 0, W, H); }
  if (baseFlash > 0) { ctx.fillStyle = `rgba(255,40,40,${Math.min(0.35, baseFlash * 0.5)})`; ctx.fillRect(0, 0, W, H); }
  // HUD kecil di kiri atas
  ctx.textAlign = "left"; ctx.textBaseline = "alphabetic";
  ctx.font = "bold 15px system-ui";
  const hud = waveActive ? `WAVE ${wave}  •  sisa ${enemies.length + spawnQueue.length}` : gameOver && wave >= MAX_WAVE && health > 0 ? "SELESAI" : "SIAP";
  ctx.strokeStyle = "#000a"; ctx.lineWidth = 4; ctx.strokeText(hud, 16, 26);
  ctx.fillStyle = "#fff"; ctx.fillText(hud, 16, 26);
}

function loop(timestamp) {
  if (!lastTime) lastTime = timestamp;
  const dt = Math.min((timestamp - lastTime) / 1000, 0.05);
  lastTime = timestamp;
  update(dt);
  draw();
  if (!gameOver) animationId = requestAnimationFrame(loop);
  else animationId = null;
}

// ===============================
// LOBBY: pilih map, atur 5 slot pasukan, dan toko
// ===============================
const L = {
  lobby: $("lobby"), gameView: $("gameView"), gems: $("gems"), mapGrid: $("mapGrid"), slotRow: $("slotRow"),
  squadGrid: $("squadGrid"), shopGrid: $("shopGrid"), playBtn: $("playBtn"), summary: $("lobbySummary"), toast: $("lobbyToast"),
  crateGrid: $("crateGrid"), skinResults: $("skinResults"), skinGrid: $("skinGrid"), skinCanvas: $("skinCanvas"), skinUnit: $("skinUnit"), skinInfo: $("skinInfo"), skinActions: $("skinActions"),
  tabs: document.querySelectorAll("[data-tab]"), panels: document.querySelectorAll("[data-panel]"),
  patchList: $("patchList"), patchBadge: $("patchBadge"), verTag: $("verTag"),
  gachaTab: $("gachaTab"), coinBadge: $("coinBadge"), coins: $("coins"), eventTimer: $("eventTimer"), pull1: $("pull1"), pull10: $("pull10"),
  raidShop: $("raidShop"), raidInfo: $("raidInfo"), raidBtn: $("raidBtn"), crystals: $("crystals"), tokenBadge: $("tokenBadge"), tokenCount: $("tokenCount"), pityInfo: $("pityInfo"), gachaResults: $("gachaResults"), gachaTable: $("gachaTable")
};
const MAX_SLOTS = 5;

function sanitizeSave() {
  save.owned = Array.from(new Set(["archer"].concat((save.owned || []).filter(k => towerTypes[k] && !towerTypes[k].evolved))));
  save.loadout = Array.from(new Set((save.loadout || []).filter(k => save.owned.includes(k)))).slice(0, MAX_SLOTS);
  if (!save.loadout.length) save.loadout = ["archer"];
  if (!mapDefs[save.map] || (mapDefs[save.map].event && !eventActive())) save.map = "forest";
  if (typeof save.gems !== "number" || save.gems < 0) save.gems = 0;
  save.mapBest = Object.assign({}, save.mapBest);
  if (!diffDefs[save.diff]) save.diff = "medium";
  if (typeof save.coins !== "number" || save.coins < 0) save.coins = 0;
  if (!save.evolved || typeof save.evolved !== "object") save.evolved = {};
  if (!save.evoOn || typeof save.evoOn !== "object") save.evoOn = {};
  ["crystals", "tokens", "tokenPity"].forEach(k => { if (typeof save[k] !== "number" || save[k] < 0) save[k] = 0; });
  save.gacha = Object.assign({ pRare: 0, pLegend: 0, pMyth: 0, pulls: 0 }, save.gacha);
  save.skinsOwned = Array.from(new Set((Array.isArray(save.skinsOwned) ? save.skinsOwned : []).filter(id => skinById[id])));
  if (!skinById[save.skinAll]) save.skinAll = "";
  if (!save.skinFor || typeof save.skinFor !== "object") save.skinFor = {};
  for (const k in save.skinFor) if (!(skinById[save.skinFor[k]] || save.skinFor[k] === "none") || !towerTypes[k]) delete save.skinFor[k];
  if (!save.skinPity || typeof save.skinPity !== "object") save.skinPity = {};
}
function lobbyToast(text) {
  L.toast.textContent = text;
  clearTimeout(lobbyToast.t);
  lobbyToast.t = setTimeout(() => { L.toast.textContent = ""; }, 3500);
}

const thumbs = {};
function mapThumb(id) {
  if (thumbs[id]) return thumbs[id];
  const prev = map.id;
  setMap(id);
  const big = document.createElement("canvas"); big.width = W; big.height = H;
  paintBackground(big.getContext("2d"));
  const th = document.createElement("canvas"); th.width = 300; th.height = 173; th.className = "map-thumb";
  th.getContext("2d").drawImage(big, 0, 0, 300, 173);
  setMap(prev);
  thumbs[id] = th;
  return th;
}

function renderDiff() {
  ui.diffRow.innerHTML = diffKeys.map(k => {
    const d = diffDefs[k];
    return `<button class="diff-btn diff-${k}${save.diff === k ? " selected" : ""}" data-diff="${k}">
      <b>${d.icon} ${d.name}</b><small>${d.desc}</small>
      <small>❤️ ${d.lives} • 🪙 ${d.gold} • 💎 ×${d.reward}</small></button>`;
  }).join("") + `<div class="diff-info">${diff().icon} <b>${diff().name}</b>: ${diff().desc} • ❤️ ${diff().lives} • 🪙 ${diff().gold} • 💎 ×${diff().reward}</div>`;
}
function renderMaps() {
  L.mapGrid.innerHTML = "";
  mapKeys.forEach(id => {
    const m = mapDefs[id], best = bestOf(id), locked = m.event && !eventActive();
    const card = document.createElement("button");
    card.className = "map-card" + (save.map === id ? " selected" : "") + (m.event ? " event" : "") + (locked ? " locked" : "");
    card.dataset.map = id;
    card.appendChild(mapThumb(id));
    const info = document.createElement("div");
    info.className = "map-info";
    info.innerHTML = `<b>${m.icon} ${m.name}</b><span class="stars">${"★".repeat(m.stars)}${"☆".repeat(Math.max(0, 4 - m.stars))}</span>
      <p>${m.desc}</p>
      <small>${m.event ? (locked ? "🎃 Event berakhir • " : `🎃 EVENT (sisa ${eventDaysLeft()} hari) • Dapat Halloween Coin • `) : ""}Hadiah 💎 ×${m.gemMult} • ${best >= MAX_WAVE ? "Rekor: menang ✔" : best ? "Rekor: wave " + best : "Belum dimainkan"}</small>`;
    card.appendChild(info);
    L.mapGrid.appendChild(card);
  });
}

function rarityTag(t) { if (t.raid) return ' <span class="rar-tag" style="--rar:#4fc3f7">Raid</span>'; const r = rarities[t.rarity]; return ` <span class="rar-tag" style="--rar:${r.color}">${r.name}</span>`; }
function mysteryCard() {
  return `<div class="unit-card locked gacha" style="--rar:${rarities.secret.color}"><div class="unit-icon">❓</div>
    <div class="unit-body"><b>???</b> <span class="rar-tag" style="--rar:${rarities.secret.color}">Secret</span><small>Unit rahasia. Mungkin muncul di Gacha Halloween…</small></div></div>`;
}
function evoControls(key) {
  const to = evolveMap[key];
  if (!to) return "";
  const e = towerTypes[to];
  if (!save.evolved[key]) {
    return `<div class="evo-row"><small class="evo-info">${e.icon} <b>${e.name}</b>: ${e.info(e.levels[0])}</small>
      <button class="chip-btn evo" data-act="evolve" data-key="${key}" ${save.tokens < EVOLVE_COST ? "disabled" : ""}>✨ Evolve permanen (${save.tokens}/${EVOLVE_COST} 🧿)</button></div>`;
  }
  const on = !!save.evoOn[key];
  return `<div class="evo-row"><small class="evo-info">${e.icon} <b>${e.name}</b> sudah terbuka permanen. ${on ? e.info(e.levels[0]) : "Sedang memakai bentuk Original."}</small>
    <button class="chip-btn evo on" data-act="evotoggle" data-key="${key}">${on ? `✨ Bentuk: ${e.name} • ketuk untuk Original` : `Bentuk: Original • ketuk untuk ${e.name}`}</button></div>`;
}
function evolveUnit(key) {
  const to = evolveMap[key];
  if (!to || !save.owned.includes(key) || save.evolved[key]) return;
  if (save.tokens < EVOLVE_COST) { lobbyToast(`Butuh ${EVOLVE_COST} 🧿 Evolve Token. Token jatuh dari musuh yang dibunuh.`); return; }
  save.tokens -= EVOLVE_COST; save.evolved[key] = true; save.evoOn[key] = true; sfx("evolve");
  writeSave(); renderLobby(); lobbyToast(`✨ ${towerTypes[key].name} berevolusi menjadi ${towerTypes[to].name} secara permanen!`);
}
function toggleEvo(key) {
  if (!save.evolved[key]) return;
  sfx("equip");
  save.evoOn[key] = !save.evoOn[key];
  writeSave(); renderLobby(); lobbyToast(save.evoOn[key] ? `${towerTypes[evolveMap[key]].name} aktif.` : `${towerTypes[key].name} kembali ke bentuk Original.`);
}
function unitCard(key, mode) {
  const t = towerTypes[key];
  const owned = save.owned.includes(key), used = save.loadout.includes(key);
  let action;
  if (mode === "shop") {
    action = owned ? `<button class="chip-btn" disabled>✔ Dimiliki</button>`
      : `<button class="chip-btn buy" data-act="buy" data-key="${key}" ${save.gems < t.gem ? "disabled" : ""}>Beli ${t.gem} 💎</button>`;
  } else if (mode === "raid") {
    action = owned ? `<button class="chip-btn" disabled>✔ Dimiliki</button>`
      : `<button class="chip-btn buy raidbuy" data-act="buyraid" data-key="${key}" ${save.crystals < t.crystal ? "disabled" : ""}>Beli ${t.crystal} 🔷</button>`;
  } else if (!owned) {
    action = t.raid ? `<button class="chip-btn" data-act="goraid">🔷 Beli di Raid</button>` : t.gacha ? `<button class="chip-btn" data-act="gogacha">🎃 Dari Gacha</button>` : `<button class="chip-btn" data-act="goshop" data-key="${key}">🔒 Beli di Toko</button>`;
  } else {
    action = `<button class="chip-btn ${used ? "on" : ""}" data-act="toggle" data-key="${key}">${used ? "✔ Dipakai" : "Pakai"}</button>`;
  }
  return `<div class="unit-card${owned ? "" : " locked"}${used && mode === "squad" ? " used" : ""}${t.gacha || t.raid ? " gacha" : ""}"${t.gacha ? ` style="--rar:${rarities[t.rarity].color}"` : t.raid ? ` style="--rar:#4fc3f7"` : ""}>
    <div class="unit-icon">${chibiIcon(key, 52)}</div>
    <div class="unit-body"><b>${t.name}</b>${t.gacha || t.raid ? rarityTag(t) : ""}<small>${t.desc}</small><small class="stat-line">${unitStatText(key)}</small>
    <small class="stat-line">Harga di game: ${t.cost} 🪙</small>${mode === "squad" && owned ? evoControls(key) : ""}</div>${action}</div>`;
}
function renderSquad() {
  const slots = [];
  for (let i = 0; i < MAX_SLOTS; i++) {
    const key = save.loadout[i];
    slots.push(key
      ? `<button class="slot filled" data-act="toggle" data-key="${key}" title="Klik untuk melepas"><span>${chibiIcon(effKey(key), 40)}</span><small>${towerTypes[effKey(key)].name}</small></button>`
      : `<div class="slot"><span>＋</span><small>Kosong</small></div>`);
  }
  L.slotRow.innerHTML = slots.join("");
  L.squadGrid.innerHTML = shopKeys.map(k => unitCard(k, "squad")).join("")
    + raidKeys.map(k => unitCard(k, "squad")).join("")
    + gachaKeys.map(k => (towerTypes[k].rarity === "secret" && !save.owned.includes(k)) ? mysteryCard() : unitCard(k, "squad")).join("");
}
function renderRaid() {
  setText(L.crystals, save.crystals);
  setText(L.tokenCount, save.tokens);
  L.raidShop.innerHTML = raidKeys.slice().sort((a, b) => towerTypes[a].crystal - towerTypes[b].crystal).map(k => unitCard(k, "raid")).join("");
  const best = bestOf("raid");
  L.raidInfo.innerHTML = `<div class="raid-thumb"></div><div class="raid-text"><h3>👹 Arena Raid</h3>
    <p>10 wave penuh bos. Wave 10: <b>Raid Boss</b> raksasa yang mengamuk saat HP 50% dan menghilangkan 3 nyawa jika bocor.</p>
    <p class="hint">Hadiah: <b>🔷 5 per wave</b> + <b>80</b> jika menang, dikali pengali kesulitan (${diff().icon} ${diff().name} ×${diff().reward}). Tingkat kesulitan dipilih di dalam arena.</p>
    <small>${best >= MAX_WAVE ? "Rekor: Raid Boss tumbang ✔" : best ? "Rekor: wave " + best : "Belum pernah dicoba"} • Pasukan: ${save.loadout.map(k => towerTypes[effKey(k)].icon).join(" ")}</small></div>`;
  L.raidInfo.querySelector(".raid-thumb").appendChild(mapThumb("raid"));
}
function renderShop() { L.shopGrid.innerHTML = shopKeys.slice().sort((a, b) => towerTypes[a].gem - towerTypes[b].gem).map(k => unitCard(k, "shop")).join(""); }
// ---------- Gacha ----------
function rarityRank(r) { return rarityOrder.indexOf(r); }
function rollRarity() {
  const g = save.gacha;
  g.pRare++; g.pLegend++; g.pMyth++;
  let r = "common";
  if (g.pMyth >= 120) r = "mythical";
  else if (g.pLegend >= 40) r = "legend";
  else {
    const total = rarityOrder.reduce((sum, k) => sum + rarities[k].weight, 0);
    let x = Math.random() * total;
    for (const k of rarityOrder) { x -= rarities[k].weight; if (x < 0) { r = k; break; } }
  }
  if (save.adminNextRarity) { r = save.adminNextRarity; save.adminNextRarity = ""; }
  if (g.pRare >= 10 && rarityRank(r) < rarityRank("rare")) r = "rare";
  if (rarityRank(r) >= 2) g.pRare = 0;
  if (rarityRank(r) >= 3) g.pLegend = 0;
  if (rarityRank(r) >= 4) g.pMyth = 0;
  return r;
}
function pullGacha(n) {
  if (!eventActive()) { lobbyToast("Event sudah berakhir."); return []; }
  const cost = n === 10 ? PULL10_COST : PULL_COST * n;
  if (save.coins < cost) { lobbyToast("Halloween Coin belum cukup. Main di Lembah Hantu untuk mendapatkannya."); return []; }
  save.coins -= cost;
  const results = [];
  for (let i = 0; i < n; i++) {
    const r = rollRarity();
    const pool = gachaKeys.filter(k => towerTypes[k].rarity === r);
    const key = pool[Math.floor(Math.random() * pool.length)];
    const dupe = save.owned.includes(key);
    if (dupe) save.coins += rarities[r].refund; else save.owned.push(key);
    save.gacha.pulls++;
    results.push({ key, r, dupe });
  }
  writeSave();
  renderLobby();
  showPullResults(results);
  const best = results.reduce((a, b) => (rarityRank(b.r) > rarityRank(a.r) ? b : a), results[0]);
  sfx("gacha", best.r);
  if (best.r === "secret") lobbyToast(`🌕 SECRET! Kamu mendapat ${towerTypes[best.key].name}!`);
  else if (rarityRank(best.r) >= 3) lobbyToast(`✨ ${rarities[best.r].name}: ${towerTypes[best.key].name}!`);
  return results;
}
function showPullResults(results) {
  L.gachaResults.innerHTML = results.map((x, i) => {
    const t = towerTypes[x.key], r = rarities[x.r];
    return `<div class="pull-card${x.r === "secret" ? " secret-glow" : ""}" style="--rar:${r.color};animation-delay:${i * 0.12}s">
      <div class="pc-icon">${t.icon}</div><b>${t.name}</b><small style="color:${r.color}">${r.name}</small>
      <em>${x.dupe ? `Duplikat +${r.refund} 🎃` : "✨ BARU!"}</em></div>`;
  }).join("");
}
function renderGacha() {
  const on = eventActive();
  L.gachaTab.hidden = !on; L.coinBadge.hidden = !on;
  setText(L.coins, save.coins);
  if (!on) return;
  setText(L.eventTimer, `Event ${EVENT.name} berakhir ${EVENT.end} • sisa ${eventDaysLeft()} hari`);
  L.pull1.disabled = save.coins < PULL_COST; L.pull10.disabled = save.coins < PULL10_COST;
  const g = save.gacha;
  setHTML(L.pityInfo, `Pity: <b>Rare+</b> dalam ${Math.max(1, 10 - g.pRare)} tarikan • <b>Legend+</b> dalam ${Math.max(1, 40 - g.pLegend)} • <b>Mythical+</b> dalam ${Math.max(1, 120 - g.pMyth)} • total tarikan: ${g.pulls}`);
  const total = rarityOrder.reduce((sum, k) => sum + rarities[k].weight, 0);
  setHTML(L.gachaTable, rarityOrder.map(rk => {
    const r = rarities[rk];
    const units = gachaKeys.filter(k => towerTypes[k].rarity === rk).map(k => {
      const owned = save.owned.includes(k), t = towerTypes[k];
      return rk === "secret" && !owned ? "❓ ???" : `${t.icon} ${t.name}${owned ? " ✔" : ""}`;
    }).join(", ");
    return `<div class="gt-row"><span class="gt-name" style="color:${r.color}">${r.name}</span><span class="gt-rate">${(r.weight / total * 100).toFixed(1).replace(".", ",")}%</span><span class="gt-units">${units}</span><span class="gt-refund">dupe +${r.refund}🎃</span></div>`;
  }).join(""));
}
function renderPatch() {
  L.patchList.innerHTML = patchNotes.map((p, i) => `<article class="patch${i === 0 ? " latest" : ""}">
    <header><span class="ver">v${p.version}</span><b>${p.title}</b>${i === 0 ? '<span class="new-tag">TERBARU</span>' : ""}<small>${p.date}</small></header>
    ${p.sections.map(sec => `<h4>${sec.label}</h4><ul>${sec.items.map(it => `<li>${it}</li>`).join("")}</ul>`).join("")}
  </article>`).join("");
  L.patchBadge.hidden = save.seenPatch === GAME_VERSION;
  if (L.verTag) L.verTag.textContent = `v${GAME_VERSION}`;
}
function renderLobby() {
  sanitizeSave();
  renderPatch();
  renderGacha();
  renderSkin();
  setText(L.gems, save.gems);
  setText(L.crystals, save.crystals);
  setText(L.tokenCount, save.tokens);
  renderMaps(); renderSquad(); renderShop(); renderRaid();
  const m = mapDefs[save.map];
  L.summary.innerHTML = `<b>${m.icon} ${m.name}</b> • ${diff().icon} ${diff().name} • Pasukan: ${save.loadout.map(k => towerTypes[effKey(k)].icon).join(" ")} (${save.loadout.length}/${MAX_SLOTS})`;
}

function toggleLoad(key) {
  sfx("equip");
  if (save.loadout.includes(key)) {
    if (save.loadout.length <= 1) { lobbyToast("Minimal harus ada 1 unit di slot."); return; }
    save.loadout = save.loadout.filter(k => k !== key);
  } else if (save.loadout.length >= MAX_SLOTS) {
    lobbyToast(`Slot penuh (${MAX_SLOTS}). Lepas satu unit dulu.`); return;
  } else save.loadout.push(key);
  writeSave(); renderLobby();
}
function buyRaidUnit(key) {
  const t = towerTypes[key];
  if (save.owned.includes(key)) return;
  if (save.crystals < t.crystal) { lobbyToast("🔷 Crystal belum cukup. Menangkan wave di Raid."); return; }
  save.crystals -= t.crystal; save.owned.push(key); sfx("buy");
  let msg = `${t.name} dibeli!`;
  if (save.loadout.length < MAX_SLOTS) { save.loadout.push(key); msg += " Otomatis dipasang di slot."; } else msg += " Slot penuh, atur di tab Pasukan.";
  writeSave(); renderLobby(); lobbyToast(msg);
}
function buyUnit(key) {
  const t = towerTypes[key];
  if (save.owned.includes(key)) return;
  if (save.gems < t.gem) { lobbyToast("Gems belum cukup. Menangkan wave untuk dapat 💎."); return; }
  save.gems -= t.gem; sfx("buy");
  save.owned.push(key);
  let msg = `${t.name} dibeli!`;
  if (save.loadout.length < MAX_SLOTS) { save.loadout.push(key); msg += " Otomatis dipasang di slot."; }
  else msg += " Slot penuh, atur di tab Pasukan.";
  writeSave(); renderLobby(); lobbyToast(msg);
}
// ---------- Skin & Peti ----------
const crateDefs = [
  { id: "wood",    name: "Peti Kayu",    icon: "📦", cost: 30,  w: { common: 65, uncommon: 28, rare: 7 }, pity: null, col: "#b98a56" },
  { id: "silver",  name: "Peti Perak",   icon: "🧰", cost: 100, w: { uncommon: 40, rare: 45, legend: 14, mythical: 1 }, pity: { r: "legend", n: 20 }, col: "#cfd8e6" },
  { id: "gold",    name: "Peti Emas",    icon: "🏆", cost: 250, w: { rare: 38, legend: 48, mythical: 12, secret: 2 }, pity: { r: "mythical", n: 12 }, col: "#ffd166" },
  { id: "diamond", name: "Peti Berlian", icon: "💎", cost: 600, w: { legend: 55, mythical: 38, secret: 7 }, pity: { r: "secret", n: 25 }, col: "#7ae0ff" }
];
const skinRefund = { common: 6, uncommon: 15, rare: 40, legend: 100, mythical: 250, secret: 600 };
const CRATE5_DISCOUNT = 0.9;
function crateCost(c, n) { return n === 5 ? Math.round(c.cost * 5 * CRATE5_DISCOUNT) : c.cost * n; }
function rollCrate(c) {
  const pt = save.skinPity;
  pt[c.id] = (pt[c.id] || 0) + 1;
  let r = null, x = Math.random() * 100;
  for (const k of rarityOrder) { const w = c.w[k]; if (!w) continue; x -= w; if (x < 0) { r = k; break; } }
  if (!r) r = rarityOrder.filter(k => c.w[k]).pop();
  if (c.pity && pt[c.id] >= c.pity.n && rarityRank(r) < rarityRank(c.pity.r)) r = c.pity.r;
  if (c.pity && rarityRank(r) >= rarityRank(c.pity.r)) pt[c.id] = 0;
  const pool = skinDefs.filter(sk => sk.r === r);
  return pool[Math.floor(Math.random() * pool.length)];
}
function openCrate(id, n) {
  const c = crateDefs.find(x => x.id === id);
  if (!c) return [];
  const cost = crateCost(c, n);
  if (save.crystals < cost) { lobbyToast("🔷 Crystal belum cukup. Menangkan wave di mode Raid."); return []; }
  save.crystals -= cost;
  const results = [];
  for (let i = 0; i < n; i++) {
    const sk = rollCrate(c), dupe = save.skinsOwned.includes(sk.id);
    if (dupe) save.crystals += skinRefund[sk.r]; else save.skinsOwned.push(sk.id);
    results.push({ sk, dupe });
  }
  const best = results.reduce((a, b) => (rarityRank(b.sk.r) > rarityRank(a.sk.r) ? b : a), results[0]);
  skinUI.sel = best.sk.id;
  writeSave(); renderLobby(); showSkinResults(results);
  sfx("gacha", best.sk.r);
  if (rarityRank(best.sk.r) >= 4) lobbyToast(`${best.sk.r === "secret" ? "🌕 SECRET!" : "✨ Mythical!"} Skin ${best.sk.name} didapat dengan efek spesial!`);
  else if (best.sk.r === "legend") lobbyToast(`✨ Legend: skin ${best.sk.name}!`);
  return results;
}
const skinUI = { sel: null, unit: "archer" };
function fxTag(sk) { return sk.fx && sk.fx !== "glow" ? '<span class="fx-tag">✨ EFEK</span>' : sk.glow ? '<span class="fx-tag soft">Aura</span>' : ""; }
function skinSwatch(sk) {
  return sk.rb ? "linear-gradient(135deg,#ff5a5a,#ffd35a,#5aff8a,#5aa0ff,#c05aff)" : `linear-gradient(135deg, ${sk.o} 0 40%, ${sk.t} 40% 60%, ${sk.h} 60%)`;
}
function showSkinResults(results) {
  L.skinResults.innerHTML = results.map((x, i) => {
    const r = rarities[x.sk.r];
    return `<div class="pull-card${x.sk.r === "secret" ? " secret-glow" : ""}" style="--rar:${r.color};animation-delay:${i * 0.12}s">
      <div class="skin-sw" style="background:${skinSwatch(x.sk)}"></div><b>${x.sk.name}</b><small style="color:${r.color}">${r.name}</small>${fxTag(x.sk)}
      <em>${x.dupe ? `Duplikat +${skinRefund[x.sk.r]} 🔷` : "✨ BARU!"}</em></div>`;
  }).join("");
}
function skinUnitKeys() { return save.owned.filter(k => chibiLooks[effKey(k)]); }
function renderSkin() {
  if (!L.crateGrid) return;
  setText(L.crystals, save.crystals);
  L.crateGrid.innerHTML = crateDefs.map(c => {
    const pt = c.pity ? `Pity: ${rarities[c.pity.r].name}+ dalam ${Math.max(1, c.pity.n - (save.skinPity[c.id] || 0))} buka` : "Tanpa pity";
    const rates = rarityOrder.filter(k => c.w[k]).map(k => `<span style="color:${rarities[k].color}">${rarities[k].name} ${c.w[k]}%</span>`).join(" • ");
    return `<div class="crate" style="--crate:${c.col}"><div class="crate-ic">${c.icon}</div><b>${c.name}</b><small class="crate-rate">${rates}</small><small>${pt}</small>
      <div class="crate-btns"><button class="chip-btn buy" data-crate="${c.id}" data-n="1" ${save.crystals < crateCost(c, 1) ? "disabled" : ""}>×1 • ${crateCost(c, 1)} 🔷</button>
      <button class="chip-btn buy" data-crate="${c.id}" data-n="5" ${save.crystals < crateCost(c, 5) ? "disabled" : ""}>×5 • ${crateCost(c, 5)} 🔷</button></div></div>`;
  }).join("");
  const units = skinUnitKeys();
  if (!units.includes(skinUI.unit)) skinUI.unit = units[0] || "archer";
  if (!skinUI.sel || !skinById[skinUI.sel]) skinUI.sel = save.skinAll || (save.skinsOwned[0]) || null;
  L.skinUnit.innerHTML = units.map(k => `<option value="${k}"${k === skinUI.unit ? " selected" : ""}>${towerTypes[effKey(k)].name}</option>`).join("");
  L.skinGrid.innerHTML = skinDefs.map(sk => {
    const own = save.skinsOwned.includes(sk.id), r = rarities[sk.r];
    if (sk.r === "secret" && !own) return `<div class="skin-card locked mystery" style="--rar:${r.color}"><div class="skin-sw">❓</div><b>???</b><small style="color:${r.color}">Secret</small></div>`;
    const on = save.skinAll === sk.id, one = save.skinFor[baseKeyOf(skinUI.unit)] === sk.id;
    return `<button class="skin-card${own ? "" : " locked"}${skinUI.sel === sk.id ? " sel" : ""}" data-skin="${sk.id}" style="--rar:${r.color}">
      <div class="skin-sw" style="background:${skinSwatch(sk)}"></div><b>${sk.name}</b><small style="color:${r.color}">${r.name}</small>${fxTag(sk)}
      ${on ? '<em class="eq">Dipakai semua</em>' : one ? '<em class="eq">Dipakai unit ini</em>' : own ? "" : "<em>Belum punya</em>"}</button>`;
  }).join("");
  const sk = skinById[skinUI.sel], own = sk && save.skinsOwned.includes(sk.id);
  const eff = skinOf(skinUI.unit);
  L.skinInfo.innerHTML = sk ? `<b style="color:${rarities[sk.r].color}">${sk.name}</b> • ${rarities[sk.r].name} ${fxTag(sk)}<br><small>${sk.d || (sk.glow ? "Aura cahaya lembut menyelimuti unit." : "Skin warna biasa.")}${own ? "" : " (pratinjau — belum dimiliki)"}</small>` : "Pilih skin untuk pratinjau.";
  L.skinActions.innerHTML = `<button class="chip-btn buy" data-skact="all" ${own ? "" : "disabled"}>Pakai untuk Semua Unit</button>
    <button class="chip-btn buy" data-skact="one" ${own ? "" : "disabled"}>Pakai di ${towerTypes[effKey(skinUI.unit)].name}</button>
    <button class="chip-btn" data-skact="none1">Unit ini: Tanpa Skin</button>
    <button class="chip-btn" data-skact="clear">Lepas Semua Skin</button>
    <small>Sekarang di unit ini: <b>${eff ? eff.name : "Original"}</b></small>`;
}
let skinRaf = 0;
function skinPreviewLoop() {
  const panel = document.querySelector('[data-panel="skin"]');
  if (!panel || panel.hidden || L.lobby.hidden) { skinRaf = 0; return; }
  const cv = L.skinCanvas, g = cv.getContext("2d");
  g.clearRect(0, 0, cv.width, cv.height);
  const gr = g.createLinearGradient(0, 0, 0, cv.height); gr.addColorStop(0, "#1b2a44"); gr.addColorStop(1, "#243a2a");
  g.fillStyle = gr; g.fillRect(0, 0, cv.width, cv.height);
  const sk = skinById[skinUI.sel] || null, t = Date.now() / 1000, key = effKey(skinUI.unit), Lk = chibiLooks[key];
  if (Lk) {
    const f = Math.floor(t * 0.5) % 2 === 0 ? 1 : -1;
    const ox = Lk.kind === "cannon" ? -14 : 0;
    renderChibi(g, key, sk, cv.width / 2 + ox, cv.height - 36, 1.6, t, { level: 1, face: 1, flash: (t % 2.4) < 0.12 ? 0.1 : 0 });
  }
  skinRaf = requestAnimationFrame(skinPreviewLoop);
}
function startSkinPreview() { if (!skinRaf && L.skinCanvas) skinRaf = requestAnimationFrame(skinPreviewLoop); }
function skinAction(act) {
  const sk = skinById[skinUI.sel], base = baseKeyOf(skinUI.unit);
  if (act === "all" && sk) { save.skinAll = sk.id; save.skinFor = {}; }
  else if (act === "one" && sk) save.skinFor[base] = sk.id;
  else if (act === "none1") save.skinFor[base] = "none";
  else if (act === "clear") { save.skinAll = ""; save.skinFor = {}; }
  sfx("equip"); writeSave(); renderLobby();
}
function switchTab(name) {
  sfx("tab");
  if (name === "patch" && save.seenPatch !== GAME_VERSION) { save.seenPatch = GAME_VERSION; writeSave(); L.patchBadge.hidden = true; }
  L.tabs.forEach(b => b.classList.toggle("active", b.dataset.tab === name));
  L.panels.forEach(p => { p.hidden = p.dataset.panel !== name; });
  if (name === "skin") startSkinPreview();
}
L.tabs.forEach(b => b.addEventListener("click", () => switchTab(b.dataset.tab)));
ui.diffRow.addEventListener("click", e => {
  const b = e.target.closest("[data-diff]");
  if (!b || b.dataset.diff === save.diff) return;
  save.diff = b.dataset.diff; sfx("click"); writeSave();
  if (animationId) cancelAnimationFrame(animationId);
  animationId = null;
  resetGame();
  loop(0);
});
L.mapGrid.addEventListener("click", e => {
  const card = e.target.closest("[data-map]");
  if (!card) return;
  const mid = card.dataset.map;
  if (mapDefs[mid].event && !eventActive()) { lobbyToast("Event sudah berakhir. Map ini tidak tersedia."); return; }
  save.map = mid; sfx("click"); writeSave(); renderLobby();
});
function unitClick(e) {
  const b = e.target.closest("[data-act]");
  if (!b || b.disabled) return;
  const key = b.dataset.key;
  if (b.dataset.act === "toggle") toggleLoad(key);
  else if (b.dataset.act === "buy") buyUnit(key);
  else if (b.dataset.act === "goshop") switchTab("shop");
  else if (b.dataset.act === "buyraid") buyRaidUnit(key);
  else if (b.dataset.act === "evolve") evolveUnit(key);
  else if (b.dataset.act === "evotoggle") toggleEvo(key);
  else if (b.dataset.act === "goraid") switchTab("raid");
  else if (b.dataset.act === "gogacha") { if (eventActive()) switchTab("gacha"); else lobbyToast("Event sudah berakhir."); }
}
L.squadGrid.addEventListener("click", unitClick);
L.slotRow.addEventListener("click", unitClick);
L.shopGrid.addEventListener("click", unitClick);
L.raidShop.addEventListener("click", unitClick);
L.raidBtn.addEventListener("click", () => { sfx("start"); startRun("raid"); });

function showLobby() {
  if (animationId) cancelAnimationFrame(animationId);
  animationId = null;
  document.body.classList.add("in-lobby");
  L.lobby.hidden = false; L.gameView.hidden = true;
  renderLobby();
}
function startRun(mode) {
  runMode = mode === "raid" ? "raid" : "normal";
  sanitizeSave();
  loadout = save.loadout.map(effKey);
  setMap(runMode === "raid" ? "raid" : save.map);
  buildTowerButtons();
  document.body.classList.remove("in-lobby");
  L.lobby.hidden = true; L.gameView.hidden = false;
  if (animationId) cancelAnimationFrame(animationId);
  animationId = null;
  resetGame();
}
function exitToLobby() {
  if (wave > 0 && !gameOver && !runRewarded) {
    if (!window.confirm("Keluar ke lobby? Permainan ini berakhir, hadiah dihitung dari wave yang sudah selesai.")) return;
    const cleared = waveActive ? wave - 1 : wave;
    const gems = grantReward(cleared, wave, false);
    showLobby();
    lobbyToast(gems || lastCrystals ? `${lastCrystals ? `+${lastCrystals} 🔷` : `+${gems} 💎`}${lastCoins ? ` +${lastCoins} 🎃` : ""} dari ${cleared} wave yang selesai.` : "");
    return;
  }
  showLobby();
}
L.crateGrid.addEventListener("click", e => { const b = e.target.closest("[data-crate]"); if (b && !b.disabled) openCrate(b.dataset.crate, +b.dataset.n); });
L.skinGrid.addEventListener("click", e => { const b = e.target.closest("[data-skin]"); if (!b) return; skinUI.sel = b.dataset.skin; sfx("click"); renderSkin(); });
L.skinUnit.addEventListener("change", () => { skinUI.unit = L.skinUnit.value; renderSkin(); });
L.skinActions.addEventListener("click", e => { const b = e.target.closest("[data-skact]"); if (b && !b.disabled) skinAction(b.dataset.skact); });
L.pull1.addEventListener("click", () => pullGacha(1));
L.pull10.addEventListener("click", () => pullGacha(10));
L.playBtn.addEventListener("click", () => { sfx("start"); startRun("normal"); });
ui.lobbyBtn.addEventListener("click", exitToLobby);
ui.overlayLobbyBtn.addEventListener("click", exitToLobby);

// ===============================
// ADMIN (tersembunyi): ketuk nomor versi 5x, lalu masukkan kode.
// Catatan: ini game di sisi browser, jadi kode ini hanya penghalang ringan, bukan keamanan sungguhan.
// ===============================
const ADMIN_HASH = "1obpgoghhte";
function adminHash(str, seed = 0) {
  str = "realm-admin::" + str;
  let h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed;
  for (let i = 0, ch; i < str.length; i++) { ch = str.charCodeAt(i); h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677); }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507); h1 ^= Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507); h2 ^= Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
}
let adminEl = null;
function inRun() { return !L.gameView.hidden; }
function adminSay(text) { const m = adminEl && adminEl.querySelector("[data-admin-msg]"); if (m) m.textContent = text; }
function adminRefresh() {
  writeSave();
  renderLobby();
  if (inRun()) { updateUI(); draw(); }
  if (adminEl) {
    const q = sel => adminEl.querySelector(sel);
    q("[data-state=event]").textContent = eventActive() ? "ON" : "OFF";
    q("[data-state=god]").textContent = adminGod ? "ON" : "OFF";
    q("[data-state=balance]").textContent = `💎 ${save.gems}  •  🎃 ${save.coins}  •  🔷 ${save.crystals}  •  🧿 ${save.tokens}  •  Unit: ${save.owned.length}/${ownableKeys.length}`;
  }
}
function adminCmd(cmd, arg) {
  const num = Number(arg);
  const needRun = () => { if (!inRun()) { adminSay("Perintah ini hanya bisa dipakai saat sedang di dalam game."); return false; } return true; };
  switch (cmd) {
    case "gems": save.gems += num; adminSay(`+${num} 💎`); break;
    case "coins": save.coins += num; adminSay(`+${num} 🎃`); break;
    case "crystals": save.crystals += num; adminSay(`+${num} 🔷`); break;
    case "allskins": save.skinsOwned = skinDefs.map(x => x.id); adminSay("Semua skin dibuka"); break;
    case "resetskins": save.skinsOwned = []; save.skinAll = ""; save.skinFor = {}; save.skinPity = {}; adminSay("Skin direset"); break;
    case "tokens": save.tokens += num; adminSay(`+${num} 🧿`); break;
    case "unlockAll": save.owned = ownableKeys.slice(); adminSay("Semua unit terbuka."); break;
    case "lockAll": save.owned = ["archer"]; save.loadout = ["archer"]; adminSay("Unit direset ke Archer saja."); break;
    case "event": save.adminEvent = !save.adminEvent; adminSay(`Event Halloween paksa: ${save.adminEvent ? "ON" : "OFF"}`); break;
    case "pull": {
      if (!eventActive()) { adminSay("Aktifkan event dulu."); break; }
      const cost = num === 10 ? PULL10_COST : PULL_COST * num;
      save.coins += cost; const res = pullGacha(num);
      adminSay(res.length ? `Tarik gratis ×${num} selesai (lihat tab Gacha).` : "Gagal."); break;
    }
    case "rarity": {
      const sel = adminEl.querySelector("[data-rarity]");
      save.adminNextRarity = sel.value; adminSay(`Tarikan berikutnya dipaksa: ${rarities[sel.value].name}`); break;
    }
    case "resetPity": save.gacha = { pRare: 0, pLegend: 0, pMyth: 0, pulls: 0 }; adminSay("Pity direset."); break;
    case "resetAll":
      if (window.confirm("Hapus SEMUA progres di browser ini?")) { try { localStorage.removeItem(SAVE_KEY); } catch (e) { /* abaikan */ } location.reload(); }
      return;
    // ---- perintah dalam game ----
    case "gold": if (!needRun()) return; gold += num; adminSay(`+${num} gold`); break;
    case "heal": if (!needRun()) return; health = diff().lives; adminSay(`Nyawa dipulihkan jadi ${health}.`); break;
    case "god": adminGod = !adminGod; adminSay(`Nyawa tak terbatas: ${adminGod ? "ON" : "OFF"}`); break;
    case "skipWave":
      if (!needRun()) return;
      if (!waveActive) { adminSay("Tidak ada wave yang sedang berjalan."); return; }
      spawnQueue = []; enemies.forEach(e => { e.hp = 0; }); adminSay("Wave dilewati."); break;
    case "boss":
      if (!needRun()) return;
      if (wave === 0 || !waveActive) { adminSay("Mulai wave dulu."); return; }
      spawnEnemy("boss"); adminSay("Bos dipanggil."); break;
    case "jumpWave": {
      if (!needRun()) return;
      const sel = adminEl.querySelector("[data-wave]"), n = Math.max(1, Math.min(MAX_WAVE, parseInt(sel.value, 10) || 1));
      if (waveActive) { adminSay("Tunggu wave selesai dulu."); return; }
      wave = n - 1; adminSay(`Wave berikutnya: ${n}`); break;
    }
    case "maxAll": if (!needRun()) return; towers.forEach(t => { t.level = maxLevel(t); }); adminSay("Semua tower dimaksimalkan."); break;
    case "meteor": if (!needRun()) return; meteorCooldown = 0; adminSay("Meteor siap."); break;
    default: return;
  }
  adminRefresh();
}
function buildAdmin() {
  adminEl = document.createElement("div");
  adminEl.className = "admin-overlay";
  adminEl.hidden = true;
  const btn = (label, cmd, arg = "") => `<button data-cmd="${cmd}" data-arg="${arg}">${label}</button>`;
  adminEl.innerHTML = `<div class="admin-card">
    <div data-view="gate">
      <h3>🔒 Admin</h3>
      <input type="password" data-code placeholder="Masukkan kode" autocomplete="off" autocapitalize="off" spellcheck="false">
      <p class="admin-msg" data-gate-msg></p>
      <div class="admin-row"><button data-cmd="enter" class="primary">Masuk</button><button data-cmd="close">Batal</button></div>
    </div>
    <div data-view="panel" hidden>
      <div class="admin-head"><h3>🛠️ Panel Admin</h3><button data-cmd="close">✕</button></div>
      <p class="admin-state" data-state="balance"></p>
      <h4>Lobby</h4>
      <div class="admin-grid">${btn("+100 💎", "gems", 100)}${btn("+1000 💎", "gems", 1000)}${btn("+50 🎃", "coins", 50)}${btn("+500 🎃", "coins", 500)}${btn("+500 🔷", "crystals", 500)}${btn("+10 🧿", "tokens", 10)}${btn("🎨 Semua Skin", "allskins", 0)}${btn("Reset Skin", "resetskins", 0)}
        ${btn("Buka semua unit", "unlockAll")}${btn("Reset unit", "lockAll")}</div>
      <h4>Event &amp; Gacha</h4>
      <div class="admin-grid">${btn("Event paksa: <b data-state='event'>-</b>", "event")}${btn("Tarik gratis ×1", "pull", 1)}${btn("Tarik gratis ×10", "pull", 10)}${btn("Reset pity", "resetPity")}</div>
      <div class="admin-row"><select data-rarity>${rarityOrder.map(k => `<option value="${k}">${rarities[k].name}</option>`).join("")}</select>${btn("Paksa tarikan berikutnya", "rarity")}</div>
      <h4>Dalam game</h4>
      <div class="admin-grid">${btn("+1000 gold", "gold", 1000)}${btn("+10000 gold", "gold", 10000)}${btn("Pulihkan nyawa", "heal")}${btn("Nyawa tak terbatas: <b data-state='god'>-</b>", "god")}
        ${btn("Lewati wave", "skipWave")}${btn("Panggil bos", "boss")}${btn("Maksimalkan tower", "maxAll")}${btn("Meteor siap", "meteor")}</div>
      <div class="admin-row"><input type="number" min="1" max="${MAX_WAVE}" value="1" data-wave>${btn("Lompat ke wave", "jumpWave")}</div>
      <h4>Bahaya</h4>
      <div class="admin-grid">${btn("Reset SEMUA progres", "resetAll")}</div>
      <p class="admin-msg" data-admin-msg></p>
    </div></div>`;
  document.body.appendChild(adminEl);
  adminEl.addEventListener("click", e => {
    if (e.target === adminEl) { adminEl.hidden = true; return; }
    const b = e.target.closest("[data-cmd]");
    if (!b) return;
    const cmd = b.dataset.cmd;
    if (cmd === "close") { adminEl.hidden = true; return; }
    if (cmd === "enter") { tryAdminCode(); return; }
    adminCmd(cmd, b.dataset.arg);
  });
  adminEl.addEventListener("keydown", e => { if (e.key === "Enter" && e.target.matches && e.target.matches("[data-code]")) tryAdminCode(); });
}
function showAdminView(name) {
  adminEl.querySelectorAll("[data-view]").forEach(v => { v.hidden = v.dataset.view !== name; });
}
function tryAdminCode() {
  const input = adminEl.querySelector("[data-code]");
  if (adminHash(input.value.trim()) === ADMIN_HASH) {
    adminUnlocked = true; input.value = "";
    showAdminView("panel"); adminRefresh(); adminSay("");
  } else {
    adminEl.querySelector("[data-gate-msg]").textContent = "Kode salah.";
    input.value = "";
  }
}
function openAdmin() {
  if (!adminEl) buildAdmin();
  adminEl.hidden = false;
  if (adminUnlocked) { showAdminView("panel"); adminRefresh(); }
  else {
    showAdminView("gate");
    adminEl.querySelector("[data-gate-msg]").textContent = "";
    const input = adminEl.querySelector("[data-code]");
    input.value = ""; if (input.focus) input.focus();
  }
}
let verTaps = 0, verTimer = null;
if (L.verTag) {
  L.verTag.addEventListener("click", () => {
    verTaps++;
    clearTimeout(verTimer);
    verTimer = setTimeout(() => { verTaps = 0; }, 2500);
    if (verTaps >= 5) { verTaps = 0; openAdmin(); }
  });
}

ui.canvasWrap = canvas.parentElement;
sanitizeSave();
setMap(save.map);
loadout = save.loadout.slice();
buildTowerButtons();
resetGame();
showLobby();
if (eventActive() && !save.seenEvent) {
  save.seenEvent = true; writeSave();
  lobbyToast(`🎃 Event ${EVENT.name} dimulai! Kamu mendapat ${save.coins} Halloween Coin gratis. Buka tab Gacha.`);
}


// ===============================
// INTRO SINEMATIK saat game dibuka
// ===============================
(function introScene() {
  try { introMain(); } catch (e) { const r = document.getElementById("intro"); if (r && r.remove) r.remove(); }
})();
function introMain() {
  const root = document.getElementById("intro");
  const cv = document.getElementById("introCanvas");
  if (!root || !cv) return;
  let skipped = false, raf = 0, t0 = 0, doneAt = 0;
  try { if (window.sessionStorage && sessionStorage.getItem("rd.intro")) { root.remove(); return; } } catch (e) { /* abaikan */ }
  const g = cv.getContext("2d");
  let W2 = 900, H2 = 520, S = 1;
  function fit() {
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    W2 = Math.max(320, window.innerWidth); H2 = Math.max(320, window.innerHeight);
    cv.width = Math.round(W2 * dpr); cv.height = Math.round(H2 * dpr);
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    S = Math.min(W2 / 900, H2 / 520) * (W2 < 600 ? 1.15 : 1);
  }
  fit(); window.addEventListener("resize", fit);
  const stars = Array.from({ length: 90 }, (_, i) => ({ x: (Math.sin(i * 91.7) * 0.5 + 0.5), y: (Math.sin(i * 37.3 + 1) * 0.5 + 0.5) * 0.6, r: 0.6 + (i % 4) * 0.4, p: i * 1.7 }));
  const embers = Array.from({ length: 46 }, (_, i) => ({ x: Math.sin(i * 12.9) * 0.5 + 0.5, sp: 18 + (i % 7) * 9, ph: i * 0.37, r: 1 + (i % 3) }));
  const squad = (save.loadout || ["archer"]).map(effKey).filter(k => chibiLooks[k]);
  ["archer", "ice", "tesla", "flame", "cannon"].forEach(k => { if (squad.length < 5 && !squad.includes(k)) squad.push(k); });
  const foes = Array.from({ length: 9 }, (_, i) => ({ x0: -0.06 - i * 0.05, kind: i % 4 === 3 ? 1 : 0, born: i * 0.22 }));
  const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
  const ease = v => 1 - Math.pow(1 - clamp(v), 3);

  function slime(x, y, r, t, hp, big) {
    g.save(); g.translate(x, y);
    const sq = 1 + Math.sin(t * 8 + x * 0.05) * 0.08;
    g.fillStyle = "#0004"; g.beginPath(); g.ellipse(0, r * 0.9, r * 0.9, r * 0.25, 0, 0, Math.PI * 2); g.fill();
    g.scale(1 / sq, sq);
    g.fillStyle = big ? "#f2a65a" : "#79d68a"; g.strokeStyle = "#14161c"; g.lineWidth = 3;
    g.beginPath(); g.ellipse(0, 0, r, r * 0.9, 0, 0, Math.PI * 2); g.fill(); g.stroke();
    g.fillStyle = "#fff"; g.beginPath(); g.arc(-r * 0.35, -r * 0.15, r * 0.24, 0, 6.3); g.arc(r * 0.35, -r * 0.15, r * 0.24, 0, 6.3); g.fill();
    g.fillStyle = "#14161c"; g.beginPath(); g.arc(-r * 0.3, -r * 0.12, r * 0.1, 0, 6.3); g.arc(r * 0.4, -r * 0.12, r * 0.1, 0, 6.3); g.fill();
    g.restore();
  }
  function frame(now) {
    if (!t0) t0 = now;
    const t = (now - t0) / 1000;
    const w = W2, h = H2;
    // langit senja
    const sky = g.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, "#070a1c"); sky.addColorStop(0.55, "#2a1747"); sky.addColorStop(0.82, "#c0476a"); sky.addColorStop(1, "#ff9a4d");
    g.fillStyle = sky; g.fillRect(0, 0, w, h);
    stars.forEach(s2 => { g.globalAlpha = 0.35 + 0.65 * Math.abs(Math.sin(t * 1.6 + s2.p)); g.fillStyle = "#fff"; g.beginPath(); g.arc(s2.x * w, s2.y * h, s2.r, 0, 6.3); g.fill(); });
    g.globalAlpha = 1;
    // bulan
    g.fillStyle = "#fff3d0"; g.shadowColor = "#ffd9a0"; g.shadowBlur = 40; g.beginPath(); g.arc(w * 0.18, h * 0.2, 34 * S, 0, 6.3); g.fill(); g.shadowBlur = 0;
    g.fillStyle = "#e8d3a6"; g.beginPath(); g.arc(w * 0.18 + 9 * S, h * 0.2 - 6 * S, 7 * S, 0, 6.3); g.arc(w * 0.18 - 10 * S, h * 0.2 + 8 * S, 5 * S, 0, 6.3); g.fill();
    // gunung berlapis
    const ridge = (base, amp, col, sp, ph) => { g.fillStyle = col; g.beginPath(); g.moveTo(0, h); for (let x = 0; x <= w; x += 20) g.lineTo(x, base - amp * (Math.sin(x * sp + ph) * 0.5 + 0.5 + Math.sin(x * sp * 2.3 + ph * 2) * 0.25)); g.lineTo(w, h); g.closePath(); g.fill(); };
    ridge(h * 0.6, 70 * S, "#3a2260", 0.006, 1); ridge(h * 0.68, 60 * S, "#2a1848", 0.009, 4);
    // benteng di kanan
    const cx = w * 0.86, gy = h * 0.74;
    g.fillStyle = "#1a1230"; g.strokeStyle = "#0b0818"; g.lineWidth = 3;
    g.fillRect(cx - 70 * S, gy - 90 * S, 140 * S, 90 * S); g.strokeRect(cx - 70 * S, gy - 90 * S, 140 * S, 90 * S);
    for (let i = 0; i < 6; i++) g.fillRect(cx - 70 * S + i * 25 * S, gy - 104 * S, 16 * S, 14 * S);
    [[-50, -150], [50, -140]].forEach(([dx, dy]) => { g.fillRect(cx + dx * S - 16 * S, gy + dy * S, 32 * S, -dy * S); g.beginPath(); g.moveTo(cx + dx * S - 22 * S, gy + dy * S); g.lineTo(cx + dx * S, gy + (dy - 34) * S); g.lineTo(cx + dx * S + 22 * S, gy + dy * S); g.closePath(); g.fillStyle = "#c0476a"; g.fill(); g.fillStyle = "#1a1230"; });
    g.fillStyle = "#ffd166";
    for (let i = 0; i < 5; i++) if (Math.sin(t * 3 + i * 2.1) > -0.6) g.fillRect(cx - 52 * S + i * 24 * S, gy - 60 * S, 8 * S, 12 * S);
    g.fillStyle = "#d93a3a"; g.beginPath(); g.moveTo(cx - 50 * S, gy - 184 * S); g.lineTo(cx - 50 * S + 26 * S, gy - 176 * S + Math.sin(t * 5) * 3); g.lineTo(cx - 50 * S, gy - 168 * S); g.fill();
    // tanah & jalan
    const gr = g.createLinearGradient(0, gy, 0, h); gr.addColorStop(0, "#2a3a2a"); gr.addColorStop(1, "#101a14");
    g.fillStyle = gr; g.fillRect(0, gy, w, h - gy);
    g.fillStyle = "#6a5236"; g.fillRect(0, gy + 26 * S, w, 24 * S);
    g.fillStyle = "#8a6c46"; for (let x = 0; x < w; x += 40) g.fillRect(x + ((t * 0) % 40), gy + 36 * S, 18, 3);
    // musuh datang dari kiri
    const lineX = w * 0.5;
    foes.forEach((f, i) => {
      const age = t - f.born; if (age < 0) return;
      const x = f.x0 * w + age * (125 + (i % 3) * 16) * S;
      const stop = lineX - 40 * S - (i % 3) * 22 * S;
      const fx2 = Math.min(x, stop);
      const dieT = 3.6 + i * 0.32;
      if (t > dieT + 0.5) return;
      const dying = t > dieT, a = dying ? 1 - (t - dieT) / 0.5 : 1;
      g.globalAlpha = Math.max(0, a);
      slime(fx2, gy + 36 * S - (dying ? (t - dieT) * 30 : 0), (f.kind ? 17 : 12) * S, t + i, 1, f.kind);
      g.globalAlpha = 1;
    });
    // pahlawan di kanan-tengah, menghadap kiri
    const base = gy + 52 * S, start = w * 0.56, spacing = Math.min(86 * S, (w * 0.93 - start) / 4);
    squad.slice(0, 5).forEach((k, i) => {
      const appear = ease((t - 0.3 - i * 0.18) / 0.5); if (appear <= 0) return;
      const x = start + i * spacing + (1 - appear) * 120 * S, y = base + (i % 2) * 10 * S;
      const fl = (Math.sin(t * 3 + i * 1.7) > 0.93) ? 0.1 : 0;
      g.globalAlpha = appear;
      renderChibi(g, k, skinOf(k), x, y, 0.95 * S, t + i, { face: -1, ring: false, flash: fl });
      g.globalAlpha = 1;
      // serangan sederhana ke arah musuh
      if (t > 0.9) {
        const ph = (t * 1.1 + i * 0.37) % 1;
        if (ph < 0.18) {
          const tx = lineX - 30 * S - ph * 200 * S, ty = gy + 34 * S, sx = x - 18 * S, sy = y - 34 * S, a = 1 - ph / 0.18;
          g.globalAlpha = a; g.lineWidth = 3;
          if (k === "tesla" || k === "storm") { g.strokeStyle = "#9ff1ff"; g.beginPath(); g.moveTo(sx, sy); for (let q = 1; q <= 5; q++) g.lineTo(sx + (tx - sx) * q / 5, sy + (ty - sy) * q / 5 + (Math.random() - 0.5) * 16); g.stroke(); }
          else if (k === "flame" || k === "blazed") { g.fillStyle = "#ff8a3d"; for (let q = 0; q < 6; q++) { g.beginPath(); g.arc(sx + (tx - sx) * q / 6, sy + (ty - sy) * q / 6, 4 + q * 1.4, 0, 6.3); g.fill(); } }
          else if (k === "ice" || k === "blizzard") { g.fillStyle = "#bff4ff"; g.beginPath(); g.arc(sx + (tx - sx) * (1 - a) * 5.5, sy + (ty - sy) * (1 - a) * 5.5, 5, 0, 6.3); g.fill(); }
          else { g.strokeStyle = "#ffe9a8"; g.beginPath(); g.moveTo(sx, sy); g.lineTo(sx + (tx - sx) * 0.35, sy + (ty - sy) * 0.35); g.stroke(); }
          g.globalAlpha = 1;
        }
      }
    });
    // percikan api melayang
    embers.forEach(e => { const y = h - ((t * e.sp + e.ph * 300) % (h * 0.9)); g.globalAlpha = 0.5 * (y / h); g.fillStyle = e.r > 2 ? "#ffd166" : "#ff8a3d"; g.beginPath(); g.arc(e.x * w + Math.sin(t + e.ph * 5) * 14, y, e.r, 0, 6.3); g.fill(); });
    g.globalAlpha = 1;
    // vinyet
    const vg = g.createRadialGradient(w / 2, h / 2, h * 0.3, w / 2, h / 2, h * 0.9); vg.addColorStop(0, "#0000"); vg.addColorStop(1, "#000a");
    g.fillStyle = vg; g.fillRect(0, 0, w, h);
    // judul
    const ts = ease((t - 1.0) / 1.1), ty0 = h * 0.26;
    if (ts > 0) {
      g.save(); g.translate(w / 2, ty0); g.globalAlpha = ts; const sc = (0.6 + 0.4 * ts) * Math.min(1, (w * 0.92) / 690);
      g.scale(sc, sc); g.textAlign = "center"; g.textBaseline = "middle";
      g.font = "900 78px system-ui, 'Segoe UI', sans-serif";
      g.lineJoin = "round"; g.lineWidth = 14; g.strokeStyle = "#1a0c2e"; g.strokeText("REALM DEFENSE", 0, 0);
      const tg = g.createLinearGradient(0, -40, 0, 40); tg.addColorStop(0, "#fff6c0"); tg.addColorStop(0.5, "#ffd166"); tg.addColorStop(1, "#ff8a3d");
      g.shadowColor = "#ff9a4d"; g.shadowBlur = 30 + Math.sin(t * 3) * 10; g.fillStyle = tg; g.fillText("REALM DEFENSE", 0, 0); g.shadowBlur = 0;
      // kilau melintas
      const sh = ((t - 2.2) * 600) % 1400 - 500; g.save(); g.beginPath(); g.rect(-380, -45, 760, 90); g.clip(); g.fillStyle = "#ffffff88"; g.transform(1, 0, -0.4, 1, 0, 0); if (t > 2.2) g.fillRect(sh, -60, 40, 120); g.restore();
      g.font = "800 34px system-ui, sans-serif"; g.lineWidth = 8; g.strokeText("2D  •  TOWER DEFENSE", 0, 62); g.fillStyle = "#e8d9ff"; g.fillText("2D  •  TOWER DEFENSE", 0, 62);
      g.restore();
    }
    const ps = clamp((t - 3) / 0.6);
    if (ps > 0) {
      g.textAlign = "center"; g.font = `700 ${Math.round(20 * Math.min(1.1, w / 520))}px system-ui, sans-serif`;
      g.globalAlpha = ps * (0.55 + 0.45 * Math.abs(Math.sin(t * 2.4))); g.fillStyle = "#fff"; g.strokeStyle = "#000a"; g.lineWidth = 4;
      g.strokeText("Ketuk layar untuk bermain", w / 2, h - 36); g.fillText("Ketuk layar untuk bermain", w / 2, h - 36); g.globalAlpha = 1;
    }
    // fade in awal & fade out akhir
    if (t < 0.7) { g.fillStyle = `rgba(0,0,0,${1 - t / 0.7})`; g.fillRect(0, 0, w, h); }
    if (skipped) {
      const k = clamp((now - doneAt) / 450);
      root.style.opacity = String(1 - k);
      if (k >= 1) { root.remove(); window.removeEventListener("resize", fit); cancelAnimationFrame(raf); return; }
    }
    raf = requestAnimationFrame(frame);
  }
  function go() {
    if (skipped) return;
    skipped = true; doneAt = performance.now();
    try { sessionStorage.setItem("rd.intro", "1"); } catch (e) { /* abaikan */ }
    sfx("intro");
  }
  root.addEventListener("pointerdown", go);
  document.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " " || e.key === "Escape") go(); });
  raf = requestAnimationFrame(frame);
}
